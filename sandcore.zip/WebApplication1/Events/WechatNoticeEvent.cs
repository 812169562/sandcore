﻿using Microsoft.Extensions.Configuration;
using RestSharp;
using Sand.Attributes;
using Sand.DI;
using Sand.Domain.Repositories.PaymentOrder;
using Sand.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebApplication1.Controllers;

namespace WebApplication1
{
    /// <summary>
    /// 微信推送消息
    /// </summary>
    [Event]
    public class WechatNoticeEvent : IEvent
    {
        /// <summary>
        /// 
        /// </summary>
        public WechatNoticeEvent()
        {
        }
        /// <summary>
        /// 事件发生时间
        /// </summary>
        public DateTime Time { get; set; }
        /// <summary>
        /// 事件编号
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 事件发生时间
        /// </summary>
        public string Text { get; set; }
    }
    /// <summary>
    /// 微信通知发送消息
    /// </summary>
    [EventHandler]
    public class WechatNotice_EventHandler : IEventHandler<WechatNoticeEvent>
    {
        private IOrderslogRepository _thridManager;
        /// <summary>
        /// 初始化
        /// </summary>
        public WechatNotice_EventHandler()
        {
            _thridManager = Ioc.GetService<IOrderslogRepository>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="event"></param>
        /// <returns></returns>
        public bool CanHandle(IEvent @event)
             => @event.GetType().Equals(typeof(WechatNoticeEvent));

        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<bool> HandleAsync(WechatNoticeEvent @event, CancellationToken cancellationToken = default)
        {
            //var accesstoken = _thridManager.Test2(@event.Text);
            return await Task.FromResult(true);
        }
        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<bool> HandleAsync(IEvent @event, CancellationToken cancellationToken = default)
               => CanHandle(@event) ? HandleAsync((WechatNoticeEvent)@event, cancellationToken) : Task.FromResult(false);

        Task<bool> IEventHandler.CanHandle(IEvent @event)
        {
            throw new NotImplementedException();
        }
    }
}
