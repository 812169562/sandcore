﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspectCore.Extensions.Autofac;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Sand.DI;
using Exceptionless;
using Sand.Domain.Uow;
using Sand.Log.Extensions;
using Sand.Data;
using Sand.Context;
using Microsoft.AspNetCore.Http;
using Sand.Events;
using AspectCore.DynamicProxy.Parameters;
using NLog.Web;
using NLog.Extensions.Logging;
using Sand.Log.Abstractions;
using Sand.Log.Provider;
using Sand.Log.Factory;
using Exceptionless.Models;
using Exceptionless.Plugins;
using MongoDB.Bson.Serialization;
using Sand.Mongo;
using EasyCaching.Core;
using EasyCaching.InMemory;
using EasyCaching.CSRedis;
using EasyCaching.Core.Configurations;
using Microsoft.Extensions.PlatformAbstractions;
using System.IO;
using Sand.Api.Filters;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerUI;
using Sand.Cloud.Express.Kdniao;
using Sand.Cloud.Express;

namespace WebApplication1
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddCors(options => options.AddPolicy("any", builder =>
            {
                builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader().AllowCredentials();
            }));

            DefaultIocConfig.ContainerBuilder.AddExceptionless(t =>
            {
                ExceptionlessClient.Default.Configuration.ServerUrl = "http://210.41.221.239:50000";
            });
            DefaultIocConfig.ContainerBuilder.RegisterModule<DefaultIocConfig>();
            DefaultIocConfig.ContainerBuilder.RegisterType<SqlQuery>().As<ISqlQuery>().AsImplementedInterfaces().InstancePerLifetimeScope();
            services.AddScoped<IUserContext, TestUserContext>();
            DefaultIocConfig.ContainerBuilder.RegisterType<HttpContextAccessor>().As<IHttpContextAccessor>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<WebContext>().As<IContext>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<WriteEfUnitOfWork>().As<IWriteUnitOfWork>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<ReadEfUnitOfWork>().As<IReadUnitOfWork>().AsImplementedInterfaces().InstancePerLifetimeScope();
            //services.AddScoped<IWriteUnitOfWork, WriteEfUnitOfWork>();
            //services.AddScoped<IReadUnitOfWork, ReadEfUnitOfWork>();
            //DefaultIocConfig.ContainerBuilder.RegisterType<KdniaoExpress>().As<IExpress>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<MySqlConfig>().As<ISqlConfig>().AsImplementedInterfaces().SingleInstance();
            DefaultIocConfig.ContainerBuilder.RegisterType<ExceptionlessProviderFactory>().As<ILogProviderFactory>().AsImplementedInterfaces().SingleInstance();
            services.AddEasyCaching(option =>
            {
                //use memory cache that named default
                option.UseInMemory();
                option.UseCSRedis(config =>
                {
                    config.DBConfig = new CSRedisDBOptions
                    {
                        ConnectionStrings = new List<string>
                        {
                            "210.41.221.221:6379,poolsize=10,password=cdutcm@123"
                        }
                    };
                });
            });
            AddSwaggerGenConfig(services);
            DefaultIocConfig.ContainerBuilder.RegisterDynamicProxy(config =>
            {
                config.EnableParameterAspect();
            });
            services.AddDefaultEventBus();
            DefaultIocConfig.ContainerBuilder.AddAspectCoreInterceptor(t => t.CacheProviderName = "DefaultInMemory");
            DefaultIocConfig.ContainerBuilder.AddRedisAspectCoreInterceptor();
            //BsonSerializer.RegisterSerializer(new DateTimeOffsetSupportingBsonDateTimeSerializer());
            DefaultIocConfig.ContainerBuilder.Populate(services);
            DefaultIocConfig.Container = DefaultIocConfig.ContainerBuilder.Build();
            return DefaultIocConfig.Container.Resolve<IServiceProvider>();
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseEasyCaching();
            loggerFactory.AddNLog();
            app.UseCors("any");
            env.ConfigureNLog("nlog.config");
            //Exceptionless.ExceptionlessClient.Default.Configuration.ServerUrl = "http://210.41.221.239:50000";
            //Exceptionless.ExceptionlessClient.Default.Configuration.ApiKey = "3TU9S2rEdg6pqPeppqeigjVgxkylxElb2Eic2kuh";
            app.UseExceptionless("ae38lB0FGA5u7Q5CZhioI2Oojg5vBzOKPzz3Mj7I");
            app.UseDefaultEventBus();
            ExceptionlessClient.Default.SubmittingEvent += SubmitEvent;
            ExceptionlessClient.Default.SubmittedEvent += OnSubmittedEvent;
            app.UseHttpsRedirection();

            app.UseSwagger(x =>
            {
            });

            app.UseSwaggerUI(c =>
            {
                //c.IndexStream = () => GetType().GetTypeInfo().Assembly.GetManifestResourceStream("Sand.UnifiedStorage.Swagger.index.html");
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                c.OAuthClientId("js");
                //c.OAuthAppName("js");
                c.OAuth2RedirectUrl("http://localhost:50001/swagger/oauth2-redirect.html");
                //c.OAuthClientSecret("test-secret");
                //c.OAuthRealm("test-realm");
                c.OAuthScopeSeparator(" ");
                c.OAuthUseBasicAuthenticationWithAccessCodeGrant();
                //c.HeadContent = StartupExtension.AddSandAuthentication();
                c.DocExpansion(DocExpansion.None);
            });
            app.UseMvc();
        }

        private void OnSubmittedEvent(object sender, EventSubmittedEventArgs e)
        {
        }

        private void SubmitEvent(object sender, EventSubmittingEventArgs e)
        {
        }

        /// <summary>
        /// 添加swagger
        /// </summary>
        /// <param name="services"></param>
        public void AddSwaggerGenConfig(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Title = "远程会诊Api",
                    TermsOfService = "WebApplication1.xml",
                });
                //c.AddSecurityDefinition("oauth2",
                //    new OAuth2Scheme()
                //    {
                //        Type = "oauth2",
                //        Flow = "implicit",
                //        AuthorizationUrl = "http://localhost:5000/connect/authorize",
                //        //TokenUrl = "http://localhost:5000/connect/token/",
                //        //Description = "勾选授权范围，获取Token",
                //        Scopes = new Dictionary<string, string>(){
                //            { "openid","用户标识" },
                //            { "profile","用户资料" },
                //            { "api1","api"},
                //        }
                //    });
                //c.OperationFilter<SecurityRequirementsOperationFilter>();
                c.DocInclusionPredicate((docName, description) => true);
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                var xmlPath = Path.Combine(basePath, "WebApplication1.xml");
                c.IncludeXmlComments(xmlPath);
                c.OperationFilter<SwaggerOperationFilter>();
                c.DocumentFilter<CustomDocumentFiliter>();
            });
        }
    }
}
