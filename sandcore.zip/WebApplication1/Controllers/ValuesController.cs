﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using OfficeOpenXml;
using Sand.Api;
using Sand.Api.Filters;
using Sand.Api.Models;
using Sand.Cache;
using Sand.Cloud.Express;
using Sand.Cloud.Express.Kdniao;
using Sand.Cloud.Tencent.Ocr;
using Sand.Context;
using Sand.Data;
using Sand.DI;
using Sand.Domain.Entities;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;
using Sand.Domain.Uow;
using Sand.Events;
using Sand.Exceptions;
using Sand.Extensions;
using Sand.Filter;
using Sand.Log.Less;
using Sand.Maps;
using Sand.Service.Contract.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Utils.Enums;
using Test.Service.Domain;
using Test.Service.Service;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ExceptionHandler]
    [EnableCors("any")]
    public class ValuesController : BaseApiController
    {
        private IOrderslogRepository _userContext;
        private ISqlQuery _sqlQuery;
        private IMongoTest _mongoTest;
        private IUnitOfWork _uow;
        private IOCR _oCR;
        private IEventBus _eventBus { get; set; }
        private IUsersService _userServive { get; set; }
        private IHttpContextAccessor _context { get; set; }
        private IPaymentService _pamentServcice { get; set; }
        private IOrdersRepository _order { get; set; }

        public ValuesController(IOrderslogRepository
            userContext,
            ISqlQuery sqlQuery,
            IMongoTest mongoTest,
            IEventBus eventBus,
            IOCR oCR,
            IUsersService userServive, IHttpContextAccessor context, IPaymentService paymentService,IOrdersRepository orders)
        {
            _userContext = userContext;
            _sqlQuery = sqlQuery;
            _mongoTest = mongoTest;
            _eventBus = eventBus;
            _oCR = oCR;
            _userServive = userServive;
            _context = context;
            _pamentServcice = paymentService;
            _order = orders;
        }

        // GET api/values
        [HttpGet]
        public virtual async Task<IActionResult> Get(UsersQuery user)
        {
            var context = _context.HttpContext.TraceIdentifier;
            try
            {
                //if (id.IsEmpty())
                //{
                //    return Success("");
                //}
                //NLog.LogManager.GetLogger("Debug").Error("GET" + context);
                var query = new UsersQuery() { UserName = "测试", Id = "39f2bfc3a01305267446d2a9c420157a" };
                var data=(await _userServive.RetrieveAsync(query)).First();

                var data2 = (await _userServive.RetrieveAsync(query)).First();

                var order = await _sqlQuery.QueryAsync<Orders>("select *  from orders where id=?ID", new Orders { Id = "39f2bfc3a01305267446d2a9c420157a" });
                var dto = order.First().MapTo<OrdersDto>();
                await _pamentServcice.RefundsAuditAsync(dto);
                //var data = await _userServive.CreateAsync(new Sand.Service.Dtos.Systems.UsersDto() { Id = id });
                //NLog.LogManager.GetLogger("Debug").Error("GET结束" + context+"\r\n");
                //var f1f = await _oCR.GetIdCard(
                //    new InputParm() { ImageUrl= "https://yztw.cddmi.cn/identitycard/20200207/39f331323fe08e925c72cec91995145c.png" });

                //var f1f2 = await _oCR.GetIdCard(
                //   new InputParm() { ImageBase64="dwedw,kpod" });
                //TestMapA testMapA = new TestMapA()
                //{
                //    Property = "12",
                //    TestMapB = new TestMapB { MyProperty = "123" }
                //};
                //var ff = testMapA.MapTo<TestMapAA>();
                //_userContext.Test4(id);
                //var express = Ioc.GetService<IKdniaoExpress>();
                //var a = new KdniaoOrderQueryRequest<OrderQueryRequest>();
                //a.SubscribeData.LogisticCode = "123";
                //a.SubscribeData.OrderCode = "123123";
                //a.SubscribeData.ShipperCode = "123123";
                //KdniaoOrderQueryResponse ff = await express.ExecuteRealTime<KdniaoOrderQueryRequest<OrderQueryRequest>, KdniaoOrderQueryResponse>(a);
                //using (ExcelPackage excelPackage = new ExcelPackage())
                //{
                //    ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("test");
                //    //worksheet.Cells[0,1].Value
                //}
                //WechatNoticeEvent drugsLog = new WechatNoticeEvent
                //{
                //    Text = id
                //};
                //_eventBus.PublishAsync(drugsLog);
                return Success(new { data = "", date = DateTime.Now, context = context, context2 = _context.HttpContext.TraceIdentifier });
                //return Success("");
                //Test1 test1 = new Test1();
                //test1.MyProperty = "1";
                //test1.MyProperty2 = "3";
                //test1.MyProperty3 = "5";
                //test1.MyProperty4 = 12;
                //test1.MyProperty5 = DateTime.Now;
                //var test4 = new Test4() { MyProperty = "1" };
                //test1.Test4.Add(test4);
                //var a = test1.MapTo<Test3>();
                ////var client = new MongoClient("mongodb://210.41.221.221:27017");
                ////var database = client.GetDatabase("chats"); // WriteConcern defaulted to Acknowledged
                ////var test = database.GetCollection<TestEntiy3>("testentiy");
                ////test.InsertOne(new TestEntiy3());
                ////return Success("");

                ////var a = _mongoTest.Get("e0d32901-b699-4d31-9848-254acd6169aa");
                //var b = _mongoTest.Get("5d5ba1c85805fb41e0d3e6dc");
                //_mongoTest.Insert(new TestEntiy());
                //for (int i = 0; i < 100; i++)
                //{
                //    _userContext.RetrieveAll();
                //}
                // var data=_sqlQuery.Query<Orderslog>("select *  from Orderslog where Id=?Id",new {Id= "39ef86a514e6932b4dde5fa71a6f16f6" });
                //var data3 = new ExceptionlessLog()
                //{ Message = "__测试一下对不对", Property = "__test", PropertyName = "__test1", Tag = "__test2", UserId = "__003" };
                //var data = new List<ExceptionlessLog>();
                //data.Add(data3);
                //var data2 = new ExceptionlessLog()
                //{ Message = "测试一下对不对", Property = "test", PropertyName = "test1", Tag = "test2", UserId = "003", Data =data };
                //Exceptionless.ExceptionlessClient.Default.Log(data2);
                //throw new Warning("测试异常日志记录");
            }
            catch (Exception ex)
            {
                throw ex;
                //return new ApiResult(StateCode.Fail, "错误", new { data = ex.Message, date = DateTime.Now, context = context, context2 = _context.HttpContext.TraceIdentifier });
            }
        }

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public ActionResult<string> Get(int id)
        //{
        //    return "value";
        //}

        // POST api/values
        [HttpPost]
        public virtual async Task<IActionResult> Post()
        {
            var context = _context.HttpContext.TraceIdentifier;
            try
            {
                //NLog.LogManager.GetLogger("Debug").Error("GET" + context);
                var dta=await _order.RetrieveByIdAsync("39f2bfc3a01305267446d2a9c420157a");
                return Success(dta);
            }
            catch (Exception ex)
            {
                throw ex;
                //return new ApiResult(StateCode.Fail, "错误", new { data = ex.Message, date = DateTime.Now, context = context, context2 = _context.HttpContext.TraceIdentifier });
            }
        }


        [HttpPost("post2")]
        public async Task<IActionResult> Post2(OrdersDto dto)
        {
            var context = _context.HttpContext.TraceIdentifier;
            try
            {
                //NLog.LogManager.GetLogger("Debug").Error("GET" + context);
                await _pamentServcice.RefundsAuditAsync(dto);
                return Success("");
            }
            catch (Exception ex)
            {
                throw ex;
                //return new ApiResult(StateCode.Fail, "错误", new { data = ex.Message, date = DateTime.Now, context = context, context2 = _context.HttpContext.TraceIdentifier });
            }
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }

    public class Test1
    {

        public Test1()
        {
            Test4 = new List<Test4>();
        }
        public string MyProperty { get; set; }
        public string MyProperty2 { get; set; }
        public string MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public DateTime MyProperty5 { get; set; }
        [Map("Test4")]
        public List<Test4> Test4 { get; set; }

    }

    public class Test3
    {
        public string MyProperty { get; set; }
        public string MyProperty2 { get; set; }
        public string MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public DateTime MyProperty5 { get; set; }
        [Map("Test5")]
        public List<Test5> Test4 { get; set; }
    }
    public class Test5
    {
        public string MyProperty { get; set; }
        public string MyProperty2 { get; set; }
        public string MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public DateTime MyProperty5 { get; set; }
    }

    public class Test4
    {
        public string MyProperty { get; set; }
        public string MyProperty2 { get; set; }
        public string MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public DateTime MyProperty5 { get; set; }
    }
}
