﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Sand.Mongo;
using Sand.Mongo.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    public interface IMongoTest : IMongoService<TestEntiy>
    {
    }
    public class MongoTest : MongoService<TestEntiy>, IMongoTest
    {
        public MongoTest()
        {

        }
    }
    [ConnectionName("MongoConnection")]
    public class TestEntiy : MongoEntity
    {
    }

    public class TestEntiy3
    {
        /// <summary>
        /// 主键
        /// </summary>
        [BsonElement(Order = 0)]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        /// <summary>
        /// 租户编号
        /// </summary>
        public virtual string TenantId { get; set; }
        /// <summary>
        /// 门店号
        /// </summary>
        public virtual string StroeId { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        private DateTime _createdOn { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        [BsonElement("_c", Order = 1)]
        //[BsonRepresentation(BsonType.DateTime)]
        //[BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public virtual DateTime CreateTime
        {
            get
            {
                if (_createdOn == null || _createdOn == DateTime.MinValue)
                    _createdOn = ObjectId.CreationTime;
                return _createdOn;
            }
            set
            {
                _createdOn = value;
            }
        }

        /// <summary>
        /// 创建者
        /// </summary>
        public virtual string CreateId { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public virtual string CreateName { get; set; }
        /// <summary>
        /// 最近更新时间
        /// </summary>
        [BsonRepresentation(BsonType.DateTime)]
        public virtual DateTime LastUpdateTime { get; set; }
        /// <summary>
        /// 最近更新者
        /// </summary>
        public virtual string LastUpdateId { get; set; }
        /// <summary>
        /// 最近更新人
        /// </summary>
        [BsonElement("_m", Order = 2)]
        //[BsonRepresentation(BsonType.DateTime)]
        public virtual string LastUpdateName { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        public virtual bool IsEnable { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public virtual int Status { get; set; }
        /// <summary>
        /// 版本号
        /// </summary>
        public virtual string Version { get; set; }
        /// <summary>
        /// 批量更新使用编号应该和主键相同
        /// </summary>
        [BsonIgnore]
        public virtual string BatchUpdateId { get { return this.Id; } }
        /// <summary>
        /// mongo数据库唯一识别号
        /// </summary>
        [BsonIgnore]
        public ObjectId ObjectId => ObjectId.Parse(Id);
    }
}
