﻿using Dapper.Contrib.Extensions;
using Sand.Result;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// 自诊信息表
    /// </summary>
    [Table("SelfDiagnosis")]
    public class SelfDiagnosisDto
    {
        /// <summary>
        /// 
        /// </summary>
        public SelfDiagnosisDto()
        {

        }
        /// <summary>
        /// 编号
        /// </summary>
        [ExplicitKey]
        public string Id { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
       public DateTime CreateTime { get; set; }
        /// <summary>
        /// 创建者
        /// </summary>
        public string CreateId { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public string CreateName { get; set; }
        /// <summary>
        /// 最近更新时间
        /// </summary>
        public DateTime LastUpdateTime { get; set; }
        /// <summary>
        /// 最近更新者
        /// </summary>
        public string LastUpdateId { get; set; }
        /// <summary>
        /// 最近更新人
        /// </summary>
        public string LastUpdateName { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        public bool IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 版本号
        /// </summary>
        public string Version { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        public string OrdersId { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 其他症状描述
        /// </summary>
        public string Other { get; set; }
        /// <summary>
        /// 图片
        /// </summary>
        [Computed]
        public List<ResultFile> ImageList { get; set; }
        /// <summary>
        /// 视频
        /// </summary>
        [Computed]

        public List<ResultFile> VideoList { get; set; }
    }
}
