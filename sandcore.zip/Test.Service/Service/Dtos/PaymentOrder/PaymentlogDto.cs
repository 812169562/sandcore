﻿using System;
using Sand.Service; 
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;

namespace Sand.Service.Dtos.PaymentOrder {
    /// <summary>
    /// 支付日志数据传输对象
    /// </summary>
    [DataContract]
    public class PaymentlogDto : BaseDto {
        /// <summary>
        /// 支付编号
        /// </summary>
        [StringLength( 9, ErrorMessage = "输入过长，不能超过9位" )]
        [Display( Name = "" )]
        [DataMember]
        public string PaymentId { get; set; }
        
        /// <summary>
        /// 支付总金额(退费时为负数,分为单位）
        /// </summary>
        [Display( Name = "支付总金额(退费时为负数,分为单位）" )]
        [DataMember]
        public int? Amount { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        [DataMember]
        public decimal Money => Amount == null ? 0 : (decimal)Amount / 100;

        /// <summary>
        /// 传入参数
        /// </summary>
        [StringLength( 4095, ErrorMessage = "传入参数输入过长，不能超过4095位" )]
        [Display( Name = "传入参数" )]
        [DataMember]
        public string Input { get; set; }
        
        /// <summary>
        /// 返回数据
        /// </summary>
        [StringLength( 4095, ErrorMessage = "返回数据输入过长，不能超过4095位" )]
        [Display( Name = "返回数据" )]
        [DataMember]
        public string Output { get; set; }
        
        /// <summary>
        /// 支付变化情况
        /// </summary>
        [StringLength( 4095, ErrorMessage = "支付变化情况输入过长，不能超过4095位" )]
        [Display( Name = "支付变化情况" )]
        [DataMember]
        public string PaymentChargeLog { get; set; }
        
        /// <summary>
        /// Ip
        /// </summary>
        [StringLength( 25, ErrorMessage = "Ip输入过长，不能超过25位" )]
        [Display( Name = "Ip" )]
        [DataMember]
        public string Ip { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [Display(Name = "订单状态")]
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 支付状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((PaymentStatus)Status).Description();
        /// <summary>
        /// 创建人
        /// </summary>
        [DataMember]
        public override string CreateName { get; set; }

    }
}
