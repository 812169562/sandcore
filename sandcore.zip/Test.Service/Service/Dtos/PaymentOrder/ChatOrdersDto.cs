﻿using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// 在线问诊订单表传输对象
    /// </summary>
    [DataContract]
    [Serializable]
    public class ChatOrdersDto : BaseDto
    {
        /// <summary>
        /// 医生编号
        /// </summary>
        [StringLength(36, ErrorMessage = "医生编号输入过长，不能超过36位")]
        [Display(Name = "医生编号")]
        [DataMember]
        public string UserId { get; set; }
        /// <summary>
        /// 医生姓名
        /// </summary>
        [Display(Name = "医生姓名")]
        [DataMember]
        public string UserName { get; set; }

        /// <summary>
        /// 患者编号
        /// </summary>
        [StringLength(36, ErrorMessage = "患者编号输入过长，不能超过36位")]
        [Display(Name = "患者编号")]
        [DataMember]
        public string PatientId { get; set; }

        /// <summary>
        /// 患者姓名
        /// </summary>
        [Display(Name = "患者姓名")]
        [DataMember]
        public string PatientName { get; set; }

        /// <summary>
        /// 科室
        /// </summary>
        [Display(Name = "科室")]
        [DataMember]
        public string DepartmentName { get; set; }

        /// <summary>
        /// 科室Id
        /// </summary>
        [StringLength(36, ErrorMessage = "患者编号输入过长，不能超过36位")]
        [Display(Name = "科室Id")]
        [DataMember]
        public string DepartmentId { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        [Display(Name = "编码")]
        [DataMember]
        public string Code { get; set; }

        /// <summary>
        /// 职称
        /// </summary>
        [Display(Name = "职称")]
        [DataMember]
        public string Title { get; set; }

        /// <summary>
        /// 订单状态(0失效,1待付款,2已支付,3已完成)
        /// </summary>
        [Display(Name = "订单状态(0失效,1待付款,2已支付,3已完成)")]
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((OrdersStatus)Status).DisplayName();

        /// <summary>
        /// 类型(1图文,2电话,3视频)
        /// </summary>
        [Display(Name = "类型(1图文,2电话,3视频)")]
        [DataMember]
        public int Type { get; set; }
        /// <summary>
        /// 类型
        /// </summary>
        [DataMember]
        public string TypeStr => ((ChatOrdersType)Type).DisplayName();

        /// <summary>
        /// 开始时间
        /// </summary>
        [Display(Name = "开始时间")]
        [DataMember]
        public DateTime? BeginTime { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        [DataMember]
        public string BeginTimeStr => BeginTime.ToDateString();

        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [StringLength(15, ErrorMessage = "支付平台订单号输入过长，不能超过15位")]
        [Display(Name = "支付平台订单号")]
        [DataMember]
        public string TradeNo { get; set; }

        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength(15, ErrorMessage = "系统订单号输入过长，不能超过15位")]
        [Display(Name = "系统订单号")]
        [DataMember]
        public string OutTradeNo { get; set; }

        /// <summary>
        /// 订单支付时间
        /// </summary>
        [Display(Name = "订单支付时间")]
        [DataMember]
        public DateTime? PayTime { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        [Display(Name = "支付金额")]
        [DataMember]
        public int? Money { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Display(Name = "结束时间")]
        [DataMember]
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        [DataMember]
        public string EndTimeStr => EndTime.ToDateString();
    }
}
