﻿using System;
using Sand.Service;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;
using System.Collections.Generic;
using Sand.Result;
using Sand.Domain.MqttData;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// convenientorder数据传输对象
    /// </summary>
    [DataContract]
    public class ConvenientorderDto : BaseDto
    {
        /// <summary>
        /// 就诊卡编号
        /// </summary>
        [StringLength(9, ErrorMessage = "就诊卡编号输入过长，不能超过9位")]
        [Display(Name = "就诊卡编号")]
        [DataMember]
        public string CardId { get; set; }

        /// <summary>
        /// HIS挂号费用记录编号
        /// </summary>
        [StringLength(9, ErrorMessage = "HIS挂号费用记录编号输入过长，不能超过9位")]
        [Display(Name = "HIS挂号费用记录编号")]
        [DataMember]
        public string RegisterChargeId { get; set; }

        /// <summary>
        /// HIS费用表信息
        /// </summary>
        [StringLength(4095, ErrorMessage = "HIS费用表信息输入过长，不能超过4095位")]
        [Display(Name = "HIS费用表信息")]
        [DataMember]
        public string ChargeJson { get; set; }

        /// <summary>
        /// HIS费用明细表信息
        /// </summary>
        [StringLength(4095, ErrorMessage = "HIS费用明细表信息输入过长，不能超过4095位")]
        [Display(Name = "HIS费用明细表信息")]
        [DataMember]
        public string ChargeDetalisJson { get; set; }

        /// <summary>
        /// 类型（1.便民 2.拍方抓药）
        /// </summary>
        [Display(Name = "类型（1.便民 2.拍方抓药）")]
        [DataMember]
        public int? Type { get; set; }

        /// <summary>
        /// 医生编号
        /// </summary>
        [StringLength(9, ErrorMessage = "医生编号输入过长，不能超过9位")]
        [Display(Name = "医生编号")]
        [DataMember]
        public string UserId { get; set; }

        /// <summary>
        /// 审核时间
        /// </summary>
        [Display(Name = "审核时间")]
        [DataMember]
        public DateTime? AuditTime { get; set; }

        /// <summary>
        /// 审核人编号
        /// </summary>
        [StringLength(9, ErrorMessage = "审核人编号输入过长，不能超过9位")]
        [Display(Name = "审核人编号")]
        [DataMember]
        public string AuditId { get; set; }

        /// <summary>
        /// 审核人名字
        /// </summary>
        [StringLength(12, ErrorMessage = "审核人名字输入过长，不能超过12位")]
        [Display(Name = "审核人名字")]
        [DataMember]
        public string AuditName { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        [StringLength(125, ErrorMessage = "备注输入过长，不能超过125位")]
        [Display(Name = "备注")]
        [DataMember]
        public string Remark { get; set; }

        /// <summary>
        /// 图片编号
        /// </summary>
        [StringLength(9, ErrorMessage = "图片编号输入过长，不能超过9位")]
        [Display(Name = "图片编号")]
        [DataMember]
        public string ImageNewName { get; set; }

        /// <summary>
        /// 数量
        /// </summary>
        [Display(Name = "数量")]
        [DataMember]
        public int? Count { get; set; }

        /// <summary>
        /// 药品类型（1.饮片2.小包装3.免煎）
        /// </summary>
        [Display(Name = "药品类型（1.饮片2.小包装3.免煎）")]
        [DataMember]
        public int? DrugType { get; set; }
        /// <summary>
        /// 药品类型（1.饮片2.小包装3.免煎）
        /// </summary>
        [Display(Name = "药品类型（1.饮片2.小包装3.免煎）")]
        [DataMember]
        public string DrugTypeStr => ((DrugType)(DrugType ?? 0)).Description();

        /// <summary>
        /// 处方类型(1.中药2.西药)
        /// </summary>
        [Display(Name = "处方类型(1.中药2.西药)")]
        [DataMember]
        public int? PrescriptionType { get; set; }

        /// <summary>
        /// 状态(1.待审核2.审核通过3.未通过)
        /// </summary>
        [Display(Name = "状态(1.待审核2.审核通过3.未通过)")]
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 项目名称
        /// </summary>
        [Display(Name = "项目名称")]
        [DataMember]
        public string ItemName { get; set; }
        /// <summary>
        /// 审核备注
        /// </summary>
        [Display(Name = "审核备注")]
        [DataMember]
        public string AuditRemark { get; set; }
        /// <summary>
        /// 是否配送
        /// </summary>
        [Display(Name = "是否配送")]
        [DataMember]
        public bool? IsDelivery { get; set; }
        /// <summary>
        /// 是否配送
        /// </summary>
        [DataMember]
        public string IsDeliveryStr => IsDelivery.ToIsOrNot();
        /// <summary>
        /// 是否代煎
        /// </summary>
        [Display(Name = "是否代煎")]
        [DataMember]
        public bool? IsDecocting { get; set; }
        /// <summary>
        /// 是否代煎
        /// </summary>
        [DataMember]
        public string IsDecoctingStr => IsDecocting.ToIsOrNot();
        /// <summary>
        /// 收货人
        /// </summary>
        [Display(Name = "收货人")]
        [DataMember]
        public string Consignee { get; set; }
        /// <summary>
        /// 收货人电话
        /// </summary>
        [Display(Name = "收货人电话")]
        [DataMember]
        public string Tel { get; set; }
        /// <summary>
        /// 收货人地址
        /// </summary>
        [Display(Name = "收货人地址")]
        [DataMember]
        public string Address { get; set; }
        /// <summary>
        /// 快递单号
        /// </summary>
        [Display(Name = "快递单号")]
        [DataMember]
        public string CourierNumber { get; set; }
        /// <summary>
        /// 快递
        /// </summary>
        [Display(Name = "快递")]
        [DataMember]
        public string ExpressId { get; set; }
        /// <summary>
        /// 快递名称
        /// </summary>
        [Display(Name = "快递名称")]
        [DataMember]
        public string ExpressName { get; set; }
        /// <summary>
        /// 是否当日送达(1.是 0.否)
        /// </summary>
        [Display(Name = "是否当日送达")]
        [DataMember]
        public int? IsSamedayDelivery { get; set; }
        /// <summary>
        /// 是否当日送达
        /// </summary>
        [DataMember]
        public string IsSamedayDeliveryStr => IsSamedayDelivery == 1 ? "是" : "否";
        /// <summary>
        /// 煎服法
        /// </summary>
        [DataMember]
        public string Use { get; set; }
        /// <summary>
        /// 煎服法
        /// </summary>
        [DataMember]
        public string UseStr { get; set; }
        /// <summary>
        /// HIS订单号
        /// </summary>
        [DataMember]
        public string ChargeNo { get; set; }
        /// <summary>
        /// 原开方医生
        /// </summary>
        [DataMember]
        public string OriginalDoctor { get; set; }
        /// <summary>
        /// 原开方医院
        /// </summary>
        [DataMember]
        public string OriginalHospital { get; set; }
        /// <summary>
        /// 原开方诊断
        /// </summary>
        [DataMember]
        public string OriginalDiagnosis { get; set; }
        /// <summary>
        /// 患者联系电话
        /// </summary>
        [DataMember]
        public string PatientTel { get; set; }

        #region 扩展
        /// <summary>
        /// 创建人
        /// </summary>
        [DataMember]
        public override string CreateId { get => base.CreateId; set => base.CreateId = value; }
        /// <summary>
        /// 审核时间
        /// </summary>
        [DataMember]
        public string AuditTimeStr => AuditTime.ToDateTimeString(true);
        /// <summary>
        /// 状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((ConvenientOrderStatus)Status).Description();
        /// <summary>
        /// 患者卡号
        /// </summary>
        [DataMember]
        public string CardNo { get; set; }
        /// <summary>
        /// 患者名字
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 项目类型
        /// </summary>
        [DataMember]
        public int ItemType { get; set; }
        /// <summary>
        /// 项目类型
        /// </summary>
        [DataMember]
        public string ItemTypeStr
        {
            get
            {
                switch (ItemType)
                {
                    case 1:
                        return "检验";
                    case 2:
                        return "检查";
                    case 3:
                        return "治疗";
                    case 4:
                        return "西药";
                    default:
                        return "";
                }
            }
        }
        /// <summary>
        /// 金额
        /// </summary>
        [DataMember]
        public string Money { get; set; }
        /// <summary>
        /// 医生名称
        /// </summary>
        [DataMember]
        public string UserName { get; set; }
        /// <summary>
        /// 费用明细
        /// </summary>
        [DataMember]
        public List<ChargeInfoModel> ChargeInfo { get; set; }
        /// <summary>
        /// 图片文件信息
        /// </summary>
        [Display(Name = "图片")]
        [DataMember]
        public ResultFile ImgFile { get; set; }
        /// <summary>
        /// 图片地址
        /// </summary>
        [DataMember]
        public string ImageUrl { get; set; }
        /// <summary>
        /// 执行科室名称
        /// </summary>
        [DataMember]
        public string ExecDepartmentName { get; set; }
        /// <summary>
        /// 执行科室ID
        /// </summary>
        [DataMember]
        public string ExecDepartmentID { get; set; }
        /// <summary>
        /// 药品信息(拍方抓药)
        /// </summary>
        [DataMember]
        public List<GoodsInventoryResult> GoodsList { get; set; }
        /// <summary>
        /// 挂号记录订单编号
        /// </summary>
        [DataMember]
        public string OrdersId { get; set; }
        /// <summary>
        /// 药品、收费项目信息（便民门诊）
        /// </summary>
        [DataMember]
        public List<ChargeItemResult> ChargeItemList { get; set; }
        #endregion
    }
    /// <summary>
    /// 
    /// </summary>
    public class ChargeModel
    {
        /// <summary>
        /// 
        /// </summary>
        public int Index { get; set; }
        /// <summary>
        /// 收费项目编号
        /// </summary>
        public string fstrItemID { get; set; }
        /// <summary>
        /// 收费项目名称
        /// </summary>
        public string fstrItemName { get; set; }
        /// <summary>
        /// 收费类型
        /// </summary>
        public int flngType { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal fmnyPrice { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int flngCount { get; set; }
        /// <summary>
        /// 缴费金额
        /// </summary>
        public decimal fmnyPayMoney { get; set; }
        /// <summary>
        /// 执行科室名称
        /// </summary>
        public string ExecDepartmentName { get; set; }
        /// <summary>
        /// 执行科室ID
        /// </summary>
        public string ExecDepartmentID { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string fstrRemark { get; set; }
        /// <summary>
        /// 收费表ID
        /// </summary>
        public string fstrChargeID { get; set; }
        /// <summary>
        /// 便民订单号
        /// </summary>
        public string fstrConvenientOrderId { get; set; }
        /// <summary>
        /// 便民订单标志(1便民门诊2.拍方抓药)
        /// </summary>
        public int flngConvenientOrderSign { get; set; }
        /// <summary>
        /// 收费流水号
        /// </summary>
        public string fstrChargeNo { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class ChargeInfoModel
    {
        /// <summary>
        /// 收费表ID
        /// </summary>
        public string fstrChargeID { get; set; }
        /// <summary>
        /// 项目ID
        /// </summary>
        public string fstrLinkID { get; set; }
        /// <summary>
        /// 项目名称
        /// </summary>
        public string fstrName { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal fmnyPrice { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int flngCount { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string fstrUnit { get; set; }
        /// <summary>
        /// 规格
        /// </summary>
        public string fstrFormat { get; set; }
        /// <summary>
        /// 科目编码
        /// </summary>
        public string fstrCode { get; set; }
        /// <summary>
        /// 根级科目名称
        /// </summary>
        public string fstrFirstName { get; set; }
        /// <summary>
        /// 根级科目编码
        /// </summary>
        public string fstrFirstCode { get; set; }
        /// <summary>
        /// 二级科目名称
        /// </summary>
        public string fstrSecondName { get; set; }
        /// <summary>
        /// 二级科目编码
        /// </summary>
        public string fstrSecondCode { get; set; }
        /// <summary>
        /// 成本价
        /// </summary>
        public decimal fmnyCost { get; set; }
        /// <summary>
        /// 包装数量
        /// </summary>
        public int PackCount { get; set; }
        /// <summary>
        /// 包装单位
        /// </summary>
        public string PackUnit { get; set; }
        /// <summary>
        /// 备注（如：先煎、后下）
        /// </summary>
        public string fstrRemark { get; set; }
        /// <summary>
        /// 顺序号
        /// </summary>
        public int flngOrderBy { get; set; }
        /// <summary>
        /// 类型：1.收费项目 2.药品
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 包装价格
        /// </summary>
        public decimal PackPrice { get; set; }
    }
}
