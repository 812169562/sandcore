﻿using System;
using Sand.Service; 
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;

namespace Sand.Service.Dtos.PaymentOrder {
    /// <summary>
    /// OrdersLog订单日志表数据传输对象
    /// </summary>
    [DataContract]
    public class OrderslogDto : BaseDto {
        /// <summary>
        /// 订单编号情况
        /// </summary>
        [StringLength( 4095, ErrorMessage = "订单编号情况输入过长，不能超过4095位" )]
        [Display( Name = "订单编号情况" )]
        [DataMember]
        public string OrdersChargeLog { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [StringLength(36, ErrorMessage = "订单编号输入过长，不能超过36位")]
        [Display(Name = "订单编号")]
        [DataMember]

        public string OrdersId { get; set; }
        /// <summary>
        /// 订单状态(0失效,1,待付款,2已支付,3已完成,-1退款中,-2退款完成,-3已取消)
        /// </summary>
        [Display(Name = "订单状态")]
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((OrdersStatus)Status).DisplayName();
        /// <summary>
        /// 创建人
        /// </summary>
        [DataMember]
        public override string CreateName { get; set; }

    }
}
