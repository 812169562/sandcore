﻿using System;
using Sand.Service;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Sand.Extensions;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// 用户评价表数据传输对象
    /// </summary>
    [DataContract]
    public class UserevaluationDto : BaseDto
    {
        /// <summary>
        /// 订单编号
        /// </summary>
        [StringLength(9, ErrorMessage = "订单编号输入过长，不能超过9位")]
        [Display(Name = "订单编号")]
        [DataMember]
        public string OrdersId { get; set; }

        /// <summary>
        /// 用户编号
        /// </summary>
        [StringLength(9, ErrorMessage = "用户编号输入过长，不能超过9位")]
        [Display(Name = "用户编号")]
        [DataMember]
        public string UserId { get; set; }

        /// <summary>
        ///  星级
        /// </summary>
        [Required(ErrorMessage = "请填写 星级")]
        [Display(Name = " 星级")]
        [DataMember]
        public int Star { get; set; }

        /// <summary>
        /// 评语
        /// </summary>
        [StringLength(250, ErrorMessage = "评语输入过长，不能超过250位")]
        [Display(Name = "评语")]
        [DataMember]
        public string Comment { get; set; }

        /// <summary>
        /// 是否匿名
        /// </summary>
        [Display(Name = "是否匿名")]
        [DataMember]
        public bool? IsAnonymous { get; set; }
        /// <summary>
        /// 订单情况
        /// </summary>
        [DataMember]
        public string Details { get; set; }
        /// <summary>
        /// 挂号信息
        /// </summary>
        [DataMember]
        public Register Register
        {
            get
            {
                if (!string.IsNullOrEmpty(Details))
                    return JsonConvert.DeserializeObject<Register>(Details);
                return new Register();
            }
        }
        /// <summary>
        /// 患者名称
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 卡号
        /// </summary>
        [DataMember]
        public string CardNo { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        [DataMember]
        public override string CreateName { get; set; }

        /// <summary>
        /// 医生名称
        /// </summary>
        [DataMember]
        public string UserName { get; set; }
        /// <summary>
        /// 类型(1.就诊评论2.咨询评论)
        /// </summary>
        [DataMember]
        public int Type { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        [DataMember]
        public string name => CreateName.IsEmpty() ? "" : ((IsAnonymous ?? false) ? CreateName.Substring(0, 1) + "**" : CreateName);
        /// <summary>
        /// 医生头像
        /// </summary>
        [DataMember]
        public string DoctorAvatarUrl { get; set; }
        /// <summary>
        /// 患者头像
        /// </summary>
        [DataMember]
        public string CardAvatarUrl { get; set; }
        /// <summary>
        /// 患者性别
        /// </summary>
        [DataMember]
        public int CardSex { get; set; }

    }
}
