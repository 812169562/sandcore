﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// 
    /// </summary>
    public class ConsultationPayDto
    {
        /// <summary>
        /// 订单编号
        /// </summary>
        public string OrdersId { get; set; }
        /// <summary>
        /// 1网络咨询 2网络门诊
        /// </summary>
        public int ServiceType { get; set; }
        /// <summary>
        ///  初诊挂号编号
        /// </summary>
        public string FirstVisitRegisterID { get; set; }
    }
}
