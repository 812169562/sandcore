﻿using System;
using Sand.Service; 
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Collections.Generic;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;

namespace Sand.Service.Dtos.PaymentOrder {
    /// <summary>
    ///  第三方支付信息数据传输对象
    /// </summary>
    [DataContract]
    public class PaymentDto : BaseDto {

        /// <summary>
        /// 支付者
        /// </summary>
        [StringLength( 9, ErrorMessage = "支付者输入过长，不能超过9位" )]
        [Display( Name = "支付者" )]
        [DataMember]
        public string PayUserId { get; set; }
        
        /// <summary>
        /// 支付者
        /// </summary>
        [StringLength( 37, ErrorMessage = "支付者输入过长，不能超过37位" )]
        [Display( Name = "支付者" )]
        [DataMember]
        public string PayUserName { get; set; }
        
        /// <summary>
        /// 支付时间
        /// </summary>
        [Display( Name = "支付时间" )]
        [DataMember]
        public DateTime? PayDate { get; set; }
        /// <summary>
        /// 支付时间
        /// </summary>
        [DataMember]
        public string PayDateStr => PayDate.ToDateTimeString();

        /// <summary>
        /// 支付类型(1,Web,2.App,3小程序,4.Wap)
        /// </summary>
        [Display( Name = "支付类型(1,Web,2.App,3小程序,4.Wap)" )]
        [DataMember]
        public int? PayType { get; set; }
        /// <summary>
        /// 支付状态
        /// </summary>
        [DataMember]
        public string PayTypeStr => PayType == null ? "" : ((PayType)PayType).DisplayName();

        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        [Display( Name = "支付金额（分为单位）" )]
        [DataMember]
        public int? Amount { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        [DataMember]
        public decimal Money => Amount == null ? 0 : (decimal)Amount / 100;

        /// <summary>
        /// 已退费金额（分为单位）
        /// </summary>
        [Display( Name = "已退费金额（分为单位）" )]
        [DataMember]
        public int? RefundAmount { get; set; }
        /// <summary>
        /// 已退费金额
        /// </summary>
        [DataMember]
        public decimal RefundMoney => RefundAmount == null ? 0 : (decimal)RefundAmount / 100;

        /// <summary>
        /// 确认已支付金额（分为单位）
        /// </summary>
        [Display( Name = "确认已支付金额（分为单位）" )]
        [DataMember]
        public int? ComfirmAmount { get; set; }
        
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [StringLength( 15, ErrorMessage = "支付平台订单号输入过长，不能超过15位" )]
        [Display( Name = "支付平台订单号" )]
        [DataMember]
        public string TradeNo { get; set; }
        
        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength( 15, ErrorMessage = "系统订单号输入过长，不能超过15位" )]
        [Display( Name = "系统订单号" )]
        [DataMember]
        public string OutTradeNo { get; set; }
        
        /// <summary>
        /// 支付平台(1,微信,2,支付宝,3银联,4.QQ)
        /// </summary>
        [Display( Name = "支付平台(1,微信,2,支付宝,3银联,4.QQ)" )]
        [DataMember]
        public int? PayPlatform { get; set; }
        /// <summary>
        /// 支付状态
        /// </summary>
        [DataMember]
        public string PayPlatformStr => PayPlatform == null ? "" : ((PayPlatformType)PayPlatform).DisplayName();
        /// <summary>
        /// 支付状态(0支付失效,1,等待支付,2支付成功,3部分退费,4完成退费)
        /// </summary>
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 支付状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((PaymentStatus)Status).DisplayName();
        /// <summary>
        /// 支付日志
        /// </summary>
        [DataMember]
        public List<PaymentlogDto> Paymentlog { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ThirdUniqueId { get; set; }
    }
}
