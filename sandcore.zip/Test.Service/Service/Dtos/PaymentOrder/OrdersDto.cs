﻿using System;
using Sand.Service;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;
using System.Collections.Generic;
using Sand.Domain.MqttData;

namespace Sand.Service.Dtos.PaymentOrder
{
    /// <summary>
    /// 订单表数据传输对象
    /// </summary>
    [DataContract]
    [Serializable]
    public class OrdersDto : BaseDto
    {
        /// <summary>
        /// 预约编号(此处HIS tbReservation ID)
        /// </summary>
        [StringLength(36, ErrorMessage = "预约编号输入过长，不能超过36位")]
        [DataMember]
        public string ReservationID { get; set; }
        /// <summary>
        /// 外部编号(此处HISId)
        /// </summary>
        [StringLength(36, ErrorMessage = "外部编号(此处HISId)输入过长，不能超过36位")]
        [Display(Name = "外部编号(此处HISId)")]
        [DataMember]
        public string OutId { get; set; }

        /// <summary>
        /// 患者编号
        /// </summary>
        [StringLength(36, ErrorMessage = "患者编号输入过长，不能超过36位")]
        [Display(Name = "患者编号")]
        [DataMember]
        public string CardId { get; set; }

        /// <summary>
        /// 患者编号(外部系统编号和CardId1-1)
        /// </summary>
        [StringLength(36, ErrorMessage = "患者编号(外部系统编号和CardId1-1)输入过长，不能超过36位")]
        [Display(Name = "患者编号(外部系统编号和CardId1-1)")]
        [DataMember]
        public string OutPatientId { get; set; }

        /// <summary>
        /// 类型(1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目)
        /// </summary>
        [Display(Name = "类型(1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目)")]
        [DataMember]
        public int Type { get; set; }
        /// <summary>
        /// 类型
        /// </summary>
        [DataMember]
        public string TypeStr => ((OrdersType)Type).DisplayName();

        /// <summary>
        /// 支付编号
        /// </summary>
        [StringLength(9, ErrorMessage = "支付编号输入过长，不能超过9位")]
        [Display(Name = "支付编号")]
        [DataMember]
        public string PaymentId { get; set; }

        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [StringLength(15, ErrorMessage = "支付平台订单号输入过长，不能超过15位")]
        [Display(Name = "支付平台订单号")]
        [DataMember]
        public string TradeNo { get; set; }

        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength(15, ErrorMessage = "系统订单号输入过长，不能超过15位")]
        [Display(Name = "系统订单号")]
        [DataMember]
        public string OutTradeNo { get; set; }

        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        [Display(Name = "支付金额（分为单位）")]
        [DataMember]
        public int Amount { get; set; }

        /// <summary>
        /// 备注信息
        /// </summary>
        [StringLength(50, ErrorMessage = "备注信息输入过长，不能超过50位")]
        [Display(Name = "备注信息")]
        [DataMember]
        public string Remark { get; set; }
        /// <summary>
        /// 订单状态(0失效,1,待付款,2已支付,3已完成,-1退款中,-2退款完成,-3已取消)
        /// </summary>
        [Display(Name = "订单状态")]
        [DataMember]
        public int Status { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [DataMember]
        public string StatusStr => ((OrdersStatus)Status).DisplayName();

        /// <summary>
        /// 订单情况
        /// </summary>
        [StringLength(4095, ErrorMessage = "订单情况输入过长，不能超过4095位")]
        [Display(Name = "订单情况")]
        [DataMember]
        public string Details { get; set; }
        /// <summary>
        /// 坐诊ID
        /// </summary>
        [DataMember]
        public string SittingId { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [DataMember]
        public string Title { get; set; }
        /// <summary>
        /// 医生名称
        /// </summary>
        [DataMember]
        public string UserName { get; set; }
        /// <summary>
        /// 挂号信息
        /// </summary>
        [DataMember]
        public Register Register
        {
            get
            {
                if (!string.IsNullOrEmpty(Details) && Type == OrdersType.Register.Value())
                    return JsonConvert.DeserializeObject<Register>(Details);
                return new Register();
            }
        }

        /// <summary>
        /// 门诊费用信息
        /// </summary>
        [DataMember]
        public Outpatient Outpatient
        {
            get
            {
                if (!string.IsNullOrEmpty(Details) && Type != OrdersType.Register.Value())
                    return JsonConvert.DeserializeObject<Outpatient>(Details);
                return new Outpatient();
            }
        }
        /// <summary>
        /// 项目名称
        /// </summary>
        [DataMember]
        public string ItemName { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [DataMember]
        public decimal Money { get; set; }
        /// <summary>
        /// 患者名称
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 卡号
        /// </summary>
        [DataMember]
        public string CardNo { get; set; }
        /// <summary>
        /// 联系电话
        /// </summary>
        [DataMember]
        public string Tel { get; set; }
        /// <summary>
        /// 支付时间
        /// </summary>
        [DataMember]
        public DateTime? PayDate { get; set; }
        /// <summary>
        /// 支付时间
        /// </summary>
        [DataMember]
        public string PayDateStr => PayDate.ToDateTimeString();
        /// <summary>
        /// 支付时间
        /// </summary>
        [DataMember]
        public string PayDateString => PayDate.ToDateString();
        /// <summary>
        /// 支付者
        /// </summary>
        [DataMember]
        public string PayUserName { get; set; }
        /// <summary>
        /// 是否显示取消
        /// </summary>
        [DataMember]
        public bool ShowCancel => this.Status == OrdersStatus.Paymented.Value() && Register.SittingDate >= DateTime.Now.ToDateString().ToDate();

        /// <summary>
        /// 申请退款时间
        /// </summary>
        public DateTime ApplicationTime { get; set; }
        /// <summary>
        /// 申请退款时间
        /// </summary>
        [DataMember]
        public string ApplicationTimeStr => ApplicationTime.ToDateTimeString();
        /// <summary>
        /// 就诊时间
        /// </summary>
        [DataMember]
        public DateTime? SittingDate { get; set; }
        /// <summary>
        /// 医生编号
        /// </summary>
        [DataMember]
        public string UserId { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        [DataMember]
        public int RefundStatus { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [DataMember]
        public string RefundStatusStr => RefundStatus == 0 ? "" : ((RefundStatus)RefundStatus).DisplayName();
        /// <summary>
        /// 退款失败原因
        /// </summary>
        [DataMember]
        public string FailureReasons { get; set; }
        /// <summary>
        /// 是否便民挂号
        /// </summary>
        [DataMember]
        public bool IsConvenient { get; set; }
        /// <summary>
        /// 便民订单编号
        /// </summary>
        [DataMember]
        public string ConvenientOrderId { get; set; }
        /// <summary>
        /// 明细
        /// </summary>
        [DataMember]
        public List<ChargeInfo> Info { get; set; }
        /// <summary>
        /// 是否显示
        /// </summary>
        [DataMember]
        public bool IsShow { get; set; }
        /// <summary>
        /// 退款金额
        /// </summary>
        [DataMember]
        public int? RefundAmount { get; set; }
        /// <summary>
        /// 退款金额
        /// </summary>
        [DataMember]
        public decimal RefundMoney { get; set; }
        /// <summary>
        /// 是否退预约加收
        /// </summary>
        [DataMember]
        public bool? IsRefundSubscribe { get; set; }
        /// <summary>
        /// 医生头像
        /// </summary>
        [DataMember]
        public string AvatarUrl { get; set; }
    }

    /// <summary>
    /// 挂号
    /// </summary>
    [DataContract]
    [Serializable]
    public class Register
    {
        /// <summary>
        /// 预约编号
        /// </summary>
        [DataMember]
        public string ReservationID { get; set; }
        /// <summary>
        /// 类型（上午下午）
        /// </summary>
        [DataMember]
        public int DayType { get; set; }
        /// <summary>
        /// 类型（上午下午）
        /// </summary>
        [DataMember]
        public string DayTypeStr
        {
            get
            {
                switch (DayType)
                {
                    case 1:
                        return "上午";
                    case 2:
                        return "中午";
                    case 3:
                        return "下午";
                    case 4:
                        return "晚上";
                    default:
                        return "上午";
                }
            }
        }
        /// <summary>
        /// 医生名称
        /// </summary>
        [DataMember]
        public string UserName { get; set; }
        /// <summary>
        /// 医生编号
        /// </summary>
        [DataMember]
        public string UserId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [DataMember]
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [DataMember]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [DataMember]
        public string Title { get; set; }
        /// <summary>
        /// 坐诊地点
        /// </summary>
        [DataMember]
        public string SittingAddress { get; set; }
        /// <summary>
        /// 看诊时间
        /// </summary>
        [DataMember]
        public DateTime SittingDate { get; set; }
        /// <summary>
        /// 看诊时间
        /// </summary>
        [DataMember]
        public string SittingDateStr => SittingDate.ToDateString();
        /// <summary>
        /// 时间段
        /// </summary>
        [DataMember]
        public string TimeIntervalId { get; set; }
        /// <summary>
        /// 时间段
        /// </summary>
        [DataMember]
        public string TimeIntervalName { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [DataMember]
        public decimal Money { get; set; }
        /// <summary>
        /// 就诊使用号
        /// </summary>
        [DataMember]
        public int UseNo { get; set; }
        /// <summary>
        /// 就诊卡编号
        /// </summary>
        [DataMember]
        public string CardId { get; set; }
        /// <summary>
        /// 卡号
        /// </summary>
        [DataMember]
        public string CardNo { get; set; }
        /// <summary>
        /// 患者名称
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 预约加收费
        /// </summary>
        [DataMember]
        public decimal BookingMoney { get; set; }
    }

    /// <summary>
    /// 门诊费用
    /// </summary>
    [DataContract]
    [Serializable]
    public class Outpatient
    {
        /// <summary>
        /// 订单编号
        /// </summary>
        [DataMember]
        public string OrdersId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 医生名称
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [DataMember]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 科室地址
        /// </summary>
        [DataMember]
        public string DepartmentAddress { get; set; }
        /// <summary>
        /// 开单时间
        /// </summary>
        [DataMember]
        public DateTime Time { get; set; }
        /// <summary>
        /// 开单时间
        /// </summary>
        [DataMember]
        public string TimeStr { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [DataMember]
        public decimal Price { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        [DataMember]
        public int Count { get; set; }
        /// <summary>
        /// 总金额
        /// </summary>
        [DataMember]
        public decimal PayMoney { get; set; }
        /// <summary>
        /// 收费项目名称
        /// </summary>
        [DataMember]
        public string ItemName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ChargeId { get; set; }
        /// <summary>
        /// 患者名称
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string PatientId { get; set; }
        /// <summary>
        /// 患者卡号
        /// </summary>
        [DataMember]
        public string PatientNo { get; set; }
        /// <summary>
        /// 总金额
        /// </summary>
        [DataMember]
        public string Money => (Price * Count).ToString("f2");
        /// <summary>
        /// 药品类型
        /// </summary>
        [DataMember]
        public int? DrugType { get; set; }
        /// <summary>
        /// 组别号
        /// </summary>
        public string GroupNo { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        [DataMember]
        public string Remark { get; set; }
        /// <summary>
        /// 附加信息
        /// </summary>
        [DataMember]
        public string AdditionalInformation { get; set; }

    }
}
