﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Service.Dtos
{
    /// <summary>
    /// 
    /// </summary>
    public class ArrayData<T>
    {
        /// <summary>
        /// 
        /// </summary>
        public List<T> Data { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }
    }
}
