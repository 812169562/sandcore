﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Service;
using Sand.Extensions;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Contract.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;
using Microsoft.EntityFrameworkCore;

namespace Sand.Service.Impl.PaymentOrder {
    /// <summary>
    /// OrdersLog订单日志表服务
    /// </summary>
    public class OrderslogService : BaseService<OrderslogDto, OrderslogQuery,Orderslog>, IOrderslogService {
        /// <summary>
        /// OrdersLog订单日志表仓储
        /// </summary>
        private readonly IOrderslogRepository _orderslogRepository;
        
        /// <summary>
        /// 初始化OrdersLog订单日志表服务
        /// </summary>
        
        /// <param name="orderslogRepository">OrdersLog订单日志表仓储</param>
        public OrderslogService( IOrderslogRepository orderslogRepository)
            : base(orderslogRepository ) {
           _orderslogRepository = orderslogRepository;
        }
        
         /// <summary>
        /// 创建OrdersLog订单日志表条件表达式
        /// </summary>
        /// <param name="orderslogQuery">OrdersLog订单日志表查询对象</param>
        /// <returns>OrdersLog订单日志表查询表达式</returns>
        protected override Expression<Func<Orderslog, bool>> CreateQuery(OrderslogQuery orderslogQuery)
        {
            return base.CreateQuery(orderslogQuery)
                 .WhereIf(t => t.OrdersId == orderslogQuery.OrdersId, orderslogQuery.OrdersId.IsNotEmpty());
        }
    }
}