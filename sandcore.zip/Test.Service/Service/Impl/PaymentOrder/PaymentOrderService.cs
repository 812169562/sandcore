﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Service;
using Sand.Extensions;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Contract.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;
using System.Collections.Generic;
using System.Threading.Tasks;
using Mqtt.Data.Input;
using Mqtt.Data.Result;
using Mqtt.Data;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Service.Services;
using Sand.Maps;
using Newtonsoft.Json;
using Sand.Exceptions;
using Sand.Data;
using Dapper.Contrib.Extensions;
using Sand.Helpers;
using WebApiClient;
using Sand.Domain.Entities.Payment;
using Microsoft.EntityFrameworkCore;
using Sand.Domain.Chat.Events;
using Sand.Events;
using Sand.DI;
using EasyCaching.Core;
using Sand.Log.Less;

namespace Sand.Service.Impl.PaymentOrder
{
    /// <summary>
    ///  订单支付信息服务
    /// </summary>
    public class PaymentOrderService : IPaymentOrderService
    {
        /// <summary>
        /// 缓存工厂
        /// </summary>
        private readonly IEasyCachingProviderFactory _cachingFactory;
        /// <summary>
        ///  订单支付信息
        /// </summary>
        private readonly IPaymentService _paymentService;
        /// <summary>
        /// 数据访问
        /// </summary>
        private readonly ISqlQuery _sqlQuery;
        /// <summary>
        /// 订单表仓储
        /// </summary>
        private readonly IOrdersRepository _ordersRepository;
        /// <summary>
        ///  第三方支付信息仓储
        /// </summary>
        private readonly IPaymentRepository _paymentRepository;
        /// <summary>
        /// convenientorder仓储
        /// </summary>
        private readonly IConvenientorderRepository _convenientorderRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cachingFactory">缓存工厂</param>
        /// <param name="paymentService">订单支付信息</param>
        /// <param name="sqlQuery">数据访问</param>
        /// <param name="ordersRepository">订单表仓储</param>
        /// <param name="paymentRepository">第三方支付信息仓储</param>
        /// <param name="convenientorderRepository">convenientorder仓储</param>
        public PaymentOrderService(IEasyCachingProviderFactory cachingFactory, IPaymentService paymentService, ISqlQuery sqlQuery, IOrdersRepository ordersRepository, IPaymentRepository paymentRepository, IConvenientorderRepository convenientorderRepository)
        {
            _cachingFactory = cachingFactory;
            _paymentService = paymentService;
            _ordersRepository = ordersRepository;
            _sqlQuery = sqlQuery;
            _paymentRepository = paymentRepository;
            _convenientorderRepository = convenientorderRepository;
        }
        /// <summary>
        /// 退费
        /// </summary>
        /// <returns></returns>
        public async Task Refund()
        {
            try
            {
                string sql = "SELECT b.Id,b.ReservationID,b.OutId,b.CardId,b.OutPatientId,b.Type,b.`Status`,b.PaymentId,b.TradeNo,b.OutTradeNo,b.Amount," +
                    "a.Reasons as Remark,b.Details,a.CreateTime as ApplicationTime,a.FailureReasons,a.Status as RefundStatus,a.RefundAmount " +
                    "FROM Refund a LEFT JOIN orders b ON a.OrdersId=b.Id WHERE a.IsDeleted=0 and a.Status=?Status and b.Type=1 " +
                    "and a.CreateTime>=?Being and a.CreateTime<?End ORDER BY a.CreateTime asc";
                var data = (await _sqlQuery.QueryAsync<OrdersDto>(sql, new
                {
                    Status = RefundStatus.Refunding.Value(),
                    Being = DateTime.Now.AddHours(-8),
                    End = DateTime.Now
                })).ToList();
                foreach (var item in data)
                {
                    try
                    {
                        await _paymentService.RefundsAuditAsync(item);
                    }
                    catch (Exception ex)
                    {
                        item.Remark = ex.Message;
                        await _paymentService.RefundsAuditNotPassedAsync(item);
                        ex.Submit();
                    }
                }

            }
            catch (Exception ex)
            {
                ex.Submit();
            }
        }

        /// <summary>
        /// 取消订单
        /// </summary>
        /// <returns></returns>
        public async Task Cancel()
        {
            var data = (await _ordersRepository.RetrieveAsync(t => t.CreateTime >= DateTime.Now.ToDateString().ToDate() && t.IsEnable)).OrderBy(t => t.CreateTime).ToList();
            var message = new Message<string, List<BookingOrderResult>>();
            message.Type = AccessType.ReservationList;
            message.Input = "";
            var result = (await MqttService.PublishAsync(message)).Result;
            //当日所有挂号订单
            var registerList = data.Where(t => t.Type == OrdersType.Register.Value());
            foreach (var item in result)
            {
                //取消微信无订单记录，his预约登记表有记录的挂号
                if (!registerList.Any(t => t.ReservationID == item.ReservationID))
                {
                    try
                    {
                        var model = new OrdersDto()
                        {
                            ReservationID = item.ReservationID
                        };
                        await _paymentService.CancelRegister(model);
                    }
                    catch (Exception ex)
                    {
                        ex.Submit();
                    }
                }
            }
            //挂号-取消当日三十分钟前的未缴费订单
            var register = registerList.Where(t => t.Status == OrdersStatus.Pay.Value() && t.CreateTime < DateTime.Now.AddMinutes(-30));
            foreach (var item in register)
            {
                try
                {
                    await _paymentService.CancelRegister(item.MapTo<OrdersDto>());
                }
                catch (Exception ex)
                {
                    ex.Submit();
                }
            }
            //门诊缴费-取消当日三十分钟前的未缴费订单
            var outpatient = data.Where(t => t.Type != OrdersType.Register.Value() && t.CreateTime < DateTime.Now.AddMinutes(-30) && t.Status == OrdersStatus.Pay.Value());
            foreach (var item in outpatient.Select(t => t.PaymentId).Distinct())
            {
                try
                {
                    var list = outpatient.Where(t => t.PaymentId == item).ToList();
                    await _paymentService.CancelOutpatientPay(list.MapToList<OrdersDto>());
                }
                catch (Exception ex)
                {
                    ex.Submit();
                }
            }
        }
        /// <summary>
        /// 订单
        /// </summary>
        /// <returns></returns>
        public async Task Confirm()
        {
            await ConfirmMz();
            await ConfirmGh();
        }
        private async Task ConfirmMz()
        {
            var log = "";
            var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
            var orders = await provider.GetByPrefixAsync<List<string>>("outpatientpaykey");
            //门诊缴费确认订单
            foreach (var item in orders)
            {
                if (!item.Value.HasValue) continue;
                var order = item.Value.Value.FirstOrDefault();
                if (order == null) continue;
                log = log + "____" + Json.ToJson(order);
                var orderEntity = await _ordersRepository.RetrieveByIdAsync(order);
                if (orderEntity == null) continue;
                //1分钟以内的单子不处理
                if ((DateTime.Now - orderEntity.CreateTime).TotalSeconds < 60) continue;
                NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊开始处理" + log);
                var payment = await _paymentRepository.RetrieveByIdAsync(orderEntity.PaymentId);
                if (payment.Status == PaymentStatus.Success.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经完成无需确认：" + Json.ToJson(orderEntity));
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经完成无需确认支付信息：" + Json.ToJson(payment));
                    await provider.RemoveAsync("outpatientpaykey:" + orderEntity.PaymentId);
                    continue;
                }
                if (payment.Status == PaymentStatus.Cancelled.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经取消无需确认：" + Json.ToJson(orderEntity));
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经取消无需确认支付信息：" + Json.ToJson(payment));
                    await provider.RemoveAsync("outpatientpaykey:" + orderEntity.PaymentId);
                    continue;
                }
                if (payment.Status != PaymentStatus.Waiting.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经无效无需确认：" + Json.ToJson(orderEntity));
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "门诊订单已经无效无需确认支付信息：" + Json.ToJson(payment));
                    //await provider.RemoveAsync("outpatientpaykey:" + orderEntity.PaymentId);
                    continue;
                }
                if (payment.Status == PaymentStatus.Waiting.Value())
                {
                    try
                    {
                        //一分钟内产生的订单 不确认状态
                        //if (order.LastUpdateTime.SafeValue().AddMinutes(1) < DateTime.Now)
                        //{
                        //    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "一分内的单据无需确认：" + Json.ToJson(order));
                        //    await provider.RemoveAsync("outpatientpaykey:" + order.PaymentId);
                        //    continue;
                        //}
                        NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "确认门诊订单开始：" + Json.ToJson(orderEntity));
                        var paymentNew = await _paymentService.ConfirmPaymentAsync(new PaymentDto() { Id = orderEntity.PaymentId, OutTradeNo = orderEntity.OutTradeNo });
                        //直到订单成功再确认订单并取消缓存
                        if (paymentNew.Status == PaymentStatus.Success.Value())
                        {
                            NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "确认门诊订单完成：" + Json.ToJson(payment));
                            await provider.RemoveAsync("outpatientpaykey:" + orderEntity.PaymentId);
                        }
                        //await provider.RemoveAsync("outpatientpaykey" + order.PaymentId);
                    }
                    catch (Exception ex)
                    {
                        if (ex is Warning)
                        {
                            //未支付状态移除缓存
                            if ((ex as Warning).Code == "W04")
                            {
                                await provider.RemoveAsync("outpatientpaykey:" + orderEntity.PaymentId);
                            }
                        }
                        NLog.LogManager.GetLogger("systemerrorLog").Error(ex);
                        ex.Submit();
                        continue;
                    }
                }
                //NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "缴费正常状态无需验证" + order + "__" );
            }
        }
        /// <summary>
        /// 确认挂号订单
        /// </summary>
        /// <returns></returns>
        private async Task ConfirmGh()
        {
            var log = "";
            var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
            var orders = await provider.GetByPrefixAsync<string>("registerpaykey");
            foreach (var item in orders)
            {
                if (!item.Value.HasValue) continue;
                var orderId = item.Value.Value;
                var order = (await _ordersRepository.RetrieveByIdAsync(orderId)).MapTo<OrdersDto>();
                //获取微信平台的支付状态已付费才确认订单
                log = log + "____" + Json.ToJson(order);
                //1分钟以内的单子不处理
                if ((DateTime.Now - order.CreateTime.Value).TotalSeconds < 60) continue;
                NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "挂号开始处理" + log);
                //当订单为待支付状态时进行校验
                if (order.Status == OrdersStatus.Paymented.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "挂号已经完成" + order.Id + "__" + order.Status);
                    await provider.RemoveAsync("registerpaykey:" + order.Id);
                    continue;
                }
                if (order.Status == OrdersStatus.Completed.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "挂号已经完成" + order.Id + "__" + order.Status);
                    await provider.RemoveAsync("registerpaykey:" + order.Id);
                    continue;
                }
                if (order.Status == OrdersStatus.Cancelled.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "挂号已取消状态" + order.Id + "__" + order.Status);
                    await provider.RemoveAsync("registerpaykey:" + order.Id);
                    continue;
                }
                if (order.Status != OrdersStatus.Pay.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "挂号已经非待付费状态" + order.Id + "__" + order.Status);
                    //await provider.RemoveAsync("registerpaykey:" + order.Id);
                    continue;
                }
                try
                {
                    //一分钟内产生的订单 不确认状态
                    //if (order.LastUpdateTime.SafeValue().AddMinutes(1) < DateTime.Now)
                    //{
                    //    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "一分内的单据无需确认：" + Json.ToJson(order));
                    //    continue;
                    //}
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "确认订单开始：" + Json.ToJson(order));
                    var payment = await _paymentService.RegisterPay(order);
                    //直到订单成功再确认订单并取消缓存
                    if (payment.Status == PaymentStatus.Success.Value())
                    {
                        NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "确认订单完成：" + Json.ToJson(payment));
                        await provider.RemoveAsync("registerpaykey:" + order.Id);
                    }
                }
                catch (Exception ex)
                {
                    if (ex is Warning)
                    {
                        //未支付状态移除缓存
                        if ((ex as Warning).Code == "W04")
                        {
                            await provider.RemoveAsync(DateTime.Now + "registerpaykey:" + order.Id);
                        }
                    }
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + log + "异常信息" + ex);
                    ex.Submit();
                    continue;
                }
            }
        }
        /// <summary>
        /// 修改便民订单编号
        /// </summary>
        /// <returns></returns>
        public async Task ConfirmConvenientorder()
        {
            var log = "";
            var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
            var convenientorders = await provider.GetByPrefixAsync<List<string>>("convenientorderkey");
            //
            foreach (var item in convenientorders)
            {
                if (!item.Value.HasValue) continue;
                var id = item.Value.Value.FirstOrDefault();
                if (id == null) continue;
                log = log + "____" + Json.ToJson(id);
                var orderEntity = (await _ordersRepository.RetrieveAsync(t => t.ConvenientOrderId == id)).ToList();
                var convenientorder = await _convenientorderRepository.RetrieveByIdAsync(id);
                if (orderEntity == null || !orderEntity.Any(t => t.Status != OrdersStatus.Paymented.Value()))
                {
                    await provider.RemoveAsync("convenientorderkey:" + id);
                    continue;
                }
                if (convenientorder == null && convenientorder.Status == ConvenientOrderStatus.Pass.Value())
                {
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "便民订单状态处理开始" + log);
                    await _convenientorderRepository.UpdateAsync(t => t.Id == id, t => new Convenientorder() { Status = ConvenientOrderStatus.Payment.Value() });
                    await provider.RemoveAsync("convenientorderkey:" + id);
                    NLog.LogManager.GetLogger("systemerrorLog").Warn(DateTime.Now + "便民订单状态处理完成" + log);
                }
            }
        }
    }
}