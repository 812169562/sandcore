﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Service;
using Sand.Extensions;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Contract.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;

namespace Sand.Service.Impl.PaymentOrder {
    /// <summary>
    /// 支付日志服务
    /// </summary>
    public class PaymentlogService : BaseService<PaymentlogDto, PaymentlogQuery,Paymentlog>, IPaymentlogService {
        /// <summary>
        /// 支付日志仓储
        /// </summary>
        private readonly IPaymentlogRepository _paymentlogRepository;
        
        /// <summary>
        /// 初始化支付日志服务
        /// </summary>
        
        /// <param name="paymentlogRepository">支付日志仓储</param>
        public PaymentlogService( IPaymentlogRepository paymentlogRepository)
            : base( paymentlogRepository ) {
           _paymentlogRepository = paymentlogRepository;
        }
        
         /// <summary>
        /// 创建支付日志条件表达式
        /// </summary>
        /// <param name="paymentlogQuery">支付日志查询对象</param>
        /// <returns>支付日志查询表达式</returns>
        protected override Expression<Func<Paymentlog, bool>> CreateQuery(PaymentlogQuery paymentlogQuery)
        {
           return  base.CreateQuery(paymentlogQuery);
        }
    }
}