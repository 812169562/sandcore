﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Service;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Contract.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;
using System.Threading.Tasks;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Maps;
using Sand.Exceptions;
using System.Collections.Generic;
using Sand.Result;
using Sand.Data;
using Sand.Extensions;
using Dapper.Contrib.Extensions;
using Sand.Helpers;
using Microsoft.EntityFrameworkCore;
using Sand.Events;
using Sand.Domain.MqttData;

namespace Sand.Service.Impl.PaymentOrder
{
    /// <summary>
    /// 订单表服务
    /// </summary>
    public class OrdersService : BaseService<OrdersDto, OrdersQuery, Orders>, IOrdersService
    {
        /// <summary>
        /// 订单表仓储
        /// </summary>
        private readonly IOrdersRepository _ordersRepository;
        /// <summary>
        /// OrdersLog订单日志表仓储
        /// </summary>
        private readonly IOrderslogRepository _orderslogRepository;
        /// <summary>
        ///  第三方支付信息仓储
        /// </summary>
        private readonly IPaymentRepository _paymentRepository;
        /// <summary>
        /// 支付日志仓储
        /// </summary>
        private readonly IPaymentlogRepository _paymentlogRepository;
        /// <summary>
        /// 数据访问
        /// </summary>
        private readonly ISqlQuery _sqlQuery;
        /// <summary>
        /// 
        /// </summary>
        private IEventBus _eventBus;
        /// <summary>
        /// 初始化订单表服务
        /// </summary>

        /// <param name="ordersRepository">订单表仓储</param>
        /// <param name="sittingRepository">医生坐诊表仓储</param>
        /// <param name="cardRepository">就诊卡仓储</param>
        /// <param name="usersRepository">用户表仓储</param>
        /// <param name="orderslogRepository">OrdersLog订单日志表仓储</param>
        /// <param name="paymentRepository">第三方支付信息仓储</param>
        /// <param name="paymentlogRepository">支付日志仓储</param>
        /// <param name="sqlQuery">数据访问</param>
        /// <param name="eventBus"></param>
        /// <param name="countCacheService">计数判断</param>
        /// <param name="storagesRepository">存储仓储</param>
        /// <param name="chatlogRepository">聊天记录仓储</param>
        public OrdersService(IOrdersRepository ordersRepository, IOrderslogRepository orderslogRepository, IPaymentRepository paymentRepository, IPaymentlogRepository paymentlogRepository, ISqlQuery sqlQuery, IEventBus eventBus, ICountCacheService countCacheService, IStoragesRepository storagesRepository, IChatlogRepository chatlogRepository)
           : base(ordersRepository)
        {
            _ordersRepository = ordersRepository;
            _orderslogRepository = orderslogRepository;
            _paymentRepository = paymentRepository;
            _paymentlogRepository = paymentlogRepository;
            _sqlQuery = sqlQuery;
            _eventBus = eventBus;
        }

        //#region 门诊缴费
        ///// <summary>
        ///// 创建缴费订单
        ///// </summary>
        ///// <param name="orders">订单表信息</param>
        ///// <returns></returns>
        //public async Task<List<OrdersDto>> CreateOutpatientOrders(List<OrdersDto> orders)
        //{
        //    if (orders == null || orders.Count() <= 0)
        //        throw new Warning("请至少选中一条订单信息！");
        //    //判断订单是否已生成过，是：删除订单、支付记录
        //    var list = (await _ordersRepository.RetrieveAsync(t => orders.Select(p => p.OutId).Contains(t.OutId))).ToList();
        //    if (list != null && list.Any())
        //    {
        //        await _paymentlogRepository.UpdateAsync(t => list.Select(p => p.PaymentId).Contains(t.PaymentId), t => new Paymentlog() { IsDeleted = true });
        //        await _paymentRepository.UpdateAsync(t => list.Select(p => p.PaymentId).Contains(t.Id), t => new Payment() { IsDeleted = true });
        //        await _orderslogRepository.UpdateAsync(t => list.Select(p => p.Id).Contains(t.OrdersId), t => new Orderslog() { IsDeleted = true });
        //        await _ordersRepository.UpdateAsync(t => list.Select(p => p.Id).Contains(t.Id), t => new Orders() { IsDeleted = true });
        //    }
        //    var outTradeNo = Uuid.Next();
        //    var cardlist = (await _cardRepository.RetrieveAsync(t => orders.Select(p => p.OutPatientId).Distinct().Contains(t.OtherId))).ToList();
        //    foreach (var item in orders)
        //    {
        //        if (cardlist != null)
        //        {
        //            var card = cardlist.FirstOrDefault(t => t.OtherId == item.OutPatientId);
        //            item.CardId = card != null ? card.Id : UserContext.LoginKey;
        //        }
        //        item.OutTradeNo = outTradeNo;
        //    }
        //    //生成订单
        //    var data = await _ordersRepository.CreateListAsync(orders.MapToList<Orders>());
        //    //HIS修改订单生成时间
        //    await UpdateOrdersTime(data.Select(t => t.OutId).ToList());
        //    //添加订单日志
        //    await CrateOrderlogList(data.ToList());
        //    // 添加支付日志
        //    var payment = await CreatePayment(data.ToList());
        //    await _ordersRepository.UpdateAsync(t => data.Select(o => o.Id).Contains(t.Id), t => new Orders() { PaymentId = payment.Id });
        //    foreach (var item in data)
        //    {
        //        item.PaymentId = payment.Id;
        //    }
        //    return data.MapToList<OrdersDto>();
        //}
        ///// <summary>
        ///// HIS修改订单生成时间
        ///// </summary>
        ///// <param name="data"></param>
        ///// <returns></returns>
        //private static async Task UpdateOrdersTime(List<string> data)
        //{
        //    var message = new Message<PaymentInput, PaymentResult>();
        //    message.Type = AccessType.UpdateLockTime;
        //    message.Input = new PaymentInput()
        //    {
        //        ChargeIdData = data,
        //        OrderCreateTime = DateTime.Now
        //    };
        //    await MqttService.PublishAsync(message);
        //}
        ///// <summary>
        ///// 添加订单日志集合
        ///// </summary>
        ///// <param name="data"></param>
        ///// <returns></returns>
        //private async Task CrateOrderlogList(List<Orders> data)
        //{
        //    var ordersloglist = new List<Orderslog>();
        //    foreach (var item in data)
        //    {
        //        ordersloglist.Add(new Orderslog()
        //        {
        //            Status = OrdersStatus.Pay.Value(),
        //            OrdersId = item.Id,
        //            OrdersChargeLog = Json.ToJson(item)
        //        });
        //    }
        //    await _orderslogRepository.CreateListAsync(ordersloglist);
        //}

        ///// <summary>
        ///// 创建支付记录、创建支付记录日志集合（Payment、Paymentlog）
        ///// </summary>
        ///// <param name="orders">订单信息</param>
        ///// <returns></returns>
        //private async Task<Payment> CreatePayment(List<Orders> orders)
        //{
        //    var payment = new Payment()
        //    {
        //        Amount = orders.Sum(t => t.Amount),
        //        ComfirmAmount = 0,
        //        PayPlatform = PayPlatformType.WeChat.Value(),
        //        PayType = PayType.App.Value(),
        //        //PayUserId = UserContext.LoginKey,
        //        //PayUserName = UserContext.LoginName,
        //        RefundAmount = 0,
        //        Status = PaymentStatus.Waiting.Value(),
        //        OutTradeNo = orders.FirstOrDefault().OutTradeNo
        //    };
        //    var data = await _paymentRepository.CreateAsync(payment);
        //    var paymentlog = new Paymentlog()
        //    {
        //        PaymentId = data.Id,
        //        Amount = data.Amount,
        //        Input = "",
        //        Ip = "",
        //        Output = "",
        //        PaymentChargeLog = Json.ToJson(data),
        //        Status = data.Status
        //    };
        //    await _paymentlogRepository.CreateAsync(paymentlog);
        //    return data;
        //}
        ///// <summary>
        ///// 获取待支付订单
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //public async Task<List<OrdersDto>> OrdersByPaymentIdAsync(OrdersQuery ordersQuery)
        //{
        //    var ordersData = (await _ordersRepository.RetrieveAsync(t => t.PaymentId == ordersQuery.PaymentId)).ToList().MapToList<OrdersDto>();
        //    var message = new Message<List<string>, List<ChargeInfo>>();
        //    message.Type = AccessType.ChargeInfo;
        //    message.Input = ordersData.Select(t => t.OutId).ToList();
        //    var data = await MqttService.PublishAsync(message);
        //    Dictionary<string, List<ChargeInfo>> dictionary = new Dictionary<string, List<ChargeInfo>>();
        //    foreach (var item in ordersData)
        //    {
        //        item.ItemName = item.Outpatient.ItemName;
        //        item.Money = item.Outpatient.PayMoney;
        //        if (item.ConvenientOrderId.IsNotEmpty())
        //        {
        //            var chargeIds = ordersData.Where(t => t.ConvenientOrderId == item.ConvenientOrderId).Select(t => t.OutId).ToList();
        //            item.Info = data.Result.Where(t => chargeIds.Contains(t.ChargeID)).ToList();
        //            item.IsShow = item.Type != OrdersType.Other.Value();
        //        }
        //        else
        //        {
        //            item.Info = data.Result.Where(t => t.ChargeID == item.OutId).ToList();
        //            item.IsShow = true;
        //        }
        //    }
        //    return ordersData;
        //}
        //#endregion

        //#region 挂号
        ///// <summary>
        ///// 检查患者信息完整性
        ///// </summary>
        ///// <param name="card">患者信息</param>
        //private void CheckCardMsg(Card card)
        //{
        //    try
        //    {
        //        card.IDCard.CheckIdCard();
        //        if (card.MaritalStatus.IsEmpty() || card.Occupation.IsEmpty() || card.Nation.IsEmpty() || card.Education.IsEmpty() || card.Address.IsEmpty())
        //            throw new Warning("请完善个人信息才可挂号！");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Log.GetLog().Error(ex.Message);
        //        throw new Warning("请完善个人信息才可挂号！");
        //    }
        //}
        ///// <summary>
        ///// 新增挂号订单信息
        ///// </summary>
        ///// <param name="dto">订单表信息</param>
        ///// <returns></returns>
        //public async Task<OrdersDto> RegisterAsync(OrdersDto dto)
        //{
        //    //判断挂号人取消次数过多情况，不可挂号
        //    await _countCacheService.CheckedCount("day:" + UserContext.LoginKey, SysCountType.CancelRegister, 3, "挂号取消订单次数过多，暂不能使用预约挂号，请到现场预约！");
        //    await _countCacheService.CheckedCount("month:" + UserContext.LoginKey, SysCountType.CancelRegister, 10, "挂号取消订单次数过多，暂不能使用预约挂号，请到现场预约！");
        //    await _countCacheService.CheckedCount("year:" + UserContext.LoginKey, SysCountType.CancelRegister, 20, "挂号取消订单次数过多，暂不能使用预约挂号，请到现场预约！");
        //    if (string.IsNullOrEmpty(dto.CardId))
        //        throw new Warning("请选择挂号人！");
        //    var card = await _cardRepository.RetrieveByIdAsync(dto.CardId);
        //    if (card == null)
        //        throw new Warning("当前就诊卡不存在！");
        //    if (card.RestrictedUse == 1)
        //        throw new Warning("您已多次创建预约后未进行支付，已取消您网络预约资格！");
        //    //判断一个月内存在退费成功挂号数超过五次不可使用挂号
        //    var data = await _ordersRepository.RetrieveAsync(t => t.CardId == card.Id && t.Type == OrdersType.Register.Value() && t.Status == OrdersStatus.Refund.Value() && t.LastUpdateTime >= DateTime.Now.AddDays(-60));
        //    if (data != null && data.Count() > 3)
        //        throw new Warning("近一月在微信平台挂号退费超过3次，请在现场进行挂号！");
        //    if (Service.Configuration.Configuration.IsMustFill)
        //        CheckCardMsg(card);
        //    var sitting = new Sitting();
        //    if (dto.IsConvenient)
        //    {
        //        sitting.UserId = dto.UserId;
        //        sitting.DayType = 1;
        //        sitting.SittingDate = DateTime.Now.ToDateString().ToDate();
        //        sitting.Registration = 1;
        //    }
        //    else
        //    {
        //        sitting = await _sittingRepository.RetrieveByIdAsync(dto.SittingId);
        //        if (sitting == null || !sitting.IsEnable)
        //            throw new Warning("当前医生已停诊！");
        //        else if (sitting.Count - sitting.UseCount <= 0)
        //            throw new Warning("当前医生号满！");
        //    }
        //    var users = await _usersRepository.RetrieveByIdAsync(sitting.UserId);
        //    if (users == null)
        //        throw new Warning("挂号医生已删除！");
        //    var Ykt = false;
        //    var remark = "";
        //    if (Service.Configuration.Configuration.IsCheckYkt && !string.IsNullOrEmpty(card.Code) && sitting.Examine >= 7)
        //    {
        //        Ykt = await CheckYkt(dto);
        //        sitting.Examine = Ykt ? sitting.Examine - 7 : sitting.Examine;
        //        remark = Ykt ? "校内人员挂号减免7元" : "";
        //    }
        //    decimal money = sitting.Registration.SafeValue() + sitting.Examine.SafeValue();
        //    decimal bookingMoney = 0;
        //    if (DateTime.Now.ToDateString() != sitting.SittingDate.ToDateString())
        //    {
        //        money += sitting.BookingMoney.SafeValue();
        //        bookingMoney = sitting.BookingMoney.SafeValue();
        //    }
        //    var ReservationId = "";
        //    var freeRegistration = false;
        //    if (Service.Configuration.Configuration.IsZeroRegistration)
        //    {
        //        List<int> TaxonData = new List<int>();
        //        if (users.Taxon.IsNotEmpty())
        //        {
        //            var data1 = users.Taxon.Split('|');
        //            for (int i = 0; i < data1.Length; i++)
        //            {
        //                if (data1[i].IsNotEmpty())
        //                    TaxonData.Add(data1[i].ToInt());
        //            }
        //        }
        //        if (TaxonData.Any(t => t == TaxonType.FreeRegistration.Value()))
        //        {
        //            freeRegistration = true;
        //            money = 0;
        //            bookingMoney = 0;
        //        }
        //    }
        //    try
        //    {
        //        // 发送到HIS
        //        var message = new Message<RegisterInput, RegisterResult>();
        //        message.Type = AccessType.BookingRegister;
        //        message.Input = new RegisterInput()
        //        {
        //            PatientNo = card.Code,
        //            UserId = users.OtherId,
        //            DateType = sitting.DayType,
        //            Date = sitting.SittingDate,
        //            TimeIntervalID = sitting.TimeIntervalID,
        //            Money = money,
        //            IsConvenient = dto.IsConvenient,
        //            Ykt = Ykt,
        //            Remark = remark,
        //            PatientID = card.OtherId,
        //            FreeRegistration = freeRegistration
        //        };
        //        var result = await MqttService.PublishAsync(message);
        //        ReservationId = result.Result.ReservationId;

        //        var register = new Register()
        //        {
        //            ReservationID = result.Result.ReservationId,
        //            UserId = users.Id,
        //            UserName = users.UserName,
        //            Title = users.Title,
        //            DepartmentId = sitting.DepartmentId.IsEmpty() ? users.DepartmentId : sitting.DepartmentId,
        //            DepartmentName = sitting.DepartmentName.IsEmpty() ? users.DepartmentName : sitting.DepartmentName,
        //            SittingDate = sitting.SittingDate,
        //            DayType = sitting.DayType,
        //            TimeIntervalId = sitting.TimeIntervalID,
        //            TimeIntervalName = sitting.TimeIntervalName,
        //            Money = money,
        //            SittingAddress = sitting.SittingAddress,
        //            CardId = card.Id,
        //            CardNo = card.Code,
        //            PatientName = card.Name,
        //            BookingMoney = bookingMoney
        //        };
        //        var orders = new OrdersDto()
        //        {
        //            CardId = dto.CardId,
        //            OutPatientId = card.OtherId,
        //            Type = OrdersType.Register.Value(),
        //            Status = OrdersStatus.Pay.Value(),
        //            Amount = System.Convert.ToInt32(money * 100),
        //            Remark = remark,
        //            ReservationID = result.Result.ReservationId,
        //            Details = Json.ToJson(register),
        //            SittingId = dto.SittingId,
        //            OutTradeNo = Uuid.Next(),
        //            SittingDate = sitting.SittingDate,
        //            UserId = users.Id
        //        };
        //        return await CreateOrders(orders);
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex is Warning)
        //        {
        //            var warning = ex as Warning;
        //            if (warning.Code == "W4")
        //                await _sqlQuery.ExecuteAsync("update sitting set UseCount=Count where Id=?Id", new { sitting.Id });
        //            if (warning.Code.Contains("W"))
        //                throw new Warning(ex.Message);
        //        }
        //        throw new Transform(ex.Message, new { ReservationID = ReservationId, SittingId = sitting.Id, dto.UserId });
        //    }
        //}
        ///// <summary>
        ///// 验证一卡通
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //private static async Task<bool> CheckYkt(OrdersDto dto)
        //{
        //    var message = new Message<string, bool>();
        //    message.Type = AccessType.CheckYkt;
        //    message.Input = dto.CardNo;
        //    var data = await MqttService.PublishAsync(message);
        //    return data.Result;
        //}

        ///// <summary>
        ///// 创建本地订单(his创建成功本地未创建订单情况)
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //public async Task<OrdersDto> CreateRegisterOrders(OrdersDto dto)
        //{
        //    var oldorders = (await _ordersRepository.RetrieveAsync(t => t.ReservationID == dto.ReservationID && t.Status == OrdersStatus.Pay.Value() && t.IsEnable)).ToList();
        //    if (oldorders.Any())
        //        return ToDto(oldorders.FirstOrDefault());
        //    var sitting = new Sitting();
        //    var users = await _usersRepository.RetrieveByIdAsync(dto.UserId);
        //    //便民
        //    if (dto.IsConvenient)
        //    {
        //        sitting.Registration = 1;
        //        sitting.DayType = 1;
        //        sitting.DepartmentName = users.DepartmentName;
        //        sitting.SittingDate = DateTime.Now.ToDateString().ToDate();
        //    }
        //    else
        //    {
        //        sitting = await _sittingRepository.RetrieveByIdAsync(dto.SittingId);
        //    }
        //    var card = (await _cardRepository.RetrieveAsync(t => t.OtherId == dto.OutPatientId)).FirstOrDefault();
        //    decimal money = sitting.Registration.SafeValue() + sitting.Examine.SafeValue();
        //    decimal bookingMoney = 0;
        //    if (DateTime.Now.ToDateString() != sitting.SittingDate.ToDateString())
        //    {
        //        money += sitting.BookingMoney.SafeValue();
        //        bookingMoney = sitting.BookingMoney.SafeValue();
        //    }
        //    if (Service.Configuration.Configuration.IsZeroRegistration)
        //    {
        //        List<int> TaxonData = new List<int>();
        //        if (users.Taxon.IsNotEmpty())
        //        {
        //            var data1 = users.Taxon.Split('|');
        //            for (int i = 0; i < data1.Length; i++)
        //            {
        //                if (data1[i].IsNotEmpty())
        //                    TaxonData.Add(data1[i].ToInt());
        //            }
        //        }
        //        if (TaxonData.Any(t => t == TaxonType.FreeRegistration.Value()))
        //        {
        //            money = 0;
        //            bookingMoney = 0;
        //        }
        //    }
        //    var register = new Register()
        //    {
        //        ReservationID = dto.ReservationID,
        //        DayType = sitting.DayType,
        //        DepartmentId = sitting.DepartmentId.IsEmpty() ? users.DepartmentId : sitting.DepartmentId,
        //        DepartmentName = sitting.DepartmentName,
        //        Money = money,
        //        SittingDate = sitting.SittingDate,
        //        TimeIntervalId = sitting.TimeIntervalID,
        //        TimeIntervalName = sitting.TimeIntervalName,
        //        Title = dto.Title,
        //        UserId = dto.UserId,
        //        UserName = dto.UserName,
        //        SittingAddress = sitting.SittingAddress,
        //        CardId = card.Id,
        //        CardNo = card.Code,
        //        PatientName = card.Name,
        //        BookingMoney = bookingMoney
        //    };
        //    var orders = new OrdersDto()
        //    {
        //        CardId = card.Id,
        //        OutPatientId = dto.OutPatientId,
        //        Type = OrdersType.Register.Value(),
        //        Status = OrdersStatus.Pay.Value(),
        //        Amount = System.Convert.ToInt32(money * 100),
        //        Remark = "",
        //        ReservationID = dto.ReservationID,
        //        Details = Json.ToJson(register),
        //        OutTradeNo = Uuid.Next(),
        //        SittingDate = sitting.SittingDate,
        //        SittingId = sitting.Id
        //    };
        //    return await CreateOrders(orders);
        //}
        ///// <summary>
        ///// 创建本地订单
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //private async Task<OrdersDto> CreateOrders(OrdersDto dto)
        //{
        //    // 修改坐诊使用号数
        //    if (dto.SittingId.IsNotEmpty())
        //        await _sittingRepository.UpdateAsync(t => t.Id == dto.SittingId, t => new Sitting() { UseCount = t.UseCount + 1 });
        //    // 添加本地订单信息
        //    var data = await _ordersRepository.CreateAsync(dto.MapTo<Orders>());
        //    //添加订单日志信息(待付款)
        //    await CreateOrderLog(data);
        //    //支付记录（等待支付）
        //    var payment = await CreatePayment(dto);
        //    data.PaymentId = payment.Id;
        //    await _ordersRepository.UpdateAsync(t => t.Id == data.Id, t => new Orders { PaymentId = payment.Id });
        //    return data.MapTo<OrdersDto>();
        //}
        ///// <summary>
        ///// 创建订单日志（Orderslog）
        ///// </summary>
        ///// <param name="orders"></param>
        ///// <returns></returns>
        //private async Task CreateOrderLog(Orders orders)
        //{
        //    // 添加订单日志
        //    var orderslog = new Orderslog()
        //    {
        //        OrdersChargeLog = Json.ToJson(orders),
        //        OrdersId = orders.Id.ToString(),
        //        Status = orders.Status
        //    };
        //    await _orderslogRepository.CreateAsync(orderslog);
        //}
        ///// <summary>
        ///// 创建支付记录（Payment、Paymentlog）
        ///// </summary>
        ///// <param name="orders">订单信息</param>
        ///// <returns></returns>
        //private async Task<Payment> CreatePayment(OrdersDto orders)
        //{
        //    PaymentDto paymentDto = new PaymentDto()
        //    {
        //        Amount = orders.Amount,
        //        ComfirmAmount = 0,
        //        PayPlatform = PayPlatformType.WeChat.Value(),
        //        PayType = PayType.App.Value(),
        //        //PayUserId = UserContext.LoginKey,
        //        //PayUserName = UserContext.LoginName,
        //        RefundAmount = 0,
        //        Status = PaymentStatus.Waiting.Value(),
        //        OutTradeNo = orders.OutTradeNo
        //    };
        //    var payment = await _paymentRepository.CreateAsync(paymentDto.MapTo<Payment>());
        //    Paymentlog paymentlog = new Paymentlog()
        //    {
        //        PaymentId = payment.Id,
        //        Amount = payment.Amount,
        //        Input = "",
        //        Ip = "",
        //        Output = "",
        //        PaymentChargeLog = Json.ToJson(payment),
        //        Status = payment.Status
        //    };
        //    await _paymentlogRepository.CreateAsync(paymentlog);
        //    return payment;
        //}
        //#endregion

        //#region 申请退款
        ///// <summary>
        ///// 退款申请
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //public async Task ApplicationRefundAsync(OrdersDto dto)
        //{
        //    var orders = await _ordersRepository.RetrieveByIdAsync(dto.Id);
        //    if (orders == null)
        //        throw new Warning("订单信息不存在");
        //    if (orders.Status != OrdersStatus.Paymented.Value())
        //        throw new Warning("该订单状态已改变，请刷新后再试！");

        //    orders.Status = OrdersStatus.Refunding.Value();
        //    orders.Remark = dto.Remark;
        //    //修改订单状态
        //    await _ordersRepository.UpdateAsync(t => t.Id == dto.Id, t => new Orders { Status = orders.Status, Remark = orders.Remark });
        //    await CreateOrderLog(orders);
        //    Refund refund = new Refund();
        //    refund.Id = Uuid.Next();
        //    refund.ChargeID = dto.OutId;
        //    refund.OrdersId = dto.Id;
        //    refund.CreateId = UserContext.LoginKey;
        //    refund.CreateName = UserContext.LoginName;
        //    refund.CreateTime = DateTime.Now;
        //    refund.LastUpdateId = UserContext.LoginKey;
        //    refund.LastUpdateName = UserContext.LoginName;
        //    refund.LastUpdateTime = DateTime.Now;
        //    refund.IsEnable = true;
        //    refund.Status = RefundStatus.Refunding.Value();
        //    refund.IsDeleted = false;
        //    refund.Version = Uuid.Next();
        //    refund.Reasons = dto.Remark;
        //    refund.RefundAmount = dto.Amount;
        //    if (dto.Type == OrdersType.Register.Value() && !Service.Configuration.Configuration.IsRefundSubscribe && dto.Register.BookingMoney > 0)
        //        refund.RefundAmount = dto.Amount - (int)(dto.Register.BookingMoney * 100);
        //    _sqlQuery.Begin(true);
        //    await _sqlQuery.WriteDbConnection.InsertAsync(refund);
        //    //消息通知
        //    WechatNoticeEvent drugsLog = new WechatNoticeEvent
        //    {
        //        TemplateType = "RefundNotice",
        //        AcceptId = Service.Configuration.Configuration.RefundReceiverWxId,
        //        Keyword1 = UserContext.LoginName,
        //        Keyword2 = dto.Money.ToString("f2"),
        //        Keyword3 = refund.CreateTime.ToDateTimeString(true),
        //        Remark = "退款原因：" + refund.Reasons,
        //        Param = dto.CardId
        //    };
        //    await _eventBus.PublishAsync(drugsLog);
        //}
        //#endregion

        ///// <summary>
        ///// 创建订单表条件表达式
        ///// </summary>
        ///// <param name="ordersQuery">订单表查询对象</param>
        ///// <returns>订单表查询表达式</returns>
        //protected override Expression<Func<Orders, bool>> CreateQuery(OrdersQuery ordersQuery)
        //{
        //    return base.CreateQuery(ordersQuery)
        //        .WhereIf(t => t.Status == ordersQuery.Status, ordersQuery.Status != null)
        //        .WhereIf(t => t.Type == ordersQuery.Type, ordersQuery.Type != null)
        //        .WhereIf(t => t.PaymentId == ordersQuery.PaymentId, ordersQuery.PaymentId.IsNotEmpty());
        //}
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //public override async Task<OrdersDto> RetrieveByIdAsync(string id)
        //{
        //    if (string.IsNullOrEmpty(id))
        //        throw new Warning("当前未选中任何订单！");
        //    string sql = "SELECT a.*,b.`Code` as CardNo,b.`Name` as PatientName,c.PayDate,d.RefundAmount,f.Path as AvatarUrl " +
        //        "FROM orders a LEFT JOIN card b on a.CardId=b.Id " +
        //        "LEFT JOIN payment c on a.PaymentId=c.Id " +
        //        "LEFT JOIN refund d on d.OrdersId=a.Id " +
        //        "LEFT JOIN users e ON e.Id=a.UserId " +
        //        "LEFT JOIN storages f ON e.AvatarUrl=f.NewName and f.IsDeleted=0 " +
        //        "WHERE a.Id=?Id";
        //    var orders = (await _sqlQuery.QueryAsync<OrdersDto>(sql, new { Id = id })).ToList();
        //    var dto = orders.FirstOrDefault();
        //    dto.Money = (decimal)dto.Amount / 100;
        //    if (dto.RefundAmount == null && dto.Type == OrdersType.Register.Value())
        //    {
        //        dto.RefundAmount = Service.Configuration.Configuration.IsRefundSubscribe ? dto.Amount : dto.Amount - (int)(dto.Register.BookingMoney * 100);
        //    }
        //    dto.RefundMoney = (decimal)dto.RefundAmount.SafeValue() / 100;
        //    if (dto.ConvenientOrderId.IsNotEmpty())
        //        orders = (await _ordersRepository.RetrieveAsync(t => t.ConvenientOrderId == dto.ConvenientOrderId)).ToList().MapToList<OrdersDto>();
        //    if (dto.Type != OrdersType.Register.Value())
        //    {
        //        var message = new Message<List<string>, List<ChargeInfo>>();
        //        message.Type = AccessType.ChargeInfo;
        //        message.Input = orders.Select(t => t.OutId).ToList();
        //        var data = await MqttService.PublishAsync(message);
        //        dto.Info = data.Result;
        //    }
        //    return dto;
        //}
        //#region 分页获取订单信息
        ///// <summary>
        ///// 获取订单信息
        ///// </summary>
        ///// <param name="ordersQuery">订单表查询对象</param>
        ///// <returns></returns>
        //public async Task<Paged<OrdersDto>> OrdersPageListAsync(OrdersQuery ordersQuery)
        //{
        //    Paged<OrdersDto> result = new Paged<OrdersDto>();
        //    if (ordersQuery.IsManage)
        //    {
        //        result = await OrdersPageManage(ordersQuery);
        //        foreach (var item in result.Result)
        //        {
        //            var name = item.Register.UserName + item.Register.SittingDateStr + item.Register.DayTypeStr + item.Register.UseNo + "号";
        //            item.ItemName = item.Type == OrdersType.Register.Value() ? name : item.Outpatient.ItemName;
        //            item.Money = (decimal)item.Amount / 100;
        //        }
        //    }
        //    else
        //    {
        //        result = await OrdersPageAPP(ordersQuery);
        //        var list = new List<OrdersDto>();
        //        foreach (var item in result.Result)
        //        {
        //            var model = list.FirstOrDefault(t => item.ConvenientOrderId.IsNotEmpty() && t.ConvenientOrderId == item.ConvenientOrderId);
        //            if (model == null)
        //            {
        //                var name = item.Register.UserName + item.Register.SittingDateStr + item.Register.DayTypeStr + item.Register.UseNo + "号";
        //                item.ItemName = item.Type == OrdersType.Register.Value() ? name : item.Outpatient.ItemName;
        //                item.Money = (decimal)item.Amount / 100;
        //                list.Add(item);
        //            }
        //            else
        //            {
        //                if (item.Type == OrdersType.WesternMedicine.Value() || item.Type == OrdersType.ChineseMedicine.Value())
        //                {
        //                    model.Id = item.Id;
        //                    model.Details = item.Details;
        //                    model.ItemName = item.Outpatient.ItemName;
        //                }
        //                //model.ItemName += "+" + item.Outpatient.ItemName;
        //                model.Money += (decimal)item.Amount / 100;
        //            }
        //        }
        //        result.Result = list;
        //    }
        //    return result;
        //}
        ///// <summary>
        ///// 获取订单信息 手机端APP使用 （Status：0.全部1.待付款2.已付款/已完成3.退款中/退款成功4.取消/失效）
        ///// (Type:-1.门诊缴费信息，其他按枚举正常值处理)
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //private async Task<Paged<OrdersDto>> OrdersPageAPP(OrdersQuery ordersQuery)
        //{
        //    var s = new List<int>();
        //    if (ordersQuery.Status == 1)
        //    {
        //        s.Add(OrdersStatus.Pay.Value());
        //    }
        //    else if (ordersQuery.Status == 2)
        //    {
        //        s.Add(OrdersStatus.Paymented.Value());
        //        s.Add(OrdersStatus.Completed.Value());
        //    }
        //    else if (ordersQuery.Status == 3)
        //    {
        //        s.Add(OrdersStatus.Refund.Value());
        //        s.Add(OrdersStatus.Refunding.Value());
        //    }
        //    else if (ordersQuery.Status == 4)
        //    {
        //        s.Add(OrdersStatus.Invalid.Value());
        //        s.Add(OrdersStatus.Cancelled.Value());
        //    }
        //    string selectSql = "SELECT a.*,b.`Name` as PatientName,b.`Code` as CardNo,c.PayDate";
        //    string whereSql = "FROM orders a LEFT JOIN card b on a.CardId=b.Id LEFT JOIN payment c on a.PaymentId=c.Id " +
        //        "WHERE a.IsDeleted=0"
        //        .WhereIf("(a.CreateId=?CardId)", UserContext.LoginKey.IsNotEmpty())
        //        .WhereIf("a.Status in ?Status", s.Any())
        //        .WhereIf("a.Type=?Type", ordersQuery.Type != null && ordersQuery.Type != -1)
        //        .WhereIf("a.Type not in (1,9,10,11)", ordersQuery.Type == -1);
        //    string orderbySql = "ORDER BY a.LastUpdateTime DESC";
        //    ordersQuery.Param = new
        //    {
        //        CardId = UserContext.LoginKey,
        //        Status = s,
        //        ordersQuery.Type
        //    };
        //    var result = await _sqlQuery.QueryPageAsync<OrdersDto>(selectSql, whereSql, orderbySql, ordersQuery);
        //    return result;
        //}
        ///// <summary>
        ///// 获取订单信息 后台管理员使用
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //private async Task<Paged<OrdersDto>> OrdersPageManage(OrdersQuery ordersQuery)
        //{
        //    string selectSql = "SELECT a.*,b.`Name` as PatientName,b.`Code` as CardNo,c.PayDate,b.Tel,c.PayUserName";
        //    string whereSql = "FROM orders a LEFT JOIN card b on a.CardId=b.Id LEFT JOIN payment c on a.PaymentId=c.Id " +
        //        "WHERE a.IsDeleted=0"
        //        .WhereIf("(b.Code=?code or b.Name like ?name)", ordersQuery.QueryData.IsNotEmpty())
        //        .WhereIf("a.Status=?Status", ordersQuery.Status != null)
        //        .WhereIf("a.Type=?Type", ordersQuery.Type != null)
        //        .WhereIf("a.CreateTime>=?BeginCreateTime and a.CreateTime<=?EndCreateTime", ordersQuery.BeginCreateTime != null && ordersQuery.EndCreateTime != null);
        //    string orderbySql = "ORDER BY a.LastUpdateTime DESC";
        //    ordersQuery.Param = new
        //    {
        //        ordersQuery.Status,
        //        ordersQuery.Type,
        //        code = ordersQuery.QueryData,
        //        name = $"%{ordersQuery.QueryData}%",
        //        BeginCreateTime = ordersQuery.BeginCreateTime.ToDateString(),
        //        EndCreateTime = ordersQuery.EndCreateTime.ToDateString() + " 23:59:59"
        //    };
        //    var result = await _sqlQuery.QueryPageAsync<OrdersDto>(selectSql, whereSql, orderbySql, ordersQuery);
        //    return result;
        //}
        //#endregion

        //#region 自诊
        ///// <summary>
        ///// 保存症状
        ///// </summary>
        ///// <param name="selfDiagnosisDto">自诊信息</param>
        ///// <returns></returns>
        //public async Task<SelfDiagnosisDto> CreateSelfDiagnosisAsync(SelfDiagnosisDto selfDiagnosisDto)
        //{
        //    var sql = "select * from SelfDiagnosis where OrdersId=?OrdersId";
        //    var data = (await _sqlQuery.QueryAsync<SelfDiagnosisDto>(sql, new { selfDiagnosisDto.OrdersId })).FirstOrDefault();
        //    if (data != null)
        //    {
        //        sql = "update SelfDiagnosis set Description=?Description,Other=?Other,LastUpdateId=?LastUpdateId,LastUpdateName=?LastUpdateName where Id=?Id";
        //        await _sqlQuery.ExecuteAsync(sql, new { selfDiagnosisDto.Description, selfDiagnosisDto.Other, LastUpdateId = UserContext.LoginKey, LastUpdateName = UserContext.LoginName, data.Id });
        //    }
        //    else
        //    {
        //        selfDiagnosisDto.Id = Uuid.Next();
        //        selfDiagnosisDto.CreateId = UserContext.LoginKey;
        //        selfDiagnosisDto.CreateName = UserContext.LoginName;
        //        selfDiagnosisDto.LastUpdateId = UserContext.LoginKey;
        //        selfDiagnosisDto.LastUpdateName = UserContext.LoginName;
        //        selfDiagnosisDto.CreateTime = DateTime.Now;
        //        selfDiagnosisDto.IsDeleted = false;
        //        selfDiagnosisDto.IsEnable = true;
        //        selfDiagnosisDto.LastUpdateTime = DateTime.Now;
        //        selfDiagnosisDto.Status = 1;
        //        selfDiagnosisDto.Version = Uuid.Next();
        //        _sqlQuery.Begin(true);
        //        await _sqlQuery.WriteDbConnection.InsertAsync(selfDiagnosisDto);
        //    }
        //    // 发送到HIS
        //    var orders = await _ordersRepository.RetrieveByIdAsync(selfDiagnosisDto.OrdersId);
        //    var message = new Message<AutognosisInput, string>();
        //    message.Type = AccessType.Autognosis;
        //    message.Input = new AutognosisInput()
        //    {
        //        OtherId = orders.OutId,
        //        Autognosis = selfDiagnosisDto.Other,
        //        Symptom = selfDiagnosisDto.Description
        //    };
        //    await MqttService.PublishAsync(message);
        //    return selfDiagnosisDto;
        //}
        ///// <summary>
        ///// 保存症状
        ///// </summary>
        ///// <param name="selfDiagnosisDto">自诊信息</param>
        ///// <returns></returns>
        //public async Task<SelfDiagnosisDto> QuerySelfDiagnosisAsync(SelfDiagnosisDto selfDiagnosisDto)
        //{
        //    if (selfDiagnosisDto.OrdersId.IsEmpty())
        //        return new SelfDiagnosisDto();
        //    var sql = "select * from SelfDiagnosis where OrdersId=?OrdersId";
        //    var data = (await _sqlQuery.QueryAsync<SelfDiagnosisDto>(sql, new { selfDiagnosisDto.OrdersId })).FirstOrDefault();
        //    var filedata = (await _storagesRepository.RetrieveAsync(t => t.OrdersId == selfDiagnosisDto.OrdersId)).ToList();
        //    if (filedata != null && filedata.Any())
        //    {
        //        data.ImageList = new List<ResultFile>();
        //        data.VideoList = new List<ResultFile>();
        //        foreach (var item in filedata)
        //        {
        //            if (item.FileType == StorageFileType.Image.Value())
        //            {
        //                data.ImageList.Add(new ResultFile()
        //                {
        //                    FileName = item.Name,
        //                    Key = item.NewName,
        //                    Path = item.Path
        //                });
        //            }
        //            else
        //            {
        //                data.VideoList.Add(new ResultFile()
        //                {
        //                    FileName = item.Name,
        //                    Key = item.NewName,
        //                    Path = item.Path
        //                });
        //            }
        //        }
        //    }
        //    return data;
        //}
        //#endregion

        #region 退款

        ///// <summary>
        ///// 获取退款订单信息
        ///// </summary>
        ///// <param name="ordersQuery">订单表查询对象</param>
        ///// <returns></returns>
        //public async Task<Paged<OrdersDto>> RefundPageAsync(OrdersQuery ordersQuery)
        //{
        //    string selectSql = "SELECT b.Id,b.ReservationID,b.OutId,b.CardId,b.OutPatientId,b.Type,b.`Status`,b.PaymentId,b.TradeNo,b.OutTradeNo,b.Amount," +
        //        "a.Reasons as Remark,b.Details,a.CreateTime as ApplicationTime,c.`Code` AS CardNo,c.`Name` AS PatientName,d.PayDate,a.FailureReasons,a.Status as RefundStatus,a.RefundAmount";
        //    string whereSql = "FROM Refund a LEFT JOIN orders b ON a.OrdersId=b.Id " +
        //        "LEFT JOIN card c ON b.CardId=c.Id LEFT JOIN payment d ON d.Id=b.PaymentId WHERE a.IsDeleted=0"
        //        .WhereIf("(c.`Code`=?code OR c.`Name` like ?name)", ordersQuery.QueryData.IsNotEmpty())
        //        .WhereIf("b.Type=?Type", ordersQuery.Type != null)
        //        .WhereIf("a.Status=?Status", ordersQuery.Status != null)
        //        .WhereIf("a.CreateTime>=?Being", ordersQuery.BeginCreateTime != null)
        //        .WhereIf("a.CreateTime<?End", ordersQuery.EndCreateTime != null);

        //    string orderbySql = "ORDER BY a.CreateTime DESC";
        //    ordersQuery.Param = new
        //    {
        //        ordersQuery.Status,
        //        ordersQuery.Type,
        //        code = ordersQuery.QueryData,
        //        name = $"%{ordersQuery.QueryData}%",
        //        Being = ordersQuery.BeginCreateTime,
        //        End = ordersQuery.EndCreateTime != null ? Helpers.Convert.ToDate(ordersQuery.EndCreateTime).AddDays(1) : ordersQuery.EndCreateTime
        //    };
        //    var result = await _sqlQuery.QueryPageAsync<OrdersDto>(selectSql, whereSql, orderbySql, ordersQuery);
        //    foreach (var item in result.Result)
        //    {

        //        if (item.Type == OrdersType.Register.Value())
        //        {
        //            item.ItemName = item.Register.UserName + item.Register.SittingDateStr + item.Register.DayTypeStr + item.Register.UseNo + "号";
        //        }
        //        else
        //        {
        //            item.ItemName = item.Outpatient.ItemName;
        //        }
        //        item.Money = (decimal)item.Amount / 100;
        //        item.RefundMoney = (decimal)item.RefundAmount.SafeValue() / 100;
        //    }
        //    return result;
        //}
        //#endregion

        //#region 获取待就诊挂号订单
        ///// <summary>
        ///// 就诊提醒
        ///// </summary>
        ///// <returns></returns>
        //public async Task QueryResgiterNoticeAsync()
        //{
        //    var begin = DateTime.Now.AddDays(1).ToDateString().ToDate();
        //    var end = DateTime.Now.AddDays(2).ToDateString().ToDate();
        //    var data = (await _ordersRepository.RetrieveAsync(t => t.SittingDate >= begin && t.SittingDate < end)).ToList().MapToList<OrdersDto>();
        //    if (data == null || !data.Any())
        //        return;
        //    foreach (var item in data)
        //    {
        //        //消息通知—就诊提醒
        //        WechatNoticeEvent noticeLog = new WechatNoticeEvent
        //        {
        //            TemplateType = "Consultation",
        //            AcceptId = "",
        //            Keyword1 = item.Register.PatientName + "（" + item.Register.CardNo + "）",
        //            Keyword2 = "",
        //            Keyword3 = item.Register.DepartmentName,
        //            Keyword4 = item.Register.SittingDateStr + " " + item.Register.TimeIntervalName,
        //            Keyword5 = item.Register.UserName,
        //            Param = item.CreateId
        //        };
        //        await _eventBus.PublishAsync(noticeLog);
        //    }
        //}
        //#endregion

        ///// <summary>
        ///// 根据坐诊编号获取订单信息(停诊)
        ///// </summary>
        ///// <param name="sittingIds"></param>
        ///// <returns></returns>
        //public async Task<List<OrdersDto>> RetrieveBySittingIdAsync(List<string> sittingIds)
        //{
        //    return (await _ordersRepository.RetrieveAsync(t => sittingIds.Contains(t.SittingId))).ToList().MapToList<OrdersDto>();
        //}

        //#region 便民
        ///// <summary>
        ///// 当天是否存在挂号信息
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //public async Task<OrdersDto> IsExistRegisterAsync(OrdersQuery ordersQuery)
        //{
        //    if (ordersQuery.CardId.IsEmpty())
        //        throw new Warning("未选择就诊人！");
        //    var list = (await _ordersRepository.RetrieveAsync(t => t.CardId == ordersQuery.CardId && t.SittingDate == DateTime.Now.ToDateString().ToDate() && (t.Status == OrdersStatus.Completed.Value() || t.Status == OrdersStatus.Paymented.Value()) && t.Type == OrdersType.Register.Value())).ToList();
        //    if (list == null || !list.Any())
        //        return null;
        //    if (list.Any(t => t.SittingId.IsNotEmpty()))
        //        throw new Warning("您今天已挂号，不可使用便民门诊！");
        //    return list.FirstOrDefault(t => t.SittingId.IsEmpty()).MapTo<OrdersDto>();
        //}
        ///// <summary>
        ///// 根据外部订单获取订单信息
        ///// </summary>
        ///// <param name="outTradeNo"></param>
        ///// <returns></returns>
        //public async Task<OrdersDto> GetOrdersByOutTradeNo(string outTradeNo)
        //{
        //    var sql = "select PaymentId,id,Type,Status,Type,UserId from orders where OutTradeNo=?outTradeNo";
        //    return (await _sqlQuery.QueryAsync<OrdersDto>(sql, new { outTradeNo = outTradeNo })).FirstOrDefault();
        //}

        //#endregion
        ///// <summary>
        ///// 发送消息
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //public async Task SendMessageAsync(OrdersDto dto)
        //{
        //    var orders = await _ordersRepository.RetrieveByIdAsync(dto.Id);
        //    if (orders == null)
        //        throw new Warning("订单信息不存在！");
        //    if (orders.CreateId.IsEmpty())
        //        throw new Warning("接收人编号不能为空！");
        //    var card = await _cardRepository.RetrieveByIdAsync(orders.CreateId);
        //    if (card == null)
        //        throw new Warning("接收人信息不存在！");
        //    var ordersDto = ToDto(orders);
        //    //消息通知
        //    WechatNoticeEvent message = new WechatNoticeEvent
        //    {
        //        TemplateType = "Message",
        //        AcceptId = card.WechatId,
        //        Keyword2 = ordersDto.Type == OrdersType.Register.Value() ? ordersDto.Register.UserName : ordersDto.Outpatient.UserName,
        //        Keyword3 = ordersDto.Type == OrdersType.Register.Value() ? ordersDto.Register.SittingDateStr : ordersDto.Outpatient.TimeStr,
        //        Keyword4 = ordersDto.Type == OrdersType.Register.Value() ? ordersDto.Register.PatientName : ordersDto.Outpatient.PatientName,
        //        Remark = dto.Remark,
        //        Param = orders.CreateId
        //    };
        //    await _eventBus.PublishAsync(message);
        //}
        //#region  咨询
        ///// <summary>
        ///// 当天是否已支付咨询费
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //public async Task<OrdersDto> IsExistPaymentedAsync(OrdersQuery ordersQuery)
        //{
        //    if (ordersQuery.Type == null || ordersQuery.UserId.IsEmpty())
        //        throw new Warning("医生编号错误！");
        //    var list = (await _ordersRepository.RetrieveAsync(t => t.CardId == ordersQuery.CardId && t.SittingDate == DateTime.Now.ToDateString().ToDate() && t.Status == OrdersStatus.Paymented.Value() && t.Type == ordersQuery.Type && t.UserId == ordersQuery.UserId && t.IsEnable)).ToList();
        //    if (list == null || !list.Any())
        //        return null;
        //    var date = DateTime.Now.ToDateString().ToDate();
        //    var chat = await _chatlogRepository.RetrieveAsync(t => t.ApplyTime >= DateTime.Now && t.EndTime == null && t.SendId == UserContext.LoginKey && t.AcceptId == ordersQuery.UserId && t.IsEnable);
        //    if (chat == null || !chat.Any())
        //        return null;
        //    return list.FirstOrDefault(t => t.SittingId.IsEmpty()).MapTo<OrdersDto>();
        //}

        ///// <summary>
        ///// 分页获取咨询订单
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //public async Task<Paged<OrdersDto>> ConsultPageAsync(OrdersQuery ordersQuery)
        //{
        //    string selectSql = "SELECT a.Id,a.Amount/100,a.Type,a.UserId,b.UserName,b.DepartmentName as Remark,c.PayDate,d.Path as avatarUrl ";
        //    string whereSql = "FROM orders a LEFT JOIN users b on a.UserId=b.Id LEFT JOIN payment c on a.OutTradeNo=c.OutTradeNo " +
        //        "LEFT JOIN storages d on b.AvatarUrl=d.NewName " +
        //        "WHERE a.Type in (9, 10, 11) and a.CardId = ?patientId and a.IsDeleted = 0 and c.Status = 2 ";
        //    string orderbySql = "ORDER BY c.PayDate DESC";
        //    ordersQuery.Param = new {
        //        patientId = ordersQuery.CardId
        //    };
        //    var result = await _sqlQuery.QueryPageAsync<OrdersDto>(selectSql, whereSql, orderbySql, ordersQuery);
        //    return result;
        //}
        ///// <summary>
        ///// 创建咨询订单
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //public async Task<OrdersDto> CreateConsultationOrdersAsync(OrdersDto dto)
        //{
        //    var oldorders = (await _ordersRepository.RetrieveAsync(t => t.CardId == dto.CardId && t.SittingDate == DateTime.Now.ToDateString().ToDate() && t.Status == OrdersStatus.Pay.Value() && t.Type == dto.Type && t.UserId == dto.UserId && t.IsEnable)).ToList();
        //    if (oldorders.Any())
        //        return ToDto(oldorders.FirstOrDefault());
        //    var card = await _cardRepository.RetrieveByIdAsync(dto.CardId);
        //    if (card == null)
        //        throw new Warning("当前就诊卡不存在！");
        //    var users = await _usersRepository.RetrieveByIdAsync(dto.UserId);
        //    if (users == null)
        //        throw new Warning("该医生已不存在，请联系医院！");
        //    var remark = "";
        //    decimal money = 0;
        //    if (dto.Type == OrdersType.Graphic.Value())
        //    {
        //        remark = "图文咨询费";
        //        money = users.GraphicFees ?? 0;
        //    }
        //    else if (dto.Type == OrdersType.Telephone.Value())
        //    {
        //        remark = "电话咨询费";
        //        money = users.TelephoneFee ?? 0;
        //    }
        //    else if (dto.Type == OrdersType.Video.Value())
        //    {
        //        remark = "视频咨询费";
        //        money = users.VideoFee ?? 0;
        //    }
        //    var ReservationId = "";
        //    if (Service.Configuration.Configuration.IsConResToHis && dto.Type == OrdersType.Telephone.Value())
        //    {
        //        // 发送到HIS
        //        var message = new Message<RegisterInput, RegisterResult>();
        //        message.Type = AccessType.BookingRegister;
        //        message.Input = new RegisterInput()
        //        {
        //            PatientNo = card.Code,
        //            UserId = users.OtherId,
        //            DateType = DateTime.Now.Hour > 12 ? 3 : 1,
        //            Date = DateTime.Now.ToDateString().ToDate(),
        //            Money = money,
        //            Remark = remark,
        //            PatientID = card.OtherId,
        //            Consultation = true
        //        };
        //        var result = await MqttService.PublishAsync(message);
        //        ReservationId = result.Result.ReservationId;
        //    }
        //    var register = new Register()
        //    {
        //        ReservationID = ReservationId,
        //        UserId = users.Id,
        //        UserName = users.UserName,
        //        Title = users.Title,
        //        DepartmentId = users.DepartmentId,
        //        DepartmentName = users.DepartmentName,
        //        SittingDate = DateTime.Now.ToDateString().ToDate(),
        //        DayType = DateTime.Now.Hour > 12 ? 3 : 1,
        //        TimeIntervalId = "",
        //        TimeIntervalName = "",
        //        Money = money,
        //        SittingAddress = "",
        //        CardId = card.Id,
        //        CardNo = card.Code,
        //        PatientName = card.Name,
        //        BookingMoney = 0
        //    };
        //    var ordersDto = new OrdersDto()
        //    {
        //        CardId = UserContext.LoginKey,
        //        OutPatientId = card.OtherId,
        //        Type = dto.Type,
        //        Status = OrdersStatus.Pay.Value(),
        //        Amount = System.Convert.ToInt32(money * 100),
        //        Remark = remark,
        //        ReservationID = ReservationId,
        //        Details = Json.ToJson(register),
        //        SittingId = "",
        //        OutTradeNo = Uuid.Next(),
        //        SittingDate = DateTime.Now.ToDateString().ToDate(),
        //        UserId = users.Id
        //    };
        //    return await CreateOrders(ordersDto);
        //}
        ///// <summary>
        ///// 创建咨询订单
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //public async Task<List<RegisterListResult>> QueryRegisterListAsync(OrdersQuery ordersQuery)
        //{
        //    var card = await _cardRepository.RetrieveByIdAsync(ordersQuery.CardId);
        //    if (card == null)
        //        throw new Warning("当前就诊卡信息不存在！");
        //    var message = new Message<RegisterListInput, List<RegisterListResult>>();
        //    message.Type = AccessType.QueryRegister;
        //    message.Input = new RegisterListInput()
        //    {
        //        PatientId = card.OtherId
        //    };
        //    var data = await MqttService.PublishAsync(message);
        //    if (data == null)
        //        return null;
        //    return data.Result;
        //}
        #endregion
    }
}