﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Service;
using Sand.Extensions;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Contract.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Maps;
using Newtonsoft.Json;
using Sand.Exceptions;
using Sand.Data;
using Dapper.Contrib.Extensions;
using Sand.Helpers;
using Sand.Domain.Entities.Payment;
using Microsoft.EntityFrameworkCore;
using Sand.Events;
using EasyCaching.Core;
using Sand.Service.Dtos.Systems;
using Sand.Domain.Chat.Events;

namespace Sand.Service.Impl.PaymentOrder
{
    /// <summary>
    ///  第三方支付信息服务
    /// </summary>
    public class PaymentService : BaseService<PaymentDto, PaymentQuery, Payment>, IPaymentService
    {
        /// <summary>
        ///  第三方支付信息仓储
        /// </summary>
        private readonly IPaymentRepository _paymentRepository;
        /// <summary>
        /// 支付日志仓储
        /// </summary>
        private readonly IPaymentlogRepository _paymentlogRepository;
        /// <summary>
        /// 订单表仓储
        /// </summary>
        private readonly IOrdersRepository _ordersRepository;
        /// <summary>
        /// OrdersLog订单日志表仓储
        /// </summary>
        private readonly IOrderslogRepository _orderslogRepository;
        /// <summary>
        /// 数据访问
        /// </summary>
        private readonly ISqlQuery _sqlQuery;
        /// <summary>
        /// 
        /// </summary>
        private IEventBus _eventBus;
        /// <summary>
        /// 缓存工厂
        /// </summary>
        private readonly IEasyCachingProviderFactory _cachingFactory;
        /// <summary>
        /// convenientorder仓储
        /// </summary>
        private readonly IConvenientorderRepository _convenientorderRepository;

        /// <summary>
        /// 初始化 第三方支付信息服务
        /// </summary>

        /// <param name="paymentRepository"> 第三方支付信息仓储</param>
        /// <param name="paymentlogRepository"> 支付日志仓储</param>
        /// <param name="ordersRepository"> 订单表仓储</param>
        /// <param name="orderslogRepository"> OrdersLog订单日志表仓储</param>
        /// <param name="sqlQuery"> 数据访问</param>
        /// <param name="eventBus"></param>
        /// <param name="cachingFactory"></param>
        /// <param name="countCacheService">计数判断</param>
        /// <param name="usersRepository">用户表仓储</param>
        /// <param name="convenientorderRepository">convenientorder仓储</param>
        /// <param name="cardRepository">就诊卡仓储</param>
        public PaymentService(IPaymentRepository paymentRepository, IPaymentlogRepository paymentlogRepository,
            IOrdersRepository ordersRepository, IOrderslogRepository orderslogRepository, ISqlQuery sqlQuery,
            IEventBus eventBus, IEasyCachingProviderFactory cachingFactory, IConvenientorderRepository convenientorderRepository)
           : base(paymentRepository)
        {
            _paymentRepository = paymentRepository;
            _paymentlogRepository = paymentlogRepository;
            _ordersRepository = ordersRepository;
            _orderslogRepository = orderslogRepository;
            _sqlQuery = sqlQuery;
            _eventBus = eventBus;
            _cachingFactory = cachingFactory;
            _convenientorderRepository = convenientorderRepository;
        }

        /// <summary>
        /// 创建 第三方支付信息条件表达式
        /// </summary>
        /// <param name="paymentQuery"> 第三方支付信息查询对象</param>
        /// <returns> 第三方支付信息查询表达式</returns>
        protected override Expression<Func<Payment, bool>> CreateQuery(PaymentQuery paymentQuery)
        {
            return base.CreateQuery(paymentQuery);
        }
        /// <summary>
        /// 根据编号查询 第三方支付信息信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override async Task<PaymentDto> RetrieveByIdAsync(string id)
        {
            var result = ToDto(await _paymentRepository.RetrieveByIdAsync(id));
            result.Paymentlog = (await _paymentlogRepository.RetrieveAsync(t => t.PaymentId == id)).ToList().MapToList<PaymentlogDto>();
            return result;
        }

        /// <summary>
        /// 获取支付结果
        /// </summary>
        /// <param name="outTradeNo"></param>
        /// <returns></returns>
        public async Task<PayModel> QueryPayResult(string outTradeNo)
        {
            //var api = HttpApi.Resolve<IAppProxyApi>();
            //var payModel = new PayModel() { OutTradeNo = outTradeNo };
            //var result = await api.QueryPayResultAsync(payModel);
            //if (result.Code == Utils.Enums.StateCode.Fail)
            //    throw new Warning(result.Message, "W04");
            //return result.Data;
            return await Task.FromResult(new PayModel());
        }

        #region 挂号支付
        ///// <summary>
        ///// 预约挂号支付
        ///// </summary>
        ///// <param name="orders"></param>
        ///// <returns></returns>
        //public async Task<PaymentDto> RegisterPay(OrdersDto orders)
        //{
        //    try
        //    {
        //        //确认单据信息时间
        //        var dto = (await _ordersRepository.RetrieveByIdAsync(orders.Id)).MapTo<OrdersDto>();
        //        if (dto.Status != OrdersStatus.Pay.Value())
        //            return (await _paymentRepository.RetrieveByIdAsync(dto.PaymentId)).MapTo<PaymentDto>();
        //        var users = await _usersRepository.RetrieveByIdAsync(dto.UserId);
        //        List<int> TaxonData = new List<int>();
        //        if (users.Taxon.IsNotEmpty())
        //        {
        //            var data1 = users.Taxon.Split('|');
        //            for (int i = 0; i < data1.Length; i++)
        //            {
        //                if (data1[i].IsNotEmpty())
        //                    TaxonData.Add(data1[i].ToInt());
        //            }
        //        }
        //        if (!Service.Configuration.Configuration.IsZeroRegistration || !TaxonData.Any(t => t == TaxonType.FreeRegistration.Value()))
        //        {
        //            var data = await QueryPayResult(dto.OutTradeNo);
        //            NLog.LogManager.GetLogger("Payment").Warn(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---QueryPayResult：" + Json.ToJson(data));
        //            dto.TradeNo = data.TradeNo;
        //            if (dto.Amount != data.TotalAmount)
        //                throw new Warning("支付金额与系统金额不一致！");
        //        }
        //        //his收费表添加插入挂号信息
        //        var registerResult = await CreateHISRegister(dto, 1);
        //        var register = JsonConvert.DeserializeObject<Register>(dto.Details);
        //        register.UseNo = registerResult.UseNo;
        //        //修改订单信息状态、支付平台订单号、系统订单号
        //        await _ordersRepository.UpdateAsync(t => t.Id == dto.Id, t => new Orders() { TradeNo = dto.TradeNo, Status = OrdersStatus.Paymented.Value(), PaymentId = dto.PaymentId, OutId = registerResult.ChargeId, Details = JsonConvert.SerializeObject(register) });

        //        dto.TradeNo = dto.TradeNo;
        //        dto.Status = OrdersStatus.Paymented.Value();
        //        dto.PaymentId = dto.PaymentId;
        //        dto.OutId = registerResult.ChargeId;
        //        //添加订单日志信息(已支付)
        //        await CreateOrderLog(dto.MapTo<Orders>());
        //        //支付记录（支付成功）
        //        var payment = await UpdatePayment(dto, PaymentStatus.Success);
        //        var r = new Domain.DomainService.MongoEntites.Register()
        //        {
        //            OrdersId = dto.Id,
        //            CardId = dto.CardId,
        //            CardNo = register.CardNo,
        //            PatientName = register.PatientName,
        //            UserId = register.UserId,
        //            UserName = register.UserName,
        //            SittingDate = register.SittingDate,
        //            DayType = register.DayType,
        //            TimeIntervalId = register.TimeIntervalId,
        //            TimeIntervalName = register.TimeIntervalName,
        //            DepartmentId = register.DepartmentId,
        //            DepartmentName = register.DepartmentName,
        //            UseNo = register.UseNo,
        //            Money = register.Money,
        //            Status = dto.Status
        //        };
        //        //患者消息通知
        //        WechatNoticeEvent resgiterLog = new WechatNoticeEvent
        //        {
        //            TemplateType = "Resgiter",
        //            AcceptId = UserContext.WxOpenId,
        //            Keyword1 = dto.TradeNo,
        //            Keyword2 = dto.Register.SittingDateStr + " " + dto.Register.TimeIntervalName,
        //            Keyword3 = dto.Register.DepartmentName + "(" + dto.Register.SittingAddress + ")",
        //            Keyword4 = dto.Register.UserName,
        //            Keyword5 = dto.Register.PatientName + "（" + dto.Register.CardNo + "）",
        //            Remark = "请及时前往就诊，过时作废！",
        //            Param = dto.CardId,
        //            Register = r
        //        };
        //        await _eventBus.PublishAsync(resgiterLog);
        //        if (users.WeiXinKey.IsNotEmpty())
        //        {
        //            //医生通知消息 
        //            WechatNoticeEvent message = new WechatNoticeEvent
        //            {
        //                TemplateType = "Message",
        //                AcceptId = users.WeiXinKey,
        //                Keyword2 = users.UserName,
        //                Keyword3 = dto.Register.SittingDateStr,
        //                Keyword4 = dto.Register.PatientName,
        //                Remark = "您有一个新的挂号订单！",
        //                Param = users.Id,
        //            };
        //            await _eventBus.PublishAsync(message);
        //        }
        //        //支付完成移除缓存
        //        var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
        //        await provider.RemoveAsync("registerpaykey:" + dto.Id);
        //        return payment.MapTo<PaymentDto>();
        //    }
        //    catch (Exception ex)
        //    {
        //        NLog.LogManager.GetLogger("Payment").Warn(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---预约挂号支付异常：" + ex.Message);
        //        throw new Transform(ex.Message, new { OrdersId = orders.Id });
        //    }
        //}
        ///// <summary>
        ///// his收费表添加插入挂号信息
        ///// </summary>
        ///// <param name="orders">订单信息</param>
        ///// <param name="isPay">1.支付成功 0.支付失败、取消支付</param>
        ///// <returns></returns>
        //private static async Task<RegisterResult> CreateHISRegister(OrdersDto orders, int isPay)
        //{
        //    NLog.LogManager.GetLogger("Payment").Warn(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---CreateHISRegister：" + Json.ToJson(orders));
        //    var message = new Message<RegisterPayInput, RegisterResult>();
        //    message.Type = AccessType.RegisterPay;
        //    message.Input = new RegisterPayInput()
        //    {
        //        ReservationId = orders.ReservationID,
        //        PayType = PayType.Public.Value(),
        //        IsPay = isPay,
        //        PlatformOrderCode = orders.OutTradeNo,
        //        ResultOrderCode = orders.TradeNo,
        //        IsConvenient = orders.SittingId.IsEmpty()
        //    };
        //    var data = await MqttService.PublishAsync(message);
        //    return data.Result;
        //}

        /// <summary>
        /// 创建订单日志
        /// </summary>
        /// <param name="orders"></param>
        /// <returns></returns>
        private async Task CreateOrderLog(Orders orders)
        {
            // 添加订单日志
            var orderslog = new Orderslog()
            {
                OrdersChargeLog = JsonConvert.SerializeObject(orders),
                OrdersId = orders.Id.ToString(),
                Status = orders.Status
            };
            await _orderslogRepository.CreateAsync(orderslog);
        }
        /// <summary>
        /// 修改支付记录、创建支付记录日志
        /// </summary>
        /// <param name="orders">订单信息</param>
        /// <param name="status">支付状态</param>
        /// <returns></returns>
        private async Task<Payment> UpdatePayment(OrdersDto orders, PaymentStatus status)
        {
            var payment = new Payment()
            {
                Id = orders.PaymentId,
                Amount = orders.Amount,
                ComfirmAmount = orders.Amount,
                PayPlatform = PayPlatformType.WeChat.Value(),
                PayType = PayType.Public.Value(),
                PayUserId = UserContext.LoginKey,
                PayUserName = UserContext.LoginName,
                RefundAmount = 0,
                Status = status.Value(),
                OutTradeNo = orders.OutTradeNo,
                TradeNo = orders.TradeNo,
                PayDate = DateTime.Now
            };
            Paymentlog paymentlog = new Paymentlog()
            {
                PaymentId = orders.PaymentId,
                Amount = orders.Amount,
                Input = "",
                Ip = "",
                Output = "",
                PaymentChargeLog = JsonConvert.SerializeObject(payment),
                Status = status.Value()
            };
            await _paymentlogRepository.CreateAsync(paymentlog);
            await _paymentRepository.UpdateAsync(t => t.Id == orders.PaymentId, t => new Payment() { Status = status.Value(), TradeNo = orders.TradeNo, PayDate = payment.PayDate, PayUserId = payment.PayUserId, PayUserName = payment.PayUserName });
            return payment;
        }

        /// <summary>
        /// 取消支付（预约挂号订单）
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        //public async Task CancelRegister(OrdersDto dto)
        //{
        //    var orders = (await _ordersRepository.RetrieveAsync(t => t.ReservationID == dto.ReservationID && t.Status == OrdersStatus.Pay.Value())).ToList();
        //    if (orders.Any())
        //    {
        //        var order = orders.FirstOrDefault();
        //        await _paymentRepository.UpdateAsync(t => t.Id == order.PaymentId, t => new Payment() { Status = PaymentStatus.Cancelled.Value() });
        //        var paymentlog = new Paymentlog()
        //        {
        //            Status = PaymentStatus.Cancelled.Value(),
        //            PaymentId = order.PaymentId,
        //            //PaymentChargeLog = JsonConvert.SerializeObject(order)
        //        };
        //        await _paymentlogRepository.CreateAsync(paymentlog);
        //        await _ordersRepository.UpdateAsync(t => t.Id == order.Id, t => new Orders() { Status = OrdersStatus.Cancelled.Value() });
        //        order.Status = OrdersStatus.Cancelled.Value();
        //        var orderslog = new Orderslog()
        //        {
        //            Status = OrdersStatus.Cancelled.Value(),
        //            OrdersId = order.Id,
        //            OrdersChargeLog = JsonConvert.SerializeObject(order)
        //        };
        //        await _orderslogRepository.CreateAsync(orderslog);
        //        await _countCacheService.SetCount(order.CreateId, SysCountType.CancelRegister);
        //    }
        //    await CreateHISRegister(dto, 0);
        //}
        #endregion

        #region 门诊费用支付
        ///// <summary>
        ///// 门诊费用支付
        ///// </summary>
        ///// <param name="orders"></param>
        ///// <returns></returns>
        //public async Task<PaymentDto> OutpatientPay(List<OrdersDto> orders)
        //{
        //    try
        //    {
        //        var dto = orders.FirstOrDefault(t => !string.IsNullOrEmpty(t.PaymentId));
        //        if (dto == null)
        //        {
        //            throw new Warning("订单已不存在,请查看列表！");
        //        }
        //        //设置更新时间
        //        var data = await QueryPayResult(dto.OutTradeNo);
        //        var itemname = "";
        //        //修改his收费表信息
        //        var message = new Message<List<OrderPayInput>, string>();
        //        message.Type = AccessType.OrderPay;
        //        List<OrderPayInput> list = new List<OrderPayInput>();
        //        foreach (var item in orders)
        //        {
        //            itemname += "," + item.Outpatient.ItemName;
        //            list.Add(new OrderPayInput()
        //            {
        //                Id = item.OutId,
        //                Money = (decimal)item.Amount / 100,
        //                PlatformOrderCode = dto.OutTradeNo,
        //                ResultOrderCode = data.TradeNo,
        //                ItemName = item.Outpatient.ItemName
        //            });
        //        }
        //        message.Input = list;
        //        await MqttService.PublishAsync(message);
        //        //修改订单信息状态、支付平台订单号、系统订单号
        //        await _ordersRepository.UpdateAsync(t => orders.Select(p => p.Id).Contains(t.Id), t => new Orders() { TradeNo = data.TradeNo, OutTradeNo = dto.OutTradeNo, Status = OrdersStatus.Paymented.Value() });
        //        var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
        //        foreach (var item in orders)
        //        {
        //            item.TradeNo = data.TradeNo;
        //            item.OutTradeNo = dto.OutTradeNo;
        //            item.Status = OrdersStatus.Paymented.Value();
        //        }
        //        //添加订单日志信息(已支付)
        //        await CreateOrderLogList(orders.MapToList<Orders>());
        //        //支付记录（支付成功）
        //        var payment = (await UpdatePayment(orders, PaymentStatus.Success)).MapTo<PaymentDto>();
        //        //修改便民订单状态
        //        foreach (var item in orders.Where(t => t.ConvenientOrderId.IsNotEmpty()).Distinct().ToList())
        //        {
        //            await provider.TrySetAsync("convenientorderkey:" + item.ConvenientOrderId, item.ConvenientOrderId, TimeSpan.FromSeconds(60 * 60));
        //        }
        //        var ordersdata = (await _ordersRepository.RetrieveAsync(t => orders.Select(p => p.Id).Contains(t.Id) && t.ConvenientOrderId.IsNotEmpty())).ToList();
        //        if (ordersdata != null && ordersdata.Any())
        //        {
        //            NLog.LogManager.GetLogger("Debug").Info(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---门诊缴费修改便民订单状态：" + Json.ToJson(ordersdata));
        //            var ids = ordersdata.Select(t => t.ConvenientOrderId).ToList();
        //            await _convenientorderRepository.UpdateAsync(t => ids.Contains(t.Id), t => new Convenientorder() { Status = ConvenientOrderStatus.Payment.Value() });
        //            foreach (var item in ids)
        //            {
        //                await provider.RemoveAsync("convenientorderkey:" + item);
        //            }
        //        }
        //        //消息通知
        //        WechatNoticeEvent drugsLog = new WechatNoticeEvent
        //        {
        //            TemplateType = "Payment",
        //            AcceptId = UserContext.WxOpenId,
        //            Keyword1 = dto.Outpatient.PatientName + "(" + dto.Outpatient.PatientNo + ")",
        //            Keyword2 = dto.Outpatient.DepartmentName + "(" + dto.Outpatient.DepartmentAddress + ")",
        //            Keyword3 = string.IsNullOrEmpty(itemname) ? "" : itemname.Substring(1),
        //            Keyword4 = payment.Money.ToString(),
        //            Keyword5 = payment.PayDateStr,
        //            Param = dto.CardId
        //        };
        //        await _eventBus.PublishAsync(drugsLog);
        //        //支付完成移除缓存
        //        await provider.RemoveAsync("outpatientpaykey:" + payment.Id);
        //        return payment;
        //    }
        //    catch (Exception ex)
        //    {
        //        NLog.LogManager.GetLogger("Payment").Info(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---门诊缴费异常：" + ex.Message);
        //        var paymentId = orders.FirstOrDefault(t => !string.IsNullOrEmpty(t.PaymentId)).PaymentId;
        //        throw new Transform(ex.Message, new { PaymentId = paymentId });
        //    }
        //}

        /// <summary>
        /// 创建订单日志
        /// </summary>
        /// <param name="orders"></param>
        /// <returns></returns>
        private async Task CreateOrderLogList(List<Orders> orders)
        {
            // 添加订单日志
            var list = new List<Orderslog>();
            foreach (var item in orders)
            {
                var orderslog = new Orderslog()
                {
                    OrdersChargeLog = JsonConvert.SerializeObject(item),
                    OrdersId = item.Id.ToString(),
                    Status = item.Status
                };
                list.Add(orderslog);
            }
            await _orderslogRepository.CreateListAsync(list);
        }
        /// <summary>
        /// 修改支付记录、创建支付记录日志
        /// </summary>
        /// <param name="orders">订单信息</param>
        /// <param name="status">支付状态</param>
        /// <returns></returns>
        private async Task<Payment> UpdatePayment(List<OrdersDto> orders, PaymentStatus status)
        {
            var dto = orders.FirstOrDefault(t => !string.IsNullOrEmpty(t.PaymentId));
            var payment = new Payment()
            {
                Id = dto.PaymentId,
                Amount = orders.Sum(t => t.Amount),
                ComfirmAmount = orders.Sum(t => t.Amount),
                PayPlatform = PayPlatformType.WeChat.Value(),
                PayType = PayType.Public.Value(),
                PayUserId = UserContext.LoginKey,
                PayUserName = UserContext.LoginName,
                RefundAmount = 0,
                Status = status.Value(),
                OutTradeNo = dto.OutTradeNo,
                TradeNo = dto.TradeNo,
                PayDate = DateTime.Now
            };
            await _paymentRepository.UpdateAsync(t => t.Id == payment.Id, t => new Payment() { Status = status.Value(), PayDate = payment.PayDate, PayUserId = payment.PayUserId, PayUserName = payment.PayUserName, TradeNo = dto.TradeNo });
            Paymentlog paymentlog = new Paymentlog()
            {
                PaymentId = payment.Id,
                Amount = payment.Amount,
                Input = "",
                Ip = "",
                Output = "",
                PaymentChargeLog = JsonConvert.SerializeObject(payment),
                Status = status.Value()
            };
            await _paymentlogRepository.CreateAsync(paymentlog);
            return payment;
        }
        /// <summary>
        /// 获取门诊缴费待支付订单
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public async Task<List<OrdersDto>> OutpatientPayingOrders(OrdersQuery query)
        {
            //var orders = await _ordersRepository.RetrieveAsync(t => t.CardId == UserContext.LoginKey && t.Status == OrdersStatus.Pay.Value() && t.Type != OrdersType.Register.Value());
            string sql = "SELECT a.*,b.Name as PatientName,b.Code as CardNo " +
                "FROM orders a LEFT JOIN card b on a.CardId=b.Id " +
                "LEFT JOIN family c on b.Id=c.CardId WHERE a.IsDeleted=0"
                .Add("AND a.Status=?Status")
                .Add("AND a.Type<>?Type")
                .Add("AND (c.MainCardId=?CardId OR b.Id=?CardId)");
            var orders = (await _sqlQuery.QueryAsync<OrdersDto>(sql, new { Status = OrdersStatus.Pay.Value(), Type = OrdersType.Register.Value(), CardId = UserContext.LoginKey })).ToList();
            var list = new List<OrdersDto>();
            foreach (var item in orders)
            {
                if (list.Any(t => t.PaymentId == item.PaymentId))
                {
                    var dto = list.FirstOrDefault(t => t.PaymentId == item.PaymentId);
                    if ((item.ConvenientOrderId.IsNotEmpty() && item.Type != OrdersType.Other.Value()) || item.ConvenientOrderId.IsEmpty())
                        dto.ItemName += "+" + item.Outpatient.ItemName;
                    dto.Money += (decimal)item.Amount / 100;
                }
                else
                {
                    item.ItemName = item.Outpatient.ItemName;
                    item.Money = (decimal)item.Amount / 100;
                    list.Add(item);
                }
            }
            return list;
        }

        ///// <summary>
        ///// 门诊费用取消支付
        ///// </summary>
        ///// <param name="list"></param>
        ///// <returns></returns>
        //public async Task CancelOutpatientPay(List<OrdersDto> list)
        //{
        //    if (list != null && list.Any())
        //    {
        //        var orders = list.FirstOrDefault();
        //        await _paymentRepository.UpdateAsync(t => t.Id == orders.PaymentId, t => new Payment() { Status = PaymentStatus.Cancelled.Value() });
        //        var paymentlog = new Paymentlog()
        //        {
        //            Status = PaymentStatus.Cancelled.Value(),
        //            PaymentId = orders.PaymentId,
        //            //PaymentChargeLog = JsonConvert.SerializeObject(order)
        //        };
        //        await _paymentlogRepository.CreateAsync(paymentlog);
        //        await _ordersRepository.UpdateAsync(t => t.PaymentId == orders.PaymentId, t => new Orders() { Status = OrdersStatus.Cancelled.Value() });
        //        var orderslog = new List<Orderslog>();
        //        foreach (var item in list)
        //        {
        //            item.Status = OrdersStatus.Cancelled.Value();
        //            orderslog.Add(new Orderslog()
        //            {
        //                Status = OrdersStatus.Cancelled.Value(),
        //                OrdersId = item.Id,
        //                OrdersChargeLog = JsonConvert.SerializeObject(item)
        //            }
        //                );
        //        }
        //        await _orderslogRepository.CreateListAsync(orderslog);
        //        //HIS修改订单生成时间
        //        var message = new Message<PaymentInput, PaymentResult>();
        //        message.Type = AccessType.UpdateLockTime;
        //        message.Input = new PaymentInput()
        //        {
        //            ChargeIdData = list.Select(t => t.OutId).ToList(),
        //            OrderCreateTime = null
        //        };
        //        await MqttService.PublishAsync(message);
        //    }
        //}
        ///// <summary>
        ///// 门诊确认支付
        ///// </summary>
        ///// <param name="paymentDto"></param>
        ///// <returns></returns>
        //public async Task<PaymentDto> ConfirmPaymentAsync(PaymentDto paymentDto)
        //{
        //    var payment = await _paymentRepository.RetrieveByIdAsync(paymentDto.Id);
        //    if (payment.Status != PaymentStatus.Waiting.Value())
        //        return ToDto(payment);
        //    var data = await QueryPayResult(paymentDto.OutTradeNo);
        //    if (payment.Amount != data.TotalAmount)
        //        throw new Warning("支付金额与系统金额不一致！");
        //    var ordersData = (await _ordersRepository.RetrieveAsync(t => t.PaymentId == paymentDto.Id)).ToList().MapToList<OrdersDto>();
        //    //修改his收费表信息
        //    var message = new Message<List<OrderPayInput>, string>();
        //    message.Type = AccessType.OrderPay;
        //    List<OrderPayInput> list = new List<OrderPayInput>();
        //    var itemname = "";
        //    foreach (var item in ordersData)
        //    {
        //        itemname += "," + item.Outpatient.ItemName;
        //        list.Add(new OrderPayInput()
        //        {
        //            Id = item.OutId,
        //            Money = (decimal)item.Amount / 100,
        //            PlatformOrderCode = payment.OutTradeNo,
        //            ResultOrderCode = data.TradeNo
        //        });
        //    }
        //    message.Input = list;
        //    await MqttService.PublishAsync(message);
        //    //修改订单信息状态、支付平台订单号、系统订单号
        //    await _ordersRepository.UpdateAsync(t => paymentDto.Id == t.PaymentId, t => new Orders() { TradeNo = data.TradeNo, OutTradeNo = payment.OutTradeNo, Status = OrdersStatus.Paymented.Value() });
        //    foreach (var item in ordersData)
        //    {
        //        item.TradeNo = data.TradeNo;
        //        item.OutTradeNo = payment.OutTradeNo;
        //        item.Status = OrdersStatus.Paymented.Value();
        //    }
        //    //添加订单日志信息(已支付)
        //    await CreateOrderLogList(ordersData.MapToList<Orders>());
        //    //支付记录（支付成功）
        //    var result = await UpdatePayment(ordersData.MapToList<OrdersDto>(), PaymentStatus.Success);
        //    var dto = ordersData.FirstOrDefault();
        //    //消息通知
        //    WechatNoticeEvent drugsLog = new WechatNoticeEvent
        //    {
        //        TemplateType = "Payment",
        //        AcceptId = UserContext.WxOpenId,
        //        Keyword1 = dto.Outpatient.PatientName + "(" + dto.Outpatient.PatientNo + ")",
        //        Keyword2 = dto.Outpatient.DepartmentName + "(" + dto.Outpatient.DepartmentAddress + ")",
        //        Keyword3 = string.IsNullOrEmpty(itemname) ? "" : itemname.Substring(1),
        //        Keyword4 = ((decimal)payment.Amount / 100).ToString("f2"),
        //        Keyword5 = payment.PayDate.ToDateTimeString(true),
        //        Param = dto.CreateId
        //    };
        //    await _eventBus.PublishAsync(drugsLog);
        //    return result.MapTo<PaymentDto>();
        //}
        //#endregion

        #region 退费审核
        /// <summary>
        /// 退费审核
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<OrdersDto> RefundsAuditAsync(OrdersDto dto)
        {
            return dto;
            dto.RefundAmount = dto.IsRefundSubscribe.SafeValue() ? dto.Amount : (dto.Amount - (int)(dto.Register.BookingMoney * 100));
            Payment payment = await Refund(dto);
            // HIS退费
            //var message = new Message<RefundInput, RefundResult>();
            //message.Type = AccessType.Refund;
            //message.Input = new RefundInput()
            //{
            //    ChargeID = dto.OutId,
            //    Money = (decimal)dto.RefundAmount.SafeValue() / 100,
            //    IsRefundSubscribe = dto.IsRefundSubscribe.SafeValue()
            //};
            //await MqttService.PublishAsync(message);
            ////退费
            //var api = HttpApi.Resolve<IAppProxyApi>();
            var payModel = new PayModel()
            {
                TradeNo = dto.TradeNo,
                RefundAmount = dto.RefundAmount.SafeValue(),
                RefundDesc = dto.Remark,
                TotalAmount = payment.Amount ?? 0,
                OutTradeNo = dto.OutTradeNo,
                OutRefundNo = dto.OutId
            };
            //  var result = await api.RefundAsync(payModel);
            RefundEvent refundEvent = new RefundEvent
            {
                OrdersId = dto.Id,
                Status = RefundStatus.Refunding,
                UserId = UserContext.LoginKey,
                UserName = UserContext.LoginName
            };
            //if (result.Code == Utils.Enums.StateCode.Fail)
            //{
            //    refundEvent.Status = RefundStatus.PlatformFailure;
            //    await _eventBus.PublishAsync(refundEvent);
            //    throw new Warning(result.Message);
            //}
            //退款记录
            refundEvent.Status = RefundStatus.Success;
            await _eventBus.PublishAsync(refundEvent);
            dto.RefundMoney = (decimal)dto.RefundAmount.SafeValue() / 100;
            //消息通知
            WechatNoticeEvent noticeEvent = new WechatNoticeEvent
            {
                TemplateType = "RefundSuccessNotice",
                AcceptId = "",
                Keyword1 = dto.TradeNo,
                Keyword2 = dto.Type == OrdersType.Register.Value() ? "挂号" : dto.Outpatient.ItemName,
                Keyword3 = dto.RefundMoney.ToString("f2"),
                Keyword4 = DateTime.Now.ToDateTimeString(true),
                Keyword5 = "退款有一定延时，退款3个工作日内到账！",
                Remark = dto.Type == OrdersType.Register.Value() ? "注：非医院原因，一月内退款不能超过3次，否则将暂停使用微信平台挂号！" : "感谢您的使用！",
                Param = payment.CreateId
            };
            await _eventBus.PublishAsync(noticeEvent);
            //Log.Log.GetLog("debug").Trace(Json.ToJson(noticeEvent));
        }
        /// <summary>
        /// 本地订单退款处理
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        private async Task<Payment> Refund(OrdersDto dto)
        {
            var payment = await _paymentRepository.RetrieveByIdAsync(dto.PaymentId);
            if (!(payment.Status == PaymentStatus.Success.Value() || payment.Status == PaymentStatus.PartialRefund.Value()))
                throw new Warning("该订单状态为" + ((PaymentStatus)payment.Status).DisplayName() + ",不能执行退费！");
            // 修改订单状态
            dto.Status = OrdersStatus.Refund.Value();
            await _ordersRepository.UpdateAsync(t => t.Id == dto.Id, t => new Orders { Status = dto.Status });
            await CreateOrderLog(dto.MapTo<Orders>());
            //修改支付状态
            payment.Status = PaymentStatus.Refund.Value();
            if (payment.Amount.SafeValue() > dto.RefundAmount.SafeValue() + payment.RefundAmount.SafeValue())
                payment.Status = PaymentStatus.PartialRefund.Value();
            await _paymentRepository.UpdateAsync(t => t.Id == dto.PaymentId, t => new Payment() { RefundAmount = t.RefundAmount.SafeValue() + dto.RefundAmount.SafeValue(), Status = payment.Status });
            Paymentlog paymentlog = new Paymentlog()
            {
                PaymentId = payment.Id,
                Amount = -dto.RefundAmount,
                Input = "",
                Ip = "",
                Output = "",
                PaymentChargeLog = JsonConvert.SerializeObject(payment),
                Status = payment.Status
            };
            await _paymentlogRepository.CreateAsync(paymentlog);
            return payment;
        }

        /// <summary>
        /// 退费审核不通过
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task RefundsAuditNotPassedAsync(OrdersDto dto)
        {
            // 修改订单状态
            dto.Status = OrdersStatus.Paymented.Value();
            await _ordersRepository.UpdateAsync(t => t.Id == dto.Id, t => new Orders { Status = dto.Status });
            await CreateOrderLog(dto.MapTo<Orders>());
            //修改为退款审核不通过
            //RefundEvent refundEvent = new RefundEvent
            //{
            //    OrdersId = dto.Id,
            //    Status = RefundStatus.Failure,
            //    Remark = dto.Remark,
            //    UserId = UserContext.LoginKey,
            //    UserName = UserContext.LoginName
            //};
            //await _eventBus.PublishAsync(refundEvent);
            ////消息通知
            WechatNoticeEvent noticeEvent = new WechatNoticeEvent
            {
                TemplateType = "RefundFailNotice",
                AcceptId = "",
                Keyword1 = dto.TradeNo,
                Keyword2 = dto.Money.ToString("f2"),
                Keyword3 = dto.Remark,
                Remark = "请您直接到医院服务台进行咨询办理，如有不便， 敬请谅解。",
                Param = dto.CardId
            };
            await _eventBus.PublishAsync(noticeEvent);
            //Log.Log.GetLog("debug").Trace(Json.ToJson(noticeEvent));
        }
        #endregion

        //#region 咨询支付
        ///// <summary>
        ///// 咨询支付
        ///// </summary>
        ///// <param name="consultationPayDto"></param>
        ///// <returns></returns>
        //public async Task<PaymentDto> ConsultationPay(ConsultationPayDto consultationPayDto)
        //{
        //    try
        //    {
        //        //确认单据信息时间
        //        var dto = (await _ordersRepository.RetrieveByIdAsync(consultationPayDto.OrdersId)).MapTo<OrdersDto>();
        //        if (dto.Status != OrdersStatus.Pay.Value())
        //            return (await _paymentRepository.RetrieveByIdAsync(dto.PaymentId)).MapTo<PaymentDto>();
        //        var userssql = "select a.Id,a.UserName,a.GraphicFees,a.VideoFee,a.TelephoneFee,a.OtherId,b.OtherId as DepartmentId " +
        //            "from users a left join dics b on a.DepartmentId=b.Id " +
        //            "where a.Id=@UserId";
        //        var userslist =( await _sqlQuery.QueryAsync<UsersDto>(userssql, new { dto.UserId })).ToList();
        //        if (userslist == null || !userslist.Any())
        //            throw new Warning("当前医生信息不存在！");
        //        var users = userslist.FirstOrDefault();
        //        decimal money = 0;
        //        if (dto.Type == OrdersType.Graphic.Value())
        //        {
        //            money = users.GraphicFees.SafeValue();
        //            consultationPayDto.ServiceType = 1;
        //        }
        //        else if (dto.Type == OrdersType.Telephone.Value())
        //        {
        //            money = users.TelephoneFee.SafeValue();
        //            consultationPayDto.ServiceType = 2;
        //        }
        //        else if (dto.Type == OrdersType.Video.Value())
        //        {
        //            money = users.VideoFee.SafeValue();
        //        }
        //        if (money > 0 && dto.Amount > 0)
        //        {
        //            var data = await QueryPayResult(dto.OutTradeNo);
        //            NLog.LogManager.GetLogger("Payment").Warn(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "--咨询支付--QueryPayResult：" + Json.ToJson(data));
        //            dto.TradeNo = data.TradeNo;
        //            if (dto.Amount != data.TotalAmount)
        //                throw new Warning("支付金额与系统金额不一致！");
        //        }
        //        //his收费表添加插入挂号信息
        //        var register = JsonConvert.DeserializeObject<Register>(dto.Details);
        //        //his收费表添加插入挂号信息
        //        var hismessage = new Message<ConsultationPayInput, ConsultationPayResult>();
        //        hismessage.Type = AccessType.ConsultationPay;
        //        var card = await _cardRepository.RetrieveByIdAsync(dto.CardId);
        //        hismessage.Input = new ConsultationPayInput()
        //        {
        //            ReservationId = dto.ReservationID,
        //            PayType = PayType.Public.Value(),
        //            PlatformOrderCode = dto.OutTradeNo,
        //            ResultOrderCode = dto.TradeNo,
        //            DepartmentId = users.DepartmentId,
        //            FirstVisitRegisterID = consultationPayDto.FirstVisitRegisterID,
        //            PatientId = card.OtherId,
        //            Price = (dto.Amount / 100),
        //            ServiceType = consultationPayDto.ServiceType,
        //            UserId = users.OtherId
        //        };
        //        var result = await MqttService.PublishAsync(hismessage);
        //        var ChargeId = "";
        //        var ThirdUniqueId = "";
        //        if (result.Result != null)
        //        {
        //            register.UseNo = result.Result.UseNo;
        //            ChargeId = result.Result.ChargeId;
        //            ThirdUniqueId = result.Result.ThirdUniqueId;
        //        }
        //        //修改订单信息状态、支付平台订单号、系统订单号
        //        await _ordersRepository.UpdateAsync(t => t.Id == dto.Id, t => new Orders() { TradeNo = dto.TradeNo, Status = OrdersStatus.Paymented.Value(), PaymentId = dto.PaymentId, OutId = ChargeId, Details = JsonConvert.SerializeObject(register) });

        //        dto.TradeNo = dto.TradeNo;
        //        dto.Status = OrdersStatus.Paymented.Value();
        //        dto.PaymentId = dto.PaymentId;
        //        dto.OutId = ChargeId;
        //        //添加订单日志信息(已支付)
        //        await CreateOrderLog(dto.MapTo<Orders>());
        //        //支付记录（支付成功）
        //        var payment = await UpdatePayment(dto, PaymentStatus.Success);
        //        //患者消息通知
        //        WechatNoticeEvent message = new WechatNoticeEvent
        //        {
        //            TemplateType = "Message",
        //            AcceptId = UserContext.WxOpenId,
        //            Keyword2 = users.UserName + "(" + users.DepartmentName + ")",
        //            Keyword3 = DateTime.Now.ToDateString(),
        //            Keyword4 = UserContext.LoginName + "(" + UserContext.LoginCode + ")",
        //            Remark = dto.TypeStr + "费：" + (dto.Amount / 100).ToString() + "。",
        //            Param = dto.CreateId
        //        };
        //        await _eventBus.PublishAsync(message);
        //        //支付完成移除缓存
        //        var provider = _cachingFactory.GetCachingProvider("csredisPaymentOrder");
        //        await provider.RemoveAsync("consultkey:" + dto.Id);
        //        var paymentdto = payment.MapTo<PaymentDto>();
        //        paymentdto.ThirdUniqueId = ThirdUniqueId;
        //        return paymentdto;
        //    }
        //    catch (Exception ex)
        //    {
        //        NLog.LogManager.GetLogger("Payment").Warn(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "---咨询挂号支付异常：" + ex.Message);
        //        throw new Transform(ex.Message, new { OrdersId = consultationPayDto.OrdersId });
        //    }
        //}
        #endregion
    }
}