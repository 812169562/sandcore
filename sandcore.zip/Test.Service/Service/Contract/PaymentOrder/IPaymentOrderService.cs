﻿using Sand.Dependency;
using Sand.Service.Dtos.PaymentOrder;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sand.Service.Contract.PaymentOrder
{
    /// <summary>
    ///  订单支付信息服务
    /// </summary>
    public interface IPaymentOrderService : IDependency
    {
        /// <summary>
        /// 退费
        /// </summary>
        /// <returns></returns>
        Task Refund();
        /// <summary>
        /// 订单取消
        /// </summary>
        /// <returns></returns>
        Task Cancel();
        /// <summary>
        /// 订单
        /// </summary>
        /// <returns></returns>
        Task Confirm();
        /// <summary>
        /// 便民订单
        /// </summary>
        /// <returns></returns>
        Task ConfirmConvenientorder();
    }
}
