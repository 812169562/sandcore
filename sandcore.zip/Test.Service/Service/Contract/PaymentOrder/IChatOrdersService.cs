﻿using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sand.Service.Contract.PaymentOrder
{
    /// <summary>
    /// 在线问诊订单表服务
    /// </summary>
    public interface IChatOrdersService : IService<ChatOrdersDto, ChatOrdersQuery, ChatOrders>
    {
        /// <summary>
        /// 更新在线问诊订单时间和状态
        /// </summary>
        /// <param name="chatOrdersQuery"></param>
        /// <returns></returns>
        Task UpdateOrder(ChatOrdersQuery chatOrdersQuery); 
    }
}
