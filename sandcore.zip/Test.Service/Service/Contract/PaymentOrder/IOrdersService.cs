﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using System.Threading.Tasks;
using Sand.Filter;
using System.Collections.Generic;
using Sand.Result;
using Sand.Domain.MqttData;

namespace Sand.Service.Contract.PaymentOrder
{
    /// <summary>
    /// 订单表服务
    /// </summary>
    public interface IOrdersService : IService<OrdersDto, OrdersQuery, Orders>
    {

        ///// <summary>
        ///// 新增挂号订单信息(包含his预约订单和本地挂号订单创建)
        ///// </summary>
        ///// <param name="dto">订单表信息</param>
        ///// <returns></returns>
        //[UowAsync]
        //Task<OrdersDto> RegisterAsync(OrdersDto dto);
        ///// <summary>
        ///// 缴费
        ///// </summary>
        ///// <param name="data">订单表信息</param>
        ///// <returns></returns>
        //[UowAsync]
        //Task<List<OrdersDto>> CreateOutpatientOrders(List<OrdersDto> data);
        ///// <summary>
        ///// 新增挂号订单信息（his预约订单创建成功，本地未创建成功情况）
        ///// </summary>
        ///// <param name="dto">订单表信息</param>
        ///// <returns></returns>
        //[UowAsync]
        //Task<OrdersDto> CreateRegisterOrders(OrdersDto dto);
        ///// <summary>
        ///// 获取订单信息
        ///// </summary>
        ///// <param name="ordersQuery">订单表信息</param>
        ///// <returns></returns>
        //Task<Paged<OrdersDto>> OrdersPageListAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 添加症状
        ///// </summary>
        ///// <param name="selfDiagnosisDto">自诊信息</param>
        ///// <returns></returns>
        //Task<SelfDiagnosisDto> CreateSelfDiagnosisAsync(SelfDiagnosisDto selfDiagnosisDto);
        ///// <summary>
        ///// 获取自诊信息
        ///// </summary>
        ///// <param name="selfDiagnosisDto"></param>
        ///// <returns></returns>
        //Task<SelfDiagnosisDto> QuerySelfDiagnosisAsync(SelfDiagnosisDto selfDiagnosisDto);
        ///// <summary>
        ///// 退款申请
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //[UowAsync]
        //Task ApplicationRefundAsync(OrdersDto dto);
        /// <summary>
        /// 分页查询退款订单
        /// </summary>
        /// <param name="ordersQuery"></param>
        /// <returns></returns>
        Task<Paged<OrdersDto>> RefundPageAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 查询挂号通知订单
        ///// </summary>
        ///// <returns></returns>
        //Task QueryResgiterNoticeAsync();
        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sittingIds"></param>
        ///// <returns></returns>
        //Task<List<OrdersDto>> RetrieveBySittingIdAsync(List<string> sittingIds);
        ///// <summary>
        ///// 验证订单信息
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //Task<OrdersDto> IsExistRegisterAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 获取订单信息
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //Task<List<OrdersDto>> OrdersByPaymentIdAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 根据微信支付号获取订单信息
        ///// </summary>
        ///// <param name="outTradeNo"></param>
        ///// <returns></returns>
        //Task<OrdersDto> GetOrdersByOutTradeNo(string outTradeNo);
        ///// <summary>
        ///// 发送消息
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //Task SendMessageAsync(OrdersDto dto);
        ///// <summary>
        ///// 创建咨询订单
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //[UowAsync]
        //Task<OrdersDto> CreateConsultationOrdersAsync(OrdersDto dto);
        ///// <summary>
        ///// 验证订单信息(咨询订单)
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //Task<OrdersDto> IsExistPaymentedAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 分页获取咨询订单
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //Task<Paged<OrdersDto>> ConsultPageAsync(OrdersQuery ordersQuery);
        ///// <summary>
        ///// 查询历史挂号记录
        ///// </summary>
        ///// <param name="ordersQuery"></param>
        ///// <returns></returns>
        //Task<List<RegisterListResult>> QueryRegisterListAsync(OrdersQuery ordersQuery);
    }
}