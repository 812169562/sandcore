﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using Sand.Service.Dtos;
using System.Threading.Tasks;
using System.Collections.Generic;
using Sand.Filter;
using Sand.Result;
using Sand.Cache;
using Sand.Domain.MqttData;

namespace Sand.Service.Contract.PaymentOrder {
    /// <summary>
    /// convenientorder服务
    /// </summary>
    public interface IConvenientorderService : IService<ConvenientorderDto, ConvenientorderQuery, Convenientorder>
    {
        /// <summary>
        /// 创建便民费用订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [UowAsync]
        Task<List<ConvenientorderDto>> CreateConvenientOrderAsync(ConvenientorderDto dto);
        /// <summary>
        /// 分页获取集合
        /// </summary>
        /// <param name="convenientorderQuery"></param>
        /// <returns></returns>
        Task<Paged<ConvenientorderDto>> PageListAsync(ConvenientorderQuery convenientorderQuery);

        /// <summary>
        /// 分页获取集合(患者端)
        /// </summary>
        /// <param name="convenientorderQuery"></param>
        /// <returns></returns>
        Task<Paged<ConvenientorderDto>> PageListByCardAsync(ConvenientorderQuery convenientorderQuery);
        /// <summary>
        /// 便民门诊订单审核
        /// </summary>
        /// <param name="convenientorderDto"></param>
        /// <returns></returns>
        [UowAsync]
        Task ChargeAuditAsync(ConvenientorderDto convenientorderDto);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task SendAuditMessageAsync(ConvenientorderDto dto);
    }
}