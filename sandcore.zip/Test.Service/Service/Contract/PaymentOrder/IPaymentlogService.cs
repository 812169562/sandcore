﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;

namespace Sand.Service.Contract.PaymentOrder {
    /// <summary>
    /// 支付日志服务
    /// </summary>
    public interface IPaymentlogService : IService<PaymentlogDto, PaymentlogQuery,Paymentlog> {
    }
}