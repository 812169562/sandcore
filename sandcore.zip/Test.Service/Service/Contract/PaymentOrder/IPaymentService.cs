﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sand.Filter;
using Sand.Domain.Entities.Payment;
using Sand.Cache;

namespace Sand.Service.Contract.PaymentOrder
{
    /// <summary>
    ///  第三方支付信息服务
    /// </summary>
    public interface IPaymentService : IService<PaymentDto, PaymentQuery, Payment>
    {
        //    /// <summary>
        //    /// 预约挂号支付
        //    /// </summary>
        //    /// <param name="orders"></param>
        //    /// <returns></returns>
        //    [UowAsync]
        //    Task<PaymentDto> RegisterPay(OrdersDto orders);
        //    /// <summary>
        //    /// 取消预约挂号订单支付
        //    /// </summary>
        //    /// <param name="dto"></param>
        //    [UowAsync]
        //    Task CancelRegister(OrdersDto dto);
        //    /// <summary>
        //    /// 获取门诊缴费待支付订单
        //    /// </summary>
        //    /// <param name="query"></param>
        //    /// <returns></returns>
        //    Task<List<OrdersDto>> OutpatientPayingOrders(OrdersQuery query);
        //    /// <summary>
        //    /// 门诊支付
        //    /// </summary>
        //    /// <param name="list"></param>
        //    /// <returns></returns>
        //    [UowAsync]
        //    Task<PaymentDto> OutpatientPay(List<OrdersDto> list);
        //    /// <summary>
        //    /// 取消支付
        //    /// </summary>
        //    /// <param name="list"></param>
        //    /// <returns></returns>
        //    [UowAsync]
        //    Task CancelOutpatientPay(List<OrdersDto> list);
        //    /// <summary>
        //    /// 确认支付
        //    /// </summary>
        //    /// <param name="paymentDto"></param>
        //    /// <returns></returns>
        //    [UowAsync]
        //    Task<PaymentDto> ConfirmPaymentAsync(PaymentDto paymentDto);
        /// <summary>
        /// 审核
        /// </summary>
        /// <param name="ordersDto"></param>
        /// <returns></returns>
        [UowAsync]
        [RedisCaching(60)]
        Task<OrdersDto> RefundsAuditAsync(OrdersDto ordersDto);
        /// <summary>
        /// 不通过审核
        /// </summary>
        /// <param name="ordersDto"></param>
        /// <returns></returns>
        [UowAsync]
        Task RefundsAuditNotPassedAsync(OrdersDto ordersDto);

        ///// <summary>
        ///// 获取支付结果
        ///// </summary>
        ///// <param name="outTradeNo"></param>
        ///// <returns></returns>
        //Task<PayModel> QueryPayResult(string outTradeNo);
        ///// <summary>
        ///// 咨询支付
        ///// </summary>
        ///// <param name="consultationPayDto"></param>
        ///// <returns></returns>
        //[UowAsync]
        //Task<PaymentDto> ConsultationPay(ConsultationPayDto consultationPayDto);
    }
}