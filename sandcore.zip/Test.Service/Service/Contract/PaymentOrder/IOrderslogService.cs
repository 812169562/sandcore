﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;

namespace Sand.Service.Contract.PaymentOrder {
    /// <summary>
    /// OrdersLog订单日志表服务
    /// </summary>
    public interface IOrderslogService : IService<OrderslogDto, OrderslogQuery,Orderslog> {
    }
}