﻿using System;
using Sand.Service;
using Sand.Domain.Queries.PaymentOrder;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Service.Dtos.PaymentOrder;
using System.Threading.Tasks;
using Sand.Result;

namespace Sand.Service.Contract.PaymentOrder {
    /// <summary>
    /// 用户评价表服务
    /// </summary>
    public interface IUserevaluationService : IService<UserevaluationDto, UserevaluationQuery, Userevaluation>
    {
        /// <summary>
        /// 分页获取历史订单
        /// </summary>
        /// <param name="userevaluationQuery">用户评价表查询对象</param>
        Task<Paged<UserevaluationDto>> EvaluationPageListAsync(UserevaluationQuery userevaluationQuery);
    }
}