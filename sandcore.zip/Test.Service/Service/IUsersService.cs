﻿using Sand.Service.Dtos.Systems;
using Sand.Context;
using System.Threading.Tasks;
using Sand.Filter;
using System.Collections.Generic;
using Sand.Result;
using Sand.Cache;
using EasyCaching.Core.Interceptor;
using Sand.Service;
using Test.Service.Domain;

namespace Test.Service.Service
{
    /// <summary>
    /// 用户表服务
    /// </summary>
    public interface IUsersService : IService<UsersDto, UsersQuery, Users>
    {
       
    }
}