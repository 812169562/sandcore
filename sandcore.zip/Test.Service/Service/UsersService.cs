﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Sand.Domain.Uow;
using Sand.Extensions;
using Sand.Service.Dtos.Systems;
using Microsoft.Extensions.Configuration;
using Sand.Helpers;
using Sand.Data;
using Test.Service.Domain;
using Test.Service.Service;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sand.Service.Impl.Systems
{
    /// <summary>
    /// 用户表服务
    /// </summary>
    public class UsersService : BaseService<UsersDto, UsersQuery, Users>, IUsersService
    {
        /// <summary>
        /// 用户表仓储
        /// </summary>
        private readonly IUsersRepository _usersRepository;
        /// <summary>
        /// 配置文件
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// 数据访问
        /// </summary>
        private readonly ISqlQuery _sqlQuery;

        /// <summary>
        /// 初始化用户表服务
        /// </summary>
        /// <param name="uow">工作单元</param>
        /// <param name="usersRepository">用户表仓储</param>
        /// <param name="configuration">配置文件</param>
        /// <param name="dicRepository">字典表仓储</param>
        /// <param name="sqlQuery">数据访问</param>
        /// <param name="sittingRepository">医生坐诊表仓储</param>
        /// <param name="storagesRepository">存储仓储</param>
        /// <param name="collectionDoctorRepository">收藏医生仓储</param>
        public UsersService(IUnitOfWork uow, IUsersRepository usersRepository, IConfiguration configuration, ISqlQuery sqlQuery)
            : base(usersRepository)
        {
            _usersRepository = usersRepository;
            _configuration = configuration;
            _sqlQuery = sqlQuery;
        }
        /// <summary>
        /// 创建用户表条件表达式
        /// </summary>
        /// <param name="usersQuery">用户表查询对象</param>
        /// <returns>用户表查询表达式</returns>
        protected override Expression<Func<Users, bool>> CreateQuery(UsersQuery usersQuery)
        {
            return base.CreateQuery(usersQuery).WhereIf(t => t.LoginCode == usersQuery.LoginCode || t.Tel == usersQuery.LoginCode, usersQuery.LoginCode.IsNotEmpty())
                .WhereIf(t => t.UserName.Contains(usersQuery.UserName) || t.PinYin.Contains(usersQuery.UserName) || t.LoginCode.Contains(usersQuery.UserName), usersQuery.UserName.IsNotEmpty())
                .WhereIf(t => t.UserName.Contains(usersQuery.QueryData) || t.DepartmentName.Contains(usersQuery.QueryData), usersQuery.QueryData.IsNotEmpty())
                .WhereIf(t => t.RelationShip.Contains(usersQuery.DepartmentId) || t.DepartmentId == usersQuery.DepartmentId, usersQuery.DepartmentId.IsNotEmpty())
                .WhereIf(t => t.IsConvenient == usersQuery.IsConvenient, usersQuery.IsConvenient != null)
                .WhereIf(t => t.OnlineConsultation == usersQuery.OnlineConsultation, usersQuery.OnlineConsultation != null)
                .WhereIf(t => t.IsRecommend == usersQuery.IsRecommend, usersQuery.IsRecommend != null)
                .WhereIf(t => t.DepartmentId == usersQuery.DepartmentId || t.RelationShip.IndexOf(usersQuery.DepartmentId) >= 0, usersQuery.DepartmentId.IsNotEmpty())
                .WhereIf(t => t.Type == usersQuery.Type, usersQuery.Type != null)
                .WhereIf(t => t.UnionId == usersQuery.UnionId, usersQuery.UnionId.IsNotEmpty())
                .WhereIf(t => t.IsEnable == usersQuery.IsEnable, usersQuery.IsEnable != null)
                .WhereIf(t => Encrypt.Md5By32(t.OtherId).ToUpper() == usersQuery.Md5.ToUpper(), usersQuery.Md5.IsNotEmpty());
        }

        public override async Task<UsersDto> CreateAsync(UsersDto dto)
        {
            //var data = new UsersQuery();
            //data.UserName = "测试";
            //NLog.LogManager.GetLogger("Debug").Error(DateTime.Now+"__"+a);
            //var q = await _sqlQuery.QueryAsync<Users>("select *  from users where Id like ?Id", new { Id = dto.Id });
            ////NLog.LogManager.GetLogger("Debug").Error(DateTime.Now + "__a" + a);
            //var data2 = q.FirstOrDefault();
            var data23 = (await _usersRepository.RetrieveAsync(t => t.Id == dto.Id)).First();
            data23.VideoFee = data23.VideoFee + 1;
            //await _usersRepository.UpdateAsync(data23);
            await _usersRepository.UpdateAsync(data23.Id, p => new Users { VideoFee = data23.VideoFee + 1 });
            //data2.UserName = "测试" + Uuid.Next().Substring(3,18);
            //await _usersRepository.CreateAsync(data2);
            //data2.VideoFee = data2.VideoFee+1;
            //await _usersRepository.UpdateAsync(data2);
            //await _usersRepository.UpdateAsync(data23.Id, p => new Users { VideoFee = data23.VideoFee + 1 });
            return ToDto(data23);
        }
    }
}