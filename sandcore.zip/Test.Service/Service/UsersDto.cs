﻿using Sand.Context;
using Sand.Extensions;
using Sand.Helpers;
using Sand.Result;
using Sand.Utils.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Security.Claims;

namespace Sand.Service.Dtos.Systems
{
    /// <summary>
    /// 用户表数据传输对象
    /// </summary>
    [DataContract]
    public class UsersDto : BaseDto
    {
        /// <summary>
        /// 编号
        /// </summary>
        [DataMember(Name = "_id")]
        public string Md5 { get { return Sand.Helpers.Encrypt.Md5By32(Id); } }

        /// <remarks>
        /// 用户名
        /// </remarks>
        [Required(ErrorMessage = "用户名不能为空")]
        [StringLength(36, ErrorMessage = "用户名输入过长，不能超过36位")]
        [Display(Name = "用户名")]
        [DataMember]
        public string UserName { get; set; }

        /// <summary>
        /// 登陆号
        /// </summary>
        [Required(ErrorMessage = "登陆号不能为空")]
        [StringLength(18, ErrorMessage = "登陆号输入过长，不能超过18位")]
        [Display(Name = "登陆号")]
        [DataMember]
        public string LoginCode { get; set; }

        /// <summary>
        /// 电话号码
        /// </summary>
        [Required(ErrorMessage = "电话号码不能为空")]
        [StringLength(18, ErrorMessage = "电话号码输入过长，不能超过18位")]
        [Display(Name = "电话号码")]
        [DataMember]
        public string Tel { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [StringLength(18, ErrorMessage = "密码输入过长，不能超过18位")]
        [Display(Name = "密码")]
        [DataMember]
        public string Pwd { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        [Display(Name = "性别")]
        [DataMember]
        public SexType? Sex { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        [DataMember]
        public string SexStr => this.Sex.GetValueOrDefault().Description();

        /// <summary>
        /// 微信识别号
        /// </summary>
        [StringLength(128, ErrorMessage = "微信识别号输入过长，不能超过128位")]
        [Display(Name = "微信识别号")]
        [DataMember]
        public string WeiXinKey { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        [Required(ErrorMessage = "类型不能为空")]
        [Display(Name = "类型")]
        [DataMember]
        public int Type { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        [DataMember]
        public string TypeStr => ((SystemUserType)Type).Description();

        /// <summary>
        /// 头像
        /// </summary>
        [DataMember]
        public string AvatarUrl { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        [DataMember]
        public ResultFile AvatarInfo { get; set; }

        /// <summary>
        /// 科室
        /// </summary>
        [DataMember]
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [DataMember]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [DataMember]
        public string Title { get; set; }
        /// <summary>
        /// his关联id
        /// </summary>
        [DataMember]
        public string OtherId { get; set; }
        /// <summary>
        /// 科室关系
        /// </summary>
        [DataMember]
        public string RelationShip { get; set; }
        /// <summary>
        /// 医生简介
        /// </summary>
        [DataMember]
        public string Synopsis { get; set; }
        /// <summary>
        /// 坐诊日期
        /// </summary>
        [Display(Name = "坐诊日期")]
        [DataMember]
        public DateTime? SittingDate { get; set; }
        /// <summary>
        /// 坐诊日期
        /// </summary>
        [DataMember]
        public string SittingDateStr => SittingDate.ToDateString();
        /// <summary>
        /// 放号数量
        /// </summary>
        [Display(Name = "放号数量")]
        [DataMember]
        public int Count { get; set; }
        /// <summary>
        /// 已使用数量
        /// </summary>
        [Display(Name = "已使用数量")]
        [DataMember]
        public int UseCount { get; set; }
        /// <summary>
        /// 坐诊
        /// </summary>
        [Display(Name = "坐诊")]
        [DataMember]
        public List<SittingInfo> SittingData { get; set; }
        /// <summary>
        /// 擅长
        /// </summary>
        [Display(Name = "擅长")]
        [DataMember]
        public string Adept { get; set; }
        /// <summary>
        /// 拼音
        /// </summary>
        [Display(Name = "拼音")]
        [DataMember]
        public string PinYin { get; set; }
        /// <summary>
        /// 挂号数量
        /// </summary>
        [DataMember]
        public int RegisteredCount { get; set; }
        /// <summary>
        /// 是否便民
        /// </summary>
        [DataMember]
        public bool? IsConvenient { get; set; }
        /// <summary>
        /// 是否便民
        /// </summary>
        [DataMember]
        public string IsConvenientStr => IsConvenient.ToIsOrNot();
        /// <summary>
        /// 是否收藏
        /// </summary>
        [DataMember]
        public bool IsCollection { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        [DataMember]
        public string AppOpenId1 { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        [DataMember]
        public string AppOpenId2 { get; set; }
        /// <summary>
        /// 拍方抓药
        /// </summary>
        [DataMember]
        public bool? IsPatron { get; set; }
        /// <summary>
        /// 拍方抓药
        /// </summary>
        [DataMember]
        public string IsPatronStr => IsPatron.ToIsOrNot();

        /// <summary>
        /// 排序号
        /// </summary>
        [DataMember]
        public int? Sort { get; set; }
        /// <summary>
        /// 是否推荐
        /// </summary>
        [DataMember]
        public bool? IsRecommend { get; set; }
        /// <summary>
        /// 密码错误次数
        /// </summary>
        [DataMember]
        public int? PwdErrorCount { get; set; }
        /// <summary>
        /// 登录状态
        /// </summary>
        [DataMember]
        public int? LogonStatus { get; set; }
        /// <summary>
        /// 锁定状态
        /// </summary>
        [DataMember]
        public int? LockedStatus { get; set; }

        /// <summary>
        /// 诊断
        /// </summary>
        [DataMember]
        public string Diagnosis { get; set; }
        /// <summary>
        /// 在线问诊标志
        /// </summary>
        [DataMember]
        public bool? OnlineConsultation { get; set; }
        /// <summary>
        /// UnionId
        /// </summary>
        [DataMember]
        public string UnionId { get; set; }
        /// <summary>
        /// 分类标志（格式：1|2|3，枚举：TaxonType）
        /// </summary>
        [DataMember]
        public string Taxon { get; set; }
        /// <summary>
        /// 分类标志集合
        /// </summary>
        [DataMember]
        public List<int> TaxonData { get; set; }
        /// <summary>
        /// 图文咨询费用
        /// </summary>
        [DataMember]
        public decimal? GraphicFees { get; set; }
        /// <summary>
        ///  电话咨询费
        /// </summary>
        [DataMember]
        public decimal? TelephoneFee { get; set; }
        /// <summary>
        ///  视频咨询费
        /// </summary>
        [DataMember]
        public decimal? VideoFee { get; set; }
        /// <summary>
        /// 患者评论
        /// </summary>
        [DataMember]
        public List<PatientComment> PatientComment { get; set; }
        /// <summary>
        /// 免挂号费
        /// </summary>
        [DataMember]
        public bool FreeRegistration { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class SittingInfo
    {
        /// <summary>
        /// 医生Id
        /// </summary>
        [DataMember]
        public string UserId { get; set; }
        /// <summary>
        /// 上午/下午
        /// </summary>
        [DataMember]
        public int DayType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string DayTypeStr
        {
            get
            {
                switch (System.Convert.ToInt32(DayType))
                {
                    case 1:
                        return "上午";
                    case 2:
                        return "中午";
                    case 3:
                        return "下午";
                    case 4:
                        return "夜间";
                    default:
                        return "";
                }
            }
        }

        /// <summary>
        /// 坐诊日期
        /// </summary>
        [DataMember]
        public DateTime SittingDate { get; set; }
        /// <summary>
        /// 坐诊日期
        /// </summary>
        [DataMember]
        public string SittingDateStr { get => SittingDate.ToDateString(); }

        /// <summary>
        /// 放号数量
        /// </summary>
        [DataMember]
        public int Count { get; set; }
        /// <summary>
        /// 已使用数量
        /// </summary>
        [DataMember]
        public int UseCount { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        [DataMember]
        public bool IsEnable { get; set; }

        /// <summary>
        /// 星期
        /// </summary>
        [DataMember]
        public string WeekStr
        {
            get
            {
                switch (SittingDate.DayOfWeek)
                {
                    case DayOfWeek.Sunday:
                        return "周日";
                    case DayOfWeek.Monday:
                        return "周一";
                    case DayOfWeek.Tuesday:
                        return "周二";
                    case DayOfWeek.Wednesday:
                        return "周三";
                    case DayOfWeek.Thursday:
                        return "周四";
                    case DayOfWeek.Friday:
                        return "周五";
                    case DayOfWeek.Saturday:
                        return "周六";
                    default:
                        return "";
                }
            }
        }
        /// <summary>
        /// 是否有号
        /// </summary>
        [DataMember]
        public bool IsNumber => IsEnable && (Count - UseCount) > 0;

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public List<TimeInterval> TimeInterval { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    public class TimeInterval
    {
        /// <summary>
        /// 坐诊编号
        /// </summary>
        [DataMember]
        public string Id { get; set; }
        /// <summary>
        /// 时间段ID
        /// </summary>
        [DataMember]
        public string TimeIntervalID { get; set; }

        /// <summary>
        /// 时间段名称
        /// </summary>
        [DataMember]
        public string TimeIntervalName { get; set; }
        /// <summary>
        /// 预约加收费
        /// </summary>
        [DataMember]
        public decimal BookingMoney { get; set; }

        /// <summary>
        /// 诊查费
        /// </summary>
        [DataMember]
        public decimal Examine { get; set; }

        /// <summary>
        /// 挂号费
        /// </summary>
        [DataMember]
        public decimal Registration { get; set; }
        /// <summary>
        /// 挂号总金额
        /// </summary>
        [DataMember]
        public decimal Money { get => (Examine + Registration); }
        /// <summary>
        /// 是否可用
        /// </summary>
        [DataMember]
        public bool IsEnable { get; set; }
        /// <summary>
        /// 放号数量
        /// </summary>
        [DataMember]
        public int Count { get; set; }
        /// <summary>
        /// 已使用数量
        /// </summary>
        [DataMember]
        public int UseCount { get; set; }

    }
    /// <summary>
    /// 
    /// </summary>
    public class PatientComment
    {
        /// <summary>
        /// 患者名称
        /// </summary>
        [DataMember]
        public string PatientName { get; set; }
        /// <summary>
        /// 星级
        /// </summary>
        [DataMember]
        public int Star { get; set; }
        /// <summary>
        /// 评论
        /// </summary>
        [DataMember]
        public string Comment { get; set; }
        /// <summary>
        /// 评论时间
        /// </summary>
        [DataMember]
        public string CommentTime { get; set; }
    }
}
