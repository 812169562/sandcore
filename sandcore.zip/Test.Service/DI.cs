﻿using AspectCore.Configuration;
using AspectCore.DynamicProxy.Parameters;
using AspectCore.Extensions.Autofac;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using EasyCaching.Core;
using EasyCaching.CSRedis;
using EasyCaching.InMemory;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Sand.Api;
using Sand.Context;
using Sand.Data;
using Sand.DI;
using Sand.Domain.Uow;
using Sand.Events;
using Sand.Helpers;
using Sand.Log.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Service.DI
{
    /// <summary>
    /// 注入
    /// </summary>
    public static class DI
    {
        /// <summary>
        /// 添加注册
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static IServiceProvider AutofacResolveReigster(this IServiceCollection services, IConfiguration configuration)
        {
            DefaultIocConfig.ContainerBuilder.RegisterModule<DefaultIocConfig>();
            DefaultIocConfig.ContainerBuilder.RegisterType<SqlQuery>().As<ISqlQuery>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<TestUserContext>().As<IUserContext>().AsImplementedInterfaces().InstancePerLifetimeScope().PropertiesAutowired();
            DefaultIocConfig.ContainerBuilder.RegisterType<HttpContextAccessor>().As<IHttpContextAccessor>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<WebContext>().As<IContext>().AsImplementedInterfaces().InstancePerLifetimeScope();
            DefaultIocConfig.ContainerBuilder.RegisterType<MySqlConfig>().As<ISqlConfig>().AsImplementedInterfaces().SingleInstance();
            DefaultIocConfig.ContainerBuilder.RegisterDynamicProxy(config =>
            {
                config.EnableParameterAspect();
            });
            services.AddDefaultEventBus();
            DefaultIocConfig.ContainerBuilder.AddAspectCoreInterceptor(x => x.CacheProviderName = EasyCachingConstValue.DefaultInMemoryName);
            DefaultIocConfig.ContainerBuilder.AddRedisAspectCoreInterceptor();
            DefaultIocConfig.ContainerBuilder.Populate(services);
            DefaultIocConfig.Container = DefaultIocConfig.ContainerBuilder.Build();
            return DefaultIocConfig.Container.Resolve<IServiceProvider>();
        }
    }
}
