﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 部门实体
    /// </summary>
    [Serializable]
    public class DepartmentResult
    {
        /// <summary>
        /// 部门ID
        /// </summary>
        public string OtherId { get; set; }
        /// <summary>
        /// 部门代码
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 打印名称 
        /// </summary>
        public string PrintName { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; }
        /// <summary>
        /// 拼音
        /// </summary>  
        public string PinYin { get; set; }
        /// <summary>
        /// 部门类型
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 父级关系
        /// </summary>
        public string ParentRelationgShip { get; set; }
        /// <summary>
        /// 父级
        /// </summary>
        public string Parent { get; set; }
        /// <summary>
        /// 父级名称
        /// </summary>
        public string ParentName { get; set; }
        /// <summary>
        /// 门诊标志
        /// </summary>
        public int OutpatientSign { get; set; }
    }
}
