﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 患者待缴费实体
    /// </summary>
    [Serializable]
    public class PaymentResult
    {
        /// <summary>
        /// 患者卡号
        /// </summary>
        public string PatientNo { get; set; }
        /// <summary>
        /// 患者ID 
        /// </summary>
        public string PatientId { get; set; }
        /// <summary>
        /// 患者姓名
        /// </summary>
        public string PatientName { get; set; }
        /// <summary>
        /// 收费表ID     
        /// </summary>
        public string ChargeId { get; set; }
        /// <summary>
        /// 收费项目名称
        /// </summary>
        public string ItemName { get; set; }
        /// <summary>
        /// 项目类型 
        /// </summary>
        public int ItemType { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        public decimal PayMoney { get; set; }
        /// <summary>
        /// 医生ID
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 医生名称
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 科室ID
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室名称
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 科室地址
        /// </summary>
        public string DepartmentAddress { get; set; }
        /// <summary>
        /// 开单时间
        /// </summary>
        public DateTime Time { get; set; }
        /// <summary>
        /// 开单时间
        /// </summary>
        public string TimeStr => this.Time.ToString("yyyy-MM-dd HH:mm");
        /// <summary>
        /// 是否选中
        /// </summary>
        public bool Checked { get; set; }
        /// <summary>
        /// 微信订单生成时间
        /// </summary>
        public DateTime OrderCreateTime { get; set; }
        /// <summary>
        /// 便民订单编号
        /// </summary>
        public string ConvenientOrderId { get; set; }
        /// <summary>
        /// 便民订单编号
        /// </summary>
        public List<ChargeInfo> Info { get; set; }
        /// <summary>
        /// 大学生医保使用金额
        /// </summary>
        public decimal DeductionsMoney { get; set; }
        /// <summary>
        /// 总金额
        /// </summary>
        public decimal TotalMoney { get; set; }
        /// <summary>
        /// 组别号
        /// </summary>
        public string GroupNo { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 附加信息
        /// </summary>
        public string AdditionalInformation { get; set; }
    }

    /// <summary>
    /// 收费明细
    /// </summary>
    [Serializable]
    public class ChargeInfo
    {
        /// <summary>
        /// 收费编号
        /// </summary>
        public string ChargeID { get; set; }
        /// <summary>
        /// 收费项目
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// 规格
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Count { get; set; }
    }
}
