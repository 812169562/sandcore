﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 药品及库存信息
    /// </summary>
    [Serializable]
    public class GoodsInventoryResult
    {
        /// <summary>
        /// 
        /// </summary>
        public GoodsInventoryResult()
        {
            Count = 1;
        }
        /// <summary>
        /// 药品编号
        /// </summary>
        public string GoodsID { get; set; }
        /// <summary>
        /// 药品名称
        /// </summary>
        public string GoodsName { get; set; }
        /// <summary>
        /// 药品规格
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// 库存数量
        /// </summary>
        public int InventoryCount { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// 包装单位
        /// </summary>
        public string PackUnit { get; set; }
        /// <summary>
        /// 包装价格
        /// </summary>
        public decimal PackPrice { get; set; }
        /// <summary>
        /// 包装比例
        /// </summary>
        public int PackScale { get; set; }
        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 根级科目名称
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// 根级科目编码
        /// </summary>
        public string FirstCode { get; set; }
        /// <summary>
        /// 二级科目名称
        /// </summary>
        public string SecondName { get; set; }
        /// <summary>
        /// 二级科目编码
        /// </summary>
        public string SecondCode { get; set; }
        /// <summary>
        /// 成本价
        /// </summary>
        public decimal Cost { get; set; }
        /// <summary>
        /// 收费项目类型
        /// </summary>
        public int ChargeType { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 序号
        /// </summary>
        public int Index { get; set; }
    }
}
