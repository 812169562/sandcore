﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 医生信息实体
    /// </summary>
    [Serializable]
    public class DoctorResult
    {
        /// <summary>
        /// 医生ID
        /// </summary>
        public string OtherId { get; set; }
        /// <summary>
        /// 登陆账号
        /// </summary>
        public string LoginCode { get; set; }
        /// <summary>
        /// 登陆密码
        /// </summary>
        public string Pwd { get; set; }
        /// <summary>
        /// 医生名称
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 医生拼音
        /// </summary>
        public string PinYin { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        public int Sex { get; set; }
        /// <summary>
        /// 科室ID
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室名称
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        public string Tel { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 类型
        /// </summary>
        public int Type { get; set; }
    }
}
