﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 预约挂号返回结果
    /// </summary>
    [Serializable]
    public class RegisterResult
    {
        /// <summary>
        /// 收费ID
        /// </summary>
        public string ChargeId { get; set; }
        /// <summary>
        /// 预约ID
        /// </summary>
        public string ReservationId { get; set; }
        /// <summary>
        /// 挂号序号
        /// </summary>
        public int UseNo { get; set; }
    }
}
