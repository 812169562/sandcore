﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.MqttData.FinanceResult
{
    /// <summary>
    /// 挂号统计
    /// </summary>
    [Serializable]
    public class RegisteStatResult
    {
        /// <summary>
        /// 医生姓名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 医生姓名
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// 科室名称
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 数据代码
        /// </summary>
        public string TreeCode { get; set; }
        /// <summary>
        /// 费用类型
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 费用明细名称
        /// </summary>
        public string TypeName { get; set; }
        /// <summary>
        /// 费用明细关联ID
        /// </summary>
        public string LinkId { get; set; }
        /// <summary>
        /// 费用
        /// </summary>
        public decimal Money { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }
    }
    /// <summary>
    /// 标准
    /// </summary>
    public enum Standard
    {
        /// <summary>
        /// 全部(单个类型的全部数据)
        /// </summary>
        [Description("全部")]
        All = 0,
        /// <summary>
        /// 个人
        /// </summary>
        [Description("个人")]
        User = 1,
        /// <summary>
        /// 科室
        /// </summary>
        [Description("科室")]
        Department = 2,
        /// <summary>
        /// 入院
        /// </summary>
        [Description("入院")]
        InHospital = 3,
        /// <summary>
        /// 出院
        /// </summary>
        [Description("出院")]
        OutHospital = 4,
        /// <summary>
        /// 挂号
        /// </summary>
        [Description("挂号")]
        Registe = 5,
        /// <summary>
        /// 门诊
        /// </summary>
        [Description("门诊")]
        Outpatient = 6
    }
    /// <summary>
    /// 数据类型
    /// </summary>
    public enum StatType
    {
        /// <summary>
        /// 挂号统计
        /// </summary>
        [Description("挂号统计")]
        RegisteStat = 1,
        /// <summary>
        /// 出入院人次统计
        /// </summary>
        [Description("出入院人次统计")]
        InOutHospitalStat = 2,
        /// <summary>
        /// 收入统计
        /// </summary>
        [Description("收入统计")]
        IncomeStat = 3,
        /// <summary>
        /// 销售排名统计
        /// </summary>
        [Description("销售排名统计")]
        SalesStat = 4
    }
}
