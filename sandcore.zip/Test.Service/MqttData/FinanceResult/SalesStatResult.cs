﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData.FinanceResult
{
    /// <summary>
    /// 销售统计
    /// </summary>
    [Serializable]
    public class SalesStatResult : RegisteStatResult
    {
        /// <summary>
        /// 规格
        /// </summary>
        public string Format { get; set; }
    }
}
