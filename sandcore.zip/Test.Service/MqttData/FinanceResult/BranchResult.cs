﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData.FinanceResult
{
    /// <summary>
    /// 分支结构返回
    /// </summary>
    [Serializable]
    public class BranchResult
    {
        /// <summary>
        /// 分院名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 分院树级码
        /// </summary>
        public string TreeCode { get; set; }
        /// <summary>
        /// 挂号数量
        /// </summary>
        public int Count { get; set; }
    }
}
