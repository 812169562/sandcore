﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 收费项目
    /// </summary>
    [Serializable]
    public class ChargeItemResult
    {
        /// <summary>
        /// 项目编号
        /// </summary>
        public string ItemID { get; set; }
        /// <summary>
        /// 项目名称
        /// </summary>
        public string ItemName { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// 规格
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 价格
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// 成本价
        /// </summary>
        public decimal Cost { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// 类型(1西药,2检查,3检验,4治疗)
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 执行科室名称
        /// </summary>
        public string ExecDepartmentName { get; set; }
        /// <summary>
        /// 执行科室ID
        /// </summary>
        public string ExecDepartmentID { get; set; }
        /// <summary>
        /// 包装单位
        /// </summary>
        public string PackUnit { get; set; }
        /// <summary>
        /// 包装价格
        /// </summary>
        public decimal PackPrice { get; set; }
        /// <summary>
        /// 包装比例
        /// </summary>
        public int PackScale { get; set; }
    }
}
