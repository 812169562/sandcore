﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.MqttData
{
    /// <summary>
    /// 
    /// </summary>
    public class RegisterListResult
    {
        /// <summary>
        /// 挂号ID
        /// </summary>
        public string RegisterID { get; set; }
        /// <summary>
        /// 就诊日期
        /// </summary>
        public DateTime Treatment { get; set; }
        /// <summary>
        /// 就诊日期
        /// </summary>
        public string TreatmentStr => Treatment.ToString("yyyy-MM-dd");
        /// <summary>
        /// 医生ID
        /// </summary>
        public string UserID { get; set; }
        /// <summary>
        /// 医生名字
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 诊断
        /// </summary>
        public string DiseaseName { get; set; }
    }
}
