﻿using Sand.Domain.Uow;
using Sand.Domain.Repositories;
using Test.Service.Domain;

namespace Test.Service.Data
{
    /// <summary>
    /// 用户表仓储
    /// </summary>
    public class UsersRepository : EfRepository<Users>, IUsersRepository
    {
        /// <summary>
        /// 初始化用户表仓储
        /// </summary>
        /// <param name="uow">工作单元</param>
        public UsersRepository(IReadUnitOfWork readUnitOfWork, IWriteUnitOfWork writeUnitOfWork) : base(readUnitOfWork, writeUnitOfWork)
        {
        }
    }
}
