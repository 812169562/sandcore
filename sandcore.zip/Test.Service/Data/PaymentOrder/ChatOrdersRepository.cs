﻿using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Repositories;
using Sand.Domain.Repositories.PaymentOrder;
using Sand.Domain.Uow;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Data.Repositories.PaymentOrder
{
    /// <summary>
    /// 在线问诊仓储
    /// </summary>
    public class ChatOrdersRepository : EfRepository<ChatOrders>, IChatOrdersRepository
    {
        /// <summary>
        /// 初始化聊天记录仓储
        /// </summary>
        /// <param name="readUnitOfWork">读取工作单元</param>
        /// <param name="writeUnitOfWork">写入工作单元</param>
        public ChatOrdersRepository(IReadUnitOfWork readUnitOfWork, IWriteUnitOfWork writeUnitOfWork) : base(readUnitOfWork, writeUnitOfWork)
        {
        }
    }
}
