﻿using Sand.Domain.Uow;
using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Repositories.PaymentOrder;

namespace Sand.Data.Repositories.PaymentOrder {
    /// <summary>
    /// 支付日志仓储
    /// </summary>
    public class PaymentlogRepository : EfRepository<Paymentlog>, IPaymentlogRepository {
        /// <summary>
        /// 初始化支付日志仓储
        /// </summary>
        /// <param name="readUnitOfWork">读取工作单元</param>
        /// <param name="writeUnitOfWork">写入工作单元</param>
        public PaymentlogRepository(IReadUnitOfWork readUnitOfWork, IWriteUnitOfWork writeUnitOfWork) : base(readUnitOfWork, writeUnitOfWork)
        {
        }
    }
}
