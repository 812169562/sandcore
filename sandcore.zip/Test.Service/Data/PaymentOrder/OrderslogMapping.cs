﻿using Sand.Data;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Datas.Mapping.PaymentOrder
{
    /// <summary>
    /// OrdersLog订单日志表映射配置
    /// </summary>
    public class OrderslogMapping : BaseEntityMap<Orderslog>
    {
        /// <summary>
        /// 映射表
        /// </summary>
        protected override void MapTable(EntityTypeBuilder<Orderslog> builder)
        {
        }

        /// <summary>
        /// 映射属性
        /// </summary>
        protected override void MapProperties(EntityTypeBuilder<Orderslog> builder)
        {
        }

        /// <summary>
        /// 拦截器
        /// </summary>
        protected override void MapSoftDelete(EntityTypeBuilder<Orderslog> builder)
        {
            builder.HasQueryFilter(t => t.IsDeleted == false);
        }

        /// <summary>
        /// 映射导航属性
        /// </summary>
        protected override void MapAssociations(EntityTypeBuilder<Orderslog> builder)
        {
        }
    }
}
