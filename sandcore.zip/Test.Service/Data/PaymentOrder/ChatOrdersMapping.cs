﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sand.Domain.Entities.PaymentOrder;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Data.Mapping.PaymentOrder
{
    /// <summary>
    /// 在线问诊订单表映射配置
    /// </summary>
    public class ChatOrdersMapping : BaseEntityMap<ChatOrders>
    {
        /// <summary>
        /// 映射表
        /// </summary>
        protected override void MapTable(EntityTypeBuilder<ChatOrders> builder)
        {
        }

        /// <summary>
        /// 映射属性
        /// </summary>
        protected override void MapProperties(EntityTypeBuilder<ChatOrders> builder)
        {
        }

        /// <summary>
        /// 拦截器
        /// </summary>
        protected override void MapSoftDelete(EntityTypeBuilder<ChatOrders> builder)
        {
            builder.HasQueryFilter(t => t.IsDeleted == false);
        }

        /// <summary>
        /// 映射导航属性
        /// </summary>
        protected override void MapAssociations(EntityTypeBuilder<ChatOrders> builder)
        {
        }
    }
}
