﻿namespace Sand.Domain.Chat.Events
{
    internal class DataNode
    {
        public DataNode()
        {
        }

        public string color { get; set; }
        public string value { get; set; }
    }
}