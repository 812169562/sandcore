﻿namespace Sand.Domain.Chat.Events
{
    public class WechatNotice
    {
        public string template_id { get; set; }
        public string touser { get; set; }

        public string url { get;  set; }
    }
}