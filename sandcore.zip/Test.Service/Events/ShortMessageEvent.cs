﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Sand.Attributes;
using Sand.DI;
//using Sand.Domain.Chat.Service;
using Sand.Events;
using Sand.Log.Less;

namespace Sand.Domain.Chat.Events
{
    /// <summary>
    /// 短信服务事件
    /// </summary>
    [Event]
    public class ShortMessageEvent : IEvent
    {
        /// <summary>
        /// 跟踪编号
        /// </summary>
        public string Id { get; }

        /// <summary>
        /// 事件
        /// </summary>
        public DateTime Time { get; }

        /// <summary>
        /// 电话号码
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 内容
        /// </summary>
        /// <returns></returns>
        public string Content { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        public string VerificationCode { get; set; }
    }

    /// <summary>
    /// 微信通知发送消息
    /// </summary>
    [EventHandler]
    public class ShortMessageEventHandler : IEventHandler<ShortMessageEvent>
    {
        //private readonly IShortMessageService _shortMessageService;

        /// <summary>
        /// 
        /// </summary>
        public ShortMessageEventHandler()
        {
            //_shortMessageService = Ioc.GetService<IShortMessageService>();
        }

        /// <summary>
        /// 发布消息
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<bool> HandleAsync(ShortMessageEvent @event, CancellationToken cancellationToken = new CancellationToken())
        {
            try
            {
                //await _shortMessageService.Send(@event);
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                ex.Submit();
                //cancellationToken.ThrowIfCancellationRequested();
                return await Task.FromResult(false);
            }
        }

        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<bool> HandleAsync(IEvent @event, CancellationToken cancellationToken = default)
            => CanHandle(@event) ? HandleAsync((WechatNoticeEvent) @event, cancellationToken) : Task.FromResult(false);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="event"></param>
        /// <returns></returns>
        public bool CanHandle(IEvent @event) => @event.GetType() == typeof(WechatNoticeEvent);

        Task<bool> IEventHandler.CanHandle(IEvent @event)
        {
            throw new NotImplementedException();
        }
    }
}