﻿using Microsoft.Extensions.Configuration;
using RestSharp;
using Sand.Attributes;
using Sand.DI;
//using Sand.Domain.Chat.Entities;
//using Sand.Domain.Manager;
//using Sand.Domain.Manager.Bind;
using Sand.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Sand.Helpers;
using Sand.Extensions;
using Sand.Exceptions;
using System.Linq;
using Sand.Log.Less;
using Microsoft.AspNetCore.Http;
//using Sand.Domain.DomainService.MongoEntites;
//using Sand.Domain.DomainService;
using Sand.Context;

namespace Sand.Domain.Chat.Events
{
    /// <summary>
    /// 微信推送消息
    /// </summary>
    [Event]
    public class WechatNoticeEvent : IEvent
    {
        public WechatNoticeEvent()
        {
        }
        public WechatNotice LoadNotice()
        {
            WechatNotice notice = new WechatNotice();
            notice.template_id = TemplateId;
            notice.touser = AcceptId;
            notice.url = Url;
            //notice.data.first = new DataNode() { color = "red", value = First };
            //notice.data.keyword1 = new DataNode() { value = Keyword1 };
            //notice.data.keyword2 = new DataNode() { value = Keyword2 };
            //notice.data.keyword3 = new DataNode() { value = Keyword3 };
            //notice.data.keyword4 = new DataNode() { value = Keyword4 };
            //notice.data.keyword5 = new DataNode() { value = Keyword5 };
            //notice.data.keyword6 = new DataNode() { value = Keyword6 };
            //notice.data.keyword7 = new DataNode() { value = Keyword7 };
            //notice.data.keyword8 = new DataNode() { value = Keyword8 };
            //notice.data.keyword9 = new DataNode() { value = Keyword9 };
            //notice.data.keyword10 = new DataNode() { value = Keyword10 };
            //notice.data.remark = new DataNode() { value = Remark };
            return notice;
        }
        /// <summary>
        /// 微信推送模型
        /// </summary>
        public WechatNotice Notice { get { return LoadNotice(); } }
        /// <summary>
        /// 事件发生时间
        /// </summary>
        public DateTime Time { get; set; }
        /// <summary>
        /// 发送者
        /// </summary>
        public string NoticeId { get; set; }
        /// <summary>
        /// 接受消息者（微信key）
        /// </summary>
        public string AcceptId { get; set; }
        /// <summary>
        /// 传出参数（微信key，患者ID HISID 皆可）
        /// </summary>
        public string Param { get; set; }
        /// <summary>
        /// 事件编号
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 事件编号
        /// </summary>
        public string TemplateId { get; set; }
        /// <summary>
        /// 模板类型
        /// </summary>
        public string TemplateType { get; set; }
        /// <summary>
        /// 模板类型
        /// </summary>
        public WechatNoticeType Type => TemplateType.StringToEnum<WechatNoticeType>();
        /// <summary>
        /// 消息模板打开地址
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 第一节消息节点
        /// </summary>
        public string First { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword1 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword2 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword3 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword4 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword5 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword6 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword7 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword8 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword9 { get; set; }
        /// <summary>
        /// 消息节点
        /// </summary>
        public string Keyword10 { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        ///// <summary>
        ///// 挂号信息
        ///// </summary>
        //public Register Register { get; set; }

    }
    /// <summary>
    /// 微信通知发送消息
    /// </summary>
    [EventHandler]
    public class WechatNotice_EventHandler : IEventHandler<WechatNoticeEvent>
    {
        ///// <summary>
        ///// 第三方数据
        ///// </summary>
        //private readonly IThridManager _thridManager;
        //private readonly IConfiguration _configuration;
        //private readonly string _accessurl;
        //private readonly IRegisterService _registerService;
        //private readonly IUserContext _usercontext;

        /// <summary>
        /// 初始化
        /// </summary>
        public WechatNotice_EventHandler()
        {
            //_thridManager = Ioc.GetService<IThridManager>();
            //_configuration = Ioc.GetService<IConfiguration>();
            //_usercontext = Ioc.GetService<IUserContext>();
            //_registerService = Ioc.GetService<IRegisterService>();
            //_accessurl = $"/cgi-bin/message/template/send?access_token=";
        }


        private async Task WechatNoticeEvent(WechatNoticeEvent @event)
        {
            await Task.FromResult(true);
            //var template = WechatNoticeEvent().FirstOrDefault(t => t.Type == @event.Type);
            //if (template == null)
            //{
            //    throw new Warning("未配置微信通知模板");
            //}
            //@event.TemplateId = template.TemplateId;
            //if (@event.AcceptId.IsEmpty())
            //{
            //    @event.AcceptId = await _thridManager.AcceptId(@event.Param);
            //}
            //if (template.Remark.IsNotEmpty())
            //{
            //    @event.Remark = template.Remark;
            //}
            //if (template.Keyword1.IsNotEmpty())
            //{
            //    @event.Keyword1 = template.Keyword1;
            //}
            //if (template.Keyword2.IsNotEmpty())
            //{
            //    @event.Keyword2 = template.Keyword2;
            //}
            //if (template.Keyword3.IsNotEmpty())
            //{
            //    @event.Keyword3 = template.Keyword3;
            //}
            //if (template.Keyword4.IsNotEmpty())
            //{
            //    @event.Keyword4 = template.Keyword4;
            //}
            //if (template.Keyword5.IsNotEmpty())
            //{
            //    @event.Keyword5 = template.Keyword5;
            //}
            //if (template.Keyword6.IsNotEmpty())
            //{
            //    @event.Keyword6 = template.Keyword6;
            //}
            //if (template.Keyword7.IsNotEmpty())
            //{
            //    @event.Keyword7 = template.Keyword7;
            //}
            //if (template.Keyword8.IsNotEmpty())
            //{
            //    @event.Keyword8 = template.Keyword8;
            //}
            //if (template.Keyword9.IsNotEmpty())
            //{
            //    @event.Keyword9 = template.Keyword9;
            //}
            //if (template.Keyword10.IsNotEmpty())
            //{
            //    @event.Keyword10 = template.Keyword10;
            //}
            //@event.Url = $"https://{Web.Request.Host}/api/login/accessnotice/?patid={@event.Param}&redirect={template.Url}&code={ _usercontext.TenantId}";
            //@event.First = template.First;
        }
        //private List<WechatNoticeEvent> WechatNoticeEvent()
        //{
        //    var value = _configuration.GetSection("Notice:Wechat").Get<List<WechatNoticeEvent>>();
        //    if (value == null)
        //        throw new Warning("未配置微信通知模板");
        //    return value;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="event"></param>
        /// <returns></returns>
        public bool CanHandle(IEvent @event)
             => @event.GetType().Equals(typeof(WechatNoticeEvent));
        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<bool> HandleAsync(IEvent @event, CancellationToken cancellationToken = default)
               => CanHandle(@event) ? HandleAsync((WechatNoticeEvent)@event, cancellationToken) : Task.FromResult(false);

        public async Task<bool> HandleAsync(WechatNoticeEvent @event, CancellationToken cancellationToken = default)
        {
            return await Task.FromResult(true);
        }

        Task<bool> IEventHandler.CanHandle(IEvent @event)
        {
            throw new NotImplementedException();
        }
    }
}
