﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Chat.Events
{
    /// <summary>
    /// 通知类型
    /// </summary>
    public enum WechatNoticeType
    {
        /// <summary>
        /// 支付通知
        /// </summary>
        [Description("001")]
        Payment = 1,
        /// <summary>
        /// 挂号通知
        /// </summary>
        [Description("002")]
        Resgiter = 2,
        /// <summary>
        /// 就诊通知
        /// </summary>
        [Description("003")]
        Consultation = 3,
        /// <summary>
        /// 发起退款通知
        /// </summary>
        [Description("004")]
        RefundNotice = 4,
        /// <summary>
        /// 退款失败通知
        /// </summary>
        [Description("005")]
        RefundFailNotice = 5,
        /// <summary>
        /// 退款成功通知
        /// </summary>
        [Description("006")]
        RefundSuccessNotice = 6,
        /// <summary>
        /// 取药通知1
        /// </summary>
        [Description("007")]
        TakeMedicine = 7,
        /// <summary>
        /// 停诊通知
        /// </summary>
        [Description("008")]
        StopExamining = 8,
        /// <summary>
        /// 检查通知1
        /// </summary>
        [Description("009")]
        Inspect = 9,
        /// <summary>
        /// 门诊缴费提醒
        /// </summary>
        [Description("010")]
        PaymentReminder = 10,
        /// <summary>
        /// 订单审核通知（拍方抓药）
        /// </summary>
        [Description("011")]
        PatronAudit = 11,
        /// <summary>
        /// 订单审核通知（便民门诊）
        /// </summary>
        [Description("012")]
        ConvenientAudit = 12,
        /// <summary>
        /// 医院消息提醒
        /// </summary>
        [Description("013")]
        Message = 13,
        /// <summary>
        /// 订单审核通知（拍方抓药）
        /// </summary>
        [Description("014")]
        Patron = 14,
        /// <summary>
        /// 订单通知（便民门诊）
        /// </summary>
        [Description("015")]
        Convenient = 15,
        /// <summary>
        /// 其他通知1
        /// </summary>
        [Description("016")]
        Other = 16,
    }
}
