﻿using Microsoft.Extensions.Configuration;
using RestSharp;
using Sand.Attributes;
using Sand.DI;
//using Sand.Domain.Chat.Entities;
//using Sand.Domain.Manager;
//using Sand.Domain.Manager.Bind;
using Sand.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Sand.Helpers;
using Sand.Extensions;
using Sand.Exceptions;
using System.Linq;
using Sand.Log.Less;
using Microsoft.AspNetCore.Http;
//using Sand.Domain.DomainService.MongoEntites;
//using Sand.Domain.DomainService;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Data;

namespace Sand.Domain.Chat.Events
{
    /// <summary>
    /// 退款处理
    /// </summary>
    [Event]
    public class RefundEvent : IEvent
    {
        public RefundEvent()
        {
        }
        /// <summary>
        /// 事件编号
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 事件发生时间
        /// </summary>

        public DateTime Time { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string OrdersId { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public RefundStatus Status { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
    }

    /// <summary>
    /// 退款处理
    /// </summary>
    [EventHandler]
    public class Refund_EventHandler : IEventHandler<RefundEvent>
    {
        private readonly ISqlQuery _sqlQuery;
        /// <summary>
        /// 初始化
        /// </summary>
        public Refund_EventHandler()
        {
            _sqlQuery = Ioc.GetService<ISqlQuery>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="event"></param>
        /// <returns></returns>
        public bool CanHandle(IEvent @event)
             => @event.GetType().Equals(typeof(RefundEvent));

        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<bool> HandleAsync(RefundEvent @event, CancellationToken cancellationToken = default)
        {
            try
            {
                //修改为退款失败
                await _sqlQuery.ExecuteAsync("update Refund set Status=?Status,FailureReasons=?FailureReasons,LastUpdateId=@LastUpdateId,LastUpdateName=@LastUpdateName,LastUpdateTime=@LastUpdateTime where OrdersId=?OrdersId",
                    new { @event.OrdersId, FailureReasons = @event.Remark, Status = @event.Status.Value(), LastUpdateId = @event.UserId, LastUpdateName = @event.UserName, LastUpdateTime = DateTime.Now });
                return await Task.FromResult(true);

            }
            catch (Exception ex)
            {
                ex.Submit();
                return await Task.FromResult(false);
            }
        }
        /// <summary>
        /// 发布事件
        /// </summary>
        /// <param name="event"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<bool> HandleAsync(IEvent @event, CancellationToken cancellationToken = default)
               => CanHandle(@event) ? HandleAsync((RefundEvent)@event, cancellationToken) : Task.FromResult(false);

        Task<bool> IEventHandler.CanHandle(IEvent @event)
        {
            throw new NotImplementedException();
        }
    }

}
