﻿using System;
using System.ComponentModel.DataAnnotations;
using Sand.Domain.Query;
using Sand.Domain.Entities.PaymentOrder;


namespace Sand.Domain.Queries.PaymentOrder {
    /// <summary>
    ///  第三方支付信息查询实体
    /// </summary>
    public class PaymentQuery :  BaseQuery<Payment> {
        
        private string _id = string.Empty;
        /// <summary>
        /// 编号
        /// </summary>
        [Display(Name="编号")]
        public string Id {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set{ _id=value;}
        }        
        
        private string _payUserId = string.Empty;
        /// <summary>
        /// 支付者
        /// </summary>
        [Display(Name="支付者")]
        public string PayUserId {
            get { return _payUserId == null ? string.Empty : _payUserId.Trim(); }
            set{ _payUserId=value;}
        }        
        
        private string _payUserName = string.Empty;
        /// <summary>
        /// 支付者
        /// </summary>
        [Display(Name="支付者")]
        public string PayUserName {
            get { return _payUserName == null ? string.Empty : _payUserName.Trim(); }
            set{ _payUserName=value;}
        }        
        /// <summary>
        /// 起始支付时间
        /// </summary>
        [Display( Name = "起始支付时间" )]
        public DateTime? BeginPayDate { get; set; }
        /// <summary>
        /// 结束支付时间
        /// </summary>
        [Display( Name = "结束支付时间" )]
        public DateTime? EndPayDate { get; set; }        
        /// <summary>
        /// 支付类型(1,Web,2.App,3小程序,4.Wap)
        /// </summary>
        [Display(Name="支付类型(1,Web,2.App,3小程序,4.Wap)")]
        public int? PayType { get; set; }
        /// <summary>
        /// 支付状态(0支付失效,1,等待支付,2支付成功,3部分退费,4完成退费)
        /// </summary>
        [Display(Name="支付状态(0支付失效,1,等待支付,2支付成功,3部分退费,4完成退费)")]
        public int? Status { get; set; }
        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        [Display(Name="支付金额（分为单位）")]
        public int? Amount { get; set; }
        /// <summary>
        /// 已退费金额（分为单位）
        /// </summary>
        [Display(Name="已退费金额（分为单位）")]
        public int? RefundAmount { get; set; }
        /// <summary>
        /// 确认已支付金额（分为单位）
        /// </summary>
        [Display(Name="确认已支付金额（分为单位）")]
        public int? ComfirmAmount { get; set; }
        
        private string _tradeNo = string.Empty;
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [Display(Name="支付平台订单号")]
        public string TradeNo {
            get { return _tradeNo == null ? string.Empty : _tradeNo.Trim(); }
            set{ _tradeNo=value;}
        }        
        
        private string _outTradeNo = string.Empty;
        /// <summary>
        /// 系统订单号
        /// </summary>
        [Display(Name="系统订单号")]
        public string OutTradeNo {
            get { return _outTradeNo == null ? string.Empty : _outTradeNo.Trim(); }
            set{ _outTradeNo=value;}
        }        
        /// <summary>
        /// 支付平台(1,微信,2,支付宝,3银联,4.QQ)
        /// </summary>
        [Display(Name="支付平台(1,微信,2,支付宝,3银联,4.QQ)")]
        public int? PayPlatform { get; set; }
        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display( Name = "起始创建时间" )]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display( Name = "结束创建时间" )]
        public DateTime? EndCreateTime { get; set; }        
        
        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name="创建者")]
        public string CreateId {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set{ _createId=value;}
        }        
        
        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name="创建人")]
        public string CreateName {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set{ _createName=value;}
        }        
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display( Name = "起始最近更新时间" )]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display( Name = "结束最近更新时间" )]
        public DateTime? EndLastUpdateTime { get; set; }        
        
        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name="最近更新者")]
        public string LastUpdateId {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set{ _lastUpdateId=value;}
        }        
        
        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name="最近更新人")]
        public string LastUpdateName {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set{ _lastUpdateName=value;}
        }        
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name="是否可用")]
        public sbyte? IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Display(Name="删除标志")]
        public sbyte? IsDeleted { get; set; }
        
        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name="版本号")]
        public string Version {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set{ _version=value;}
        }        
        
    }
}
