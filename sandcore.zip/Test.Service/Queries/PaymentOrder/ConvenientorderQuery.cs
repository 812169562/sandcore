﻿using System;
using System.ComponentModel.DataAnnotations;
using Sand.Domain.Query;
using Sand.Domain.Entities.PaymentOrder;


namespace Sand.Domain.Queries.PaymentOrder {
    /// <summary>
    /// convenientorder查询实体
    /// </summary>
    public class ConvenientorderQuery :  BaseQuery<Convenientorder> {
        
        private string _id = string.Empty;
        /// <summary>
        /// 编号
        /// </summary>
        [Display(Name="编号")]
        public string Id {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set{ _id=value;}
        }        
        
        private string _cardId = string.Empty;
        /// <summary>
        /// 就诊卡编号
        /// </summary>
        [Display(Name="就诊卡编号")]
        public string CardId {
            get { return _cardId == null ? string.Empty : _cardId.Trim(); }
            set{ _cardId=value;}
        }        
        
        private string _registerChargeId = string.Empty;
        /// <summary>
        /// HIS挂号费用记录编号
        /// </summary>
        [Display(Name="HIS挂号费用记录编号")]
        public string RegisterChargeId {
            get { return _registerChargeId == null ? string.Empty : _registerChargeId.Trim(); }
            set{ _registerChargeId=value;}
        }        
        
        private string _chargeJson = string.Empty;
        /// <summary>
        /// HIS费用表信息
        /// </summary>
        [Display(Name="HIS费用表信息")]
        public string ChargeJson {
            get { return _chargeJson == null ? string.Empty : _chargeJson.Trim(); }
            set{ _chargeJson=value;}
        }        
        
        private string _chargeDetalisJson = string.Empty;
        /// <summary>
        /// HIS费用明细表信息
        /// </summary>
        [Display(Name="HIS费用明细表信息")]
        public string ChargeDetalisJson {
            get { return _chargeDetalisJson == null ? string.Empty : _chargeDetalisJson.Trim(); }
            set{ _chargeDetalisJson=value;}
        }        
        /// <summary>
        /// 类型（1.便民 2.拍方抓药）
        /// </summary>
        [Display(Name="类型（1.便民 2.拍方抓药）")]
        public int? Type { get; set; }
        /// <summary>
        ///  状态(1.待审核2.审核通过3.驳回)
        /// </summary>
        [Display(Name=" 状态(1.待审核2.审核通过3.驳回)")]
        public int? Status { get; set; }
        
        private string _userId = string.Empty;
        /// <summary>
        /// 医生编号
        /// </summary>
        [Display(Name="医生编号")]
        public string UserId {
            get { return _userId == null ? string.Empty : _userId.Trim(); }
            set{ _userId=value;}
        }        
        /// <summary>
        /// 起始审核时间
        /// </summary>
        [Display( Name = "起始审核时间" )]
        public DateTime? BeginAuditTime { get; set; }
        /// <summary>
        /// 结束审核时间
        /// </summary>
        [Display( Name = "结束审核时间" )]
        public DateTime? EndAuditTime { get; set; }        
        
        private string _auditId = string.Empty;
        /// <summary>
        /// 审核人编号
        /// </summary>
        [Display(Name="审核人编号")]
        public string AuditId {
            get { return _auditId == null ? string.Empty : _auditId.Trim(); }
            set{ _auditId=value;}
        }        
        
        private string _auditName = string.Empty;
        /// <summary>
        /// 审核人名字
        /// </summary>
        [Display(Name="审核人名字")]
        public string AuditName {
            get { return _auditName == null ? string.Empty : _auditName.Trim(); }
            set{ _auditName=value;}
        }        
        
        private string _remark = string.Empty;
        /// <summary>
        /// 备注
        /// </summary>
        [Display(Name="备注")]
        public string Remark {
            get { return _remark == null ? string.Empty : _remark.Trim(); }
            set{ _remark=value;}
        }        
        
        private string _imageNewName = string.Empty;
        /// <summary>
        /// 图片编号
        /// </summary>
        [Display(Name="图片编号")]
        public string ImageNewName {
            get { return _imageNewName == null ? string.Empty : _imageNewName.Trim(); }
            set{ _imageNewName=value;}
        }        
        /// <summary>
        /// 数量
        /// </summary>
        [Display(Name="数量")]
        public int? Count { get; set; }
        /// <summary>
        /// 药品类型（1.饮片2.小包装3.免煎）
        /// </summary>
        [Display(Name="药品类型（1.饮片2.小包装3.免煎）")]
        public int? DrugType { get; set; }
        /// <summary>
        /// 处方类型(1.中药2.西药)
        /// </summary>
        [Display(Name="处方类型(1.中药2.西药)")]
        public int? PrescriptionType { get; set; }
        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display( Name = "起始创建时间" )]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display( Name = "结束创建时间" )]
        public DateTime? EndCreateTime { get; set; }        
        
        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name="创建者")]
        public string CreateId {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set{ _createId=value;}
        }        
        
        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name="创建人")]
        public string CreateName {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set{ _createName=value;}
        }        
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display( Name = "起始最近更新时间" )]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display( Name = "结束最近更新时间" )]
        public DateTime? EndLastUpdateTime { get; set; }        
        
        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name="最近更新者")]
        public string LastUpdateId {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set{ _lastUpdateId=value;}
        }        
        
        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name="最近更新人")]
        public string LastUpdateName {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set{ _lastUpdateName=value;}
        }        
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name="是否可用")]
        public sbyte? IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Display(Name="删除标志")]
        public sbyte? IsDeleted { get; set; }
        
        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name="版本号")]
        public string Version {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set{ _version=value;}
        }
        /// <summary>
        /// 审核备注
        /// </summary>
        public string AuditRemark { get; set; }
        /// <summary>
        /// 执行科室
        /// </summary>
        public string ExecuteId { get; set; }
        /// <summary>
        /// 执行科室
        /// </summary>
        public string ExecuteName { get; set; }
        /// <summary>
        /// 是否配送
        /// </summary>
        public bool? IsDelivery { get; set; }
        /// <summary>
        /// 是否代煎
        /// </summary>
        public bool? IsDecocting { get; set; }
        /// <summary>
        /// 收货人
        /// </summary>
        public string Consignee { get; set; }
        /// <summary>
        /// 收货人电话
        /// </summary>
        public string Tel { get; set; }
        /// <summary>
        /// 收货人地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 快递单号
        /// </summary>
        public string CourierNumber { get; set; }
        /// <summary>
        /// 快递
        /// </summary>
        public string ExpressId { get; set; }
        /// <summary>
        /// 快递名称
        /// </summary>
        public string ExpressName { get; set; }

    }
}
