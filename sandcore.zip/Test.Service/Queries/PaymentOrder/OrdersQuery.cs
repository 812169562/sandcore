﻿using System;
using System.ComponentModel.DataAnnotations;
using Sand.Domain.Query;
using Sand.Domain.Entities.PaymentOrder;


namespace Sand.Domain.Queries.PaymentOrder {
    /// <summary>
    /// 订单表查询实体
    /// </summary>
    public class OrdersQuery :  BaseQuery<Orders> {
        
        private string _id = string.Empty;
        /// <summary>
        /// 编号
        /// </summary>
        [Display(Name="编号")]
        public string Id {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set{ _id=value;}
        }        
        
        private string _outId = string.Empty;
        /// <summary>
        /// 外部编号(此处HISId)
        /// </summary>
        [Display(Name="外部编号(此处HISId)")]
        public string OutId {
            get { return _outId == null ? string.Empty : _outId.Trim(); }
            set{ _outId=value;}
        }        
        
        private string _cardId = string.Empty;
        /// <summary>
        /// 患者编号
        /// </summary>
        [Display(Name="患者编号")]
        public string CardId {
            get { return _cardId == null ? string.Empty : _cardId.Trim(); }
            set{ _cardId=value;}
        }        
        
        private string _outPatientId = string.Empty;
        /// <summary>
        /// 患者编号(外部系统编号和CardId1-1)
        /// </summary>
        [Display(Name="患者编号(外部系统编号和CardId1-1)")]
        public string OutPatientId {
            get { return _outPatientId == null ? string.Empty : _outPatientId.Trim(); }
            set{ _outPatientId=value;}
        }        
        /// <summary>
        /// 订单状态(0失效,1,待付款,2已支付,3已完成,-1退款中,-2退款完成,-3已取消)
        /// </summary>
        [Display(Name="订单状态(0失效,1,待付款,2已支付,3已完成,-1退款中,-2退款完成,-3已取消)")]
        public int? Status { get; set; }
        /// <summary>
        /// 类型(1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目)
        /// </summary>
        [Display(Name="类型(1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目)")]
        public int? Type { get; set; }
        
        private string _paymentId = string.Empty;
        /// <summary>
        /// 支付编号
        /// </summary>
        [Display(Name="支付编号")]
        public string PaymentId {
            get { return _paymentId == null ? string.Empty : _paymentId.Trim(); }
            set{ _paymentId=value;}
        }        
        
        private string _tradeNo = string.Empty;
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [Display(Name="支付平台订单号")]
        public string TradeNo {
            get { return _tradeNo == null ? string.Empty : _tradeNo.Trim(); }
            set{ _tradeNo=value;}
        }        
        
        private string _outTradeNo = string.Empty;
        /// <summary>
        /// 系统订单号
        /// </summary>
        [Display(Name="系统订单号")]
        public string OutTradeNo {
            get { return _outTradeNo == null ? string.Empty : _outTradeNo.Trim(); }
            set{ _outTradeNo=value;}
        }        
        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        [Display(Name="支付金额（分为单位）")]
        public int? Amount { get; set; }
        
        private string _remark = string.Empty;
        /// <summary>
        /// 备注信息
        /// </summary>
        [Display(Name="备注信息")]
        public string Remark {
            get { return _remark == null ? string.Empty : _remark.Trim(); }
            set{ _remark=value;}
        }        
        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display( Name = "起始创建时间" )]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display( Name = "结束创建时间" )]
        public DateTime? EndCreateTime { get; set; }        
        
        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name="创建者")]
        public string CreateId {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set{ _createId=value;}
        }        
        
        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name="创建人")]
        public string CreateName {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set{ _createName=value;}
        }        
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display( Name = "起始最近更新时间" )]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display( Name = "结束最近更新时间" )]
        public DateTime? EndLastUpdateTime { get; set; }        
        
        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name="最近更新者")]
        public string LastUpdateId {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set{ _lastUpdateId=value;}
        }        
        
        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name="最近更新人")]
        public string LastUpdateName {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set{ _lastUpdateName=value;}
        }        
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name="是否可用")]
        public sbyte? IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Display(Name="删除标志")]
        public sbyte? IsDeleted { get; set; }
        
        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name="版本号")]
        public string Version {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set{ _version=value;}
        }        
        /// <summary>
        /// 是否后台管理查询
        /// </summary>
        public bool IsManage { get; set; }
        /// <summary>
        /// 就诊开始时间
        /// </summary>
        [Display(Name = "就诊开始时间")]
        public DateTime? BeginTreatmentTime { get; set; }
        /// <summary>
        /// 就诊结束时间
        /// </summary>
        [Display(Name = "就诊结束时间")]
        public DateTime? EndTreatmentTime { get; set; }
        /// <summary>
        /// 坐诊ID
        /// </summary>
        public string SittingId { get; set; }
        /// <summary>
        /// 便民订单编号
        /// </summary>
        public string ConvenientOrderId { get; set; }
        /// <summary>
        /// 医生编号
        /// </summary>
        public string UserId { get; set; }
    }
}
