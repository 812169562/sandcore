﻿using Sand.Domain.Entities.PaymentOrder;
using Sand.Domain.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Sand.Domain.Queries.PaymentOrder
{
    /// <summary>
    /// 在线问诊订单查询实体
    /// </summary>
    public class ChatOrdersQuery : BaseQuery<ChatOrders>
    {
        private string _id = string.Empty;
        /// <summary>
        /// 编号
        /// </summary>
        [Display(Name = "编号")]
        public string Id
        {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set { _id = value; }
        }

        private string _userId = string.Empty;
        /// <summary>
        /// 医生编号
        /// </summary>
        [Display(Name = "医生编号")]
        public string UserId
        {
            get { return _userId == null ? string.Empty : _userId.Trim(); }
            set { _userId = value; }
        }

        /// <summary>
        /// 医生姓名
        /// </summary>
        [Display(Name = "医生姓名")]
        public string UserName { get; set; }

        private string _patientId = string.Empty;
        /// <summary>
        /// 患者编号
        /// </summary>
        [Display(Name = "患者编号")]
        public string PatientId
        {
            get { return _patientId == null ? string.Empty : _patientId.Trim(); }
            set { _patientId = value; }
        }

        private string _outPatientId = string.Empty;
        /// <summary>
        /// 患者姓名
        /// </summary>
        [Display(Name = "患者姓名")]
        public string PatientName { get; set; }

        /// <summary>
        /// 科室
        /// </summary>
        [Display(Name = "科室")]
        public string DepartmentName { get; set; }
        
        private string _departmentId = string.Empty;
        /// <summary>
        /// 科室Id
        /// </summary>
        [Display(Name = "科室Id")]
        public string DepartmentId
        {
            get { return _departmentId == null ? string.Empty : _departmentId.Trim(); }
            set { _departmentId = value; }
        }

        /// <summary>
        /// 编码
        /// </summary>
        [Display(Name = "编码")]
        public string Code { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [Display(Name = "职称")]
        public string Title { get; set; }

        /// <summary>
        /// 订单状态(0失效,1待付款,2已支付,3已完成)
        /// </summary>
        [Display(Name = "订单状态(0失效,1待付款,2已支付,3已完成)")]
        public int? Status { get; set; }
        /// <summary>
        /// 类型(1图文,2电话,3视频)
        /// </summary>
        [Display(Name = "类型(1图文,2电话,3视频)")]
        public int? Type { get; set; }
        /// <summary>
        /// 订单生成时间
        /// </summary>
        [Display(Name = "订单生成时间")]
        public DateTime? BeginTime { get; set; }
        /// <summary>
        /// 订单结束时间
        /// </summary>
        [Display(Name = "订单结束时间")]
        public DateTime? EndTime { get; set; }

        private string _tradeNo = string.Empty;
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [Display(Name = "支付平台订单号")]
        public string TradeNo
        {
            get { return _tradeNo == null ? string.Empty : _tradeNo.Trim(); }
            set { _tradeNo = value; }
        }

        private string _outTradeNo = string.Empty;
        /// <summary>
        /// 系统订单号
        /// </summary>
        [Display(Name = "系统订单号")]
        public string OutTradeNo
        {
            get { return _outTradeNo == null ? string.Empty : _outTradeNo.Trim(); }
            set { _outTradeNo = value; }
        }

        /// <summary>
        /// 订单支付时间
        /// </summary>
        [Display(Name = "订单支付时间")]
        public DateTime? PayTime { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        [Display(Name = "支付金额")]
        public int? Money { get; set; }

        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display(Name = "起始创建时间")]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display(Name = "结束创建时间")]
        public DateTime? EndCreateTime { get; set; }

        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name = "创建者")]
        public string CreateId
        {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set { _createId = value; }
        }

        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name = "创建人")]
        public string CreateName
        {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set { _createName = value; }
        }
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display(Name = "起始最近更新时间")]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display(Name = "结束最近更新时间")]
        public DateTime? EndLastUpdateTime { get; set; }

        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name = "最近更新者")]
        public string LastUpdateId
        {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set { _lastUpdateId = value; }
        }

        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name = "最近更新人")]
        public string LastUpdateName
        {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set { _lastUpdateName = value; }
        }
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name = "是否可用")]
        public sbyte? IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Display(Name = "删除标志")]
        public sbyte? IsDeleted { get; set; }

        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name = "版本号")]
        public string Version
        {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set { _version = value; }
        }
    }
}
