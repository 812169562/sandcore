﻿using System;
using System.ComponentModel.DataAnnotations;
using Sand.Domain.Query;
using Sand.Domain.Entities.PaymentOrder;


namespace Sand.Domain.Queries.PaymentOrder {
    /// <summary>
    /// 支付日志查询实体
    /// </summary>
    public class PaymentlogQuery :  BaseQuery<Paymentlog> {
        
        private string _id = string.Empty;
        /// <summary>
        /// 编号
        /// </summary>
        [Display(Name="编号")]
        public string Id {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set{ _id=value;}
        }        
        
        private string _paymentId支付编号 = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        [Display(Name="")]
        public string PaymentId支付编号 {
            get { return _paymentId支付编号 == null ? string.Empty : _paymentId支付编号.Trim(); }
            set{ _paymentId支付编号=value;}
        }        
        /// <summary>
        /// 支付总金额(退费时为负数,分为单位）
        /// </summary>
        [Display(Name="支付总金额(退费时为负数,分为单位）")]
        public int? Amount { get; set; }
        
        private string _input = string.Empty;
        /// <summary>
        /// 传入参数
        /// </summary>
        [Display(Name="传入参数")]
        public string Input {
            get { return _input == null ? string.Empty : _input.Trim(); }
            set{ _input=value;}
        }        
        
        private string _output = string.Empty;
        /// <summary>
        /// 返回数据
        /// </summary>
        [Display(Name="返回数据")]
        public string Output {
            get { return _output == null ? string.Empty : _output.Trim(); }
            set{ _output=value;}
        }        
        
        private string _paymentChargeLog = string.Empty;
        /// <summary>
        /// 支付变化情况
        /// </summary>
        [Display(Name="支付变化情况")]
        public string PaymentChargeLog {
            get { return _paymentChargeLog == null ? string.Empty : _paymentChargeLog.Trim(); }
            set{ _paymentChargeLog=value;}
        }        
        /// <summary>
        /// 支付状态(1,等待支付,2支付成功,3,退费)
        /// </summary>
        [Display(Name="支付状态(1,等待支付,2支付成功,3,退费)")]
        public int? Status { get; set; }
        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display( Name = "起始创建时间" )]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display( Name = "结束创建时间" )]
        public DateTime? EndCreateTime { get; set; }        
        
        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name="创建者")]
        public string CreateId {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set{ _createId=value;}
        }        
        
        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name="创建人")]
        public string CreateName {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set{ _createName=value;}
        }        
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display( Name = "起始最近更新时间" )]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display( Name = "结束最近更新时间" )]
        public DateTime? EndLastUpdateTime { get; set; }        
        
        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name="最近更新者")]
        public string LastUpdateId {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set{ _lastUpdateId=value;}
        }        
        
        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name="最近更新人")]
        public string LastUpdateName {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set{ _lastUpdateName=value;}
        }        
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name="是否可用")]
        public sbyte? IsEnable { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Display(Name="删除标志")]
        public sbyte? IsDeleted { get; set; }
        
        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name="版本号")]
        public string Version {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set{ _version=value;}
        }        
        
        private string _ip = string.Empty;
        /// <summary>
        /// Ip
        /// </summary>
        [Display(Name="Ip")]
        public string Ip {
            get { return _ip == null ? string.Empty : _ip.Trim(); }
            set{ _ip=value;}
        }        
        
    }
}
