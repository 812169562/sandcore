﻿using System;
using System.ComponentModel.DataAnnotations;
using Sand.Domain.Query;
using System.Collections.Generic;

namespace Test.Service.Domain
{
    /// <summary>
    /// 用户表查询实体
    /// </summary>
    public class UsersQuery :  BaseQuery<Users> {
        
        /// <summary>
        /// 
        /// </summary>
        public string Md5 { get; set; }
        private string _id = string.Empty;
        /// <summary>
        /// 用户主键编号
        /// </summary>
        [Display(Name="用户主键编号")]
        public string Id {
            get { return _id == null ? string.Empty : _id.Trim(); }
            set{ _id=value;}
        }        
        
        private string _userName = string.Empty;
        /// <summary>
        /// 用户名
        /// </summary>
        [Display(Name="用户名")]
        public string UserName {
            get { return _userName == null ? string.Empty : _userName.Trim(); }
            set{ _userName=value;}
        }        
        
        private string _loginCode = string.Empty;
        /// <summary>
        /// 登陆号
        /// </summary>
        [Display(Name="登陆号")]
        public string LoginCode {
            get { return _loginCode == null ? string.Empty : _loginCode.Trim(); }
            set{ _loginCode=value;}
        }        
        
        private string _tel = string.Empty;
        /// <summary>
        /// 电话号码
        /// </summary>
        [Display(Name="电话号码")]
        public string Tel {
            get { return _tel == null ? string.Empty : _tel.Trim(); }
            set{ _tel=value;}
        }        
        
        private string _pwd = string.Empty;
        /// <summary>
        /// 密码
        /// </summary>
        [Display(Name="密码")]
        public string Pwd {
            get { return _pwd == null ? string.Empty : _pwd.Trim(); }
            set{ _pwd=value;}
        }        
        /// <summary>
        /// 性别
        /// </summary>
        [Display(Name="性别")]
        public int? Sex { get; set; }
        
        private string _weiXinKey = string.Empty;
        /// <summary>
        /// 微信识别号
        /// </summary>
        [Display(Name="微信识别号")]
        public string WeiXinKey {
            get { return _weiXinKey == null ? string.Empty : _weiXinKey.Trim(); }
            set{ _weiXinKey = value;}
        }        
        
        /// <summary>
        /// 类型
        /// </summary>
        [Display(Name="类型")]
        public int? Type { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        [Display(Name="是否可用")]
        public bool? IsEnable { get; set; }
        /// <summary>
        /// 起始创建时间
        /// </summary>
        [Display( Name = "起始创建时间" )]
        public DateTime? BeginCreateTime { get; set; }
        /// <summary>
        /// 结束创建时间
        /// </summary>
        [Display( Name = "结束创建时间" )]
        public DateTime? EndCreateTime { get; set; }        
        
        private string _createId = string.Empty;
        /// <summary>
        /// 创建者
        /// </summary>
        [Display(Name="创建者")]
        public string CreateId {
            get { return _createId == null ? string.Empty : _createId.Trim(); }
            set{ _createId=value;}
        }        
        
        private string _createName = string.Empty;
        /// <summary>
        /// 创建人
        /// </summary>
        [Display(Name="创建人")]
        public string CreateName {
            get { return _createName == null ? string.Empty : _createName.Trim(); }
            set{ _createName=value;}
        }        
        /// <summary>
        /// 起始最近更新时间
        /// </summary>
        [Display( Name = "起始最近更新时间" )]
        public DateTime? BeginLastUpdateTime { get; set; }
        /// <summary>
        /// 结束最近更新时间
        /// </summary>
        [Display( Name = "结束最近更新时间" )]
        public DateTime? EndLastUpdateTime { get; set; }        
        
        private string _lastUpdateId = string.Empty;
        /// <summary>
        /// 最近更新者
        /// </summary>
        [Display(Name="最近更新者")]
        public string LastUpdateId {
            get { return _lastUpdateId == null ? string.Empty : _lastUpdateId.Trim(); }
            set{ _lastUpdateId=value;}
        }        
        
        private string _lastUpdateName = string.Empty;
        /// <summary>
        /// 最近更新人
        /// </summary>
        [Display(Name="最近更新人")]
        public string LastUpdateName {
            get { return _lastUpdateName == null ? string.Empty : _lastUpdateName.Trim(); }
            set{ _lastUpdateName=value;}
        }        
        
        private string _version = string.Empty;
        /// <summary>
        /// 版本号
        /// </summary>
        [Display(Name="版本号")]
        public string Version {
            get { return _version == null ? string.Empty : _version.Trim(); }
            set{ _version=value;}
        }
        /// <summary>
        /// 科室
        /// </summary>
        [Display(Name = "科室")]
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [Display(Name = "科室")]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [Display(Name = "职称")]
        public string Title { get; set; }
        /// <summary>
        /// 起始坐诊日期
        /// </summary>
        [Display(Name = "起始坐诊日期")]
        public DateTime? BeginSittingDate { get; set; }
        /// <summary>
        /// 结束坐诊日期
        /// </summary>
        [Display(Name = "结束坐诊日期")]
        public DateTime? EndSittingDate { get; set; }
        /// <summary>
        /// 是否便民
        /// </summary>
        [Display(Name = "是否便民")]
        public bool? IsConvenient { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        [Display(Name = "小程序ID")]
        public string AppOpenId1 { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        [Display(Name = "小程序ID2")]
        public string AppOpenId2 { get; set; }
        /// <summary>
        /// 拍方抓药
        /// </summary>
        [Display(Name = "拍方抓药")]
        public bool? IsPatron { get; set; }
        /// <summary>
        /// 登录类型
        /// </summary>
        public int LoginType { get; set; }

        /// <summary>
        /// 排序号
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否推荐
        /// </summary>
        public bool? IsRecommend { get; set; }
        /// <summary>
        /// 密码错误次数
        /// </summary>
        public int? PwdErrorCount { get; set; }
        /// <summary>
        /// 登录状态
        /// </summary>
        public int? LogonStatus { get; set; }
        /// <summary>
        /// 锁定状态
        /// </summary>
        public int? LockedStatus { get; set; }
        /// <summary>
        /// 诊断分类编号
        /// </summary>
        public string TagId { get; set; }
        /// <summary>
        /// 症状
        /// </summary>
        public string SymptomData { get; set; }
        /// <summary>
        /// 在线问诊标志
        /// </summary>
        public bool? OnlineConsultation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UnionId { get; set; }

        /// <summary>
        /// 图文咨询费用
        /// </summary>
        public decimal? GraphicFees { get; set; }
        /// <summary>
        ///  电话咨询费
        /// </summary>
        public decimal? TelephoneFee { get; set; }
        /// <summary>
        ///  视频咨询费
        /// </summary>
        public decimal? VideoFee { get; set; }

    }
}
