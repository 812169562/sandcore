﻿using Sand.Domain.Repositories;

namespace Test.Service.Domain
{
    /// <summary>
    /// 用户表仓储
    /// </summary>
    public interface IUsersRepository : IRepository<Users> {
    }
}
