﻿using System;
using Sand.Dependency;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Sand.Helpers;
using Sand.Utils.Enums;
using Sand.Domain.Entities;

namespace Test.Service.Domain
{
    /// <summary>
    /// 用户表
    /// </summary>
    [Description( "用户表" )]
    public partial class Users : Entity,ISoftDelete {
        /// <summary>
        /// 初始化用户表
        /// </summary>
        public Users(){
        }

        /// <summary>
        /// 拼音
        /// </summary>
        public string PinYin { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        [Required(ErrorMessage = "用户名不能为空")]
        [StringLength( 36, ErrorMessage = "用户名输入过长，不能超过36位" )]
        public string UserName { get; set; }
        /// <summary>
        /// 登陆号
        /// </summary>
        [Required(ErrorMessage = "登陆号不能为空")]
        [StringLength(25, ErrorMessage = "登陆号输入过长，不能超过25位" )]
        public string LoginCode { get; set; }
        /// <summary>
        /// 电话号码
        /// </summary>
        [StringLength(25, ErrorMessage = "电话号码输入过长，不能超过25位" )]
        public string Tel { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        [StringLength( 36, ErrorMessage = "密码输入过长，不能超过36位" )]
        public string Pwd { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        public SexType? Sex { get; set; }
        /// <summary>
        /// 微信识别号
        /// </summary>
        [StringLength( 128, ErrorMessage = "微信识别号输入过长，不能超过128位" )]
        public string WeiXinKey { get; set; }
        /// <summary>
        /// 类型
        /// </summary>
        [Required(ErrorMessage = "类型不能为空")]
        public int Type { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        ///  医馆号
        /// </summary>
        [NotMapped]
        public override string TenantId { get; set; }
        /// <summary>
        /// 门店号
        /// </summary>
        [NotMapped]
        public override string StroeId { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        public string AvatarUrl { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [Required(ErrorMessage = "科室不能为空")]
        public string DepartmentId { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        [Required(ErrorMessage = "科室不能为空")]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        [Required(ErrorMessage = "职称不能为空")]
        public string Title { get; set; }
        /// <summary>
        /// his关联id
        /// </summary>
        public string OtherId { get; set; }
        /// <summary>
        /// 科室关系
        /// </summary>
        public string RelationShip { get; set; }
        /// <summary>
        /// 医生简介
        /// </summary>
        public string Synopsis { get; set; }
        /// <summary>
        /// 擅长
        /// </summary>
        public string Adept { get; set; }
        /// <summary>
        /// 是否便民
        /// </summary>
        public bool? IsConvenient { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        public string AppOpenId1 { get; set; }
        /// <summary>
        /// 小程序ID
        /// </summary>
        public string AppOpenId2 { get; set; }
        /// <summary>
        /// 拍方抓药
        /// </summary>
        public bool? IsPatron { get; set; }
        /// <summary>
        /// 排序号
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否推荐
        /// </summary>
        public bool? IsRecommend { get; set; }
        /// <summary>
        /// 密码错误次数
        /// </summary>
        public int? PwdErrorCount { get; set; }
        /// <summary>
        /// 登录状态
        /// </summary>
        public int? LogonStatus { get; set; }
        /// <summary>
        /// 锁定状态
        /// </summary>
        public int? LockedStatus { get; set; }
        /// <summary>
        /// 在线问诊标志
        /// </summary>
        public bool? OnlineConsultation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UnionId { get; set; }
        /// <summary>
        /// HIS部门编号
        /// </summary>
        [NotMapped]
        public string HISDepartmentId { get; set; }
        /// <summary>
        /// 分类标志
        /// </summary>
        public string Taxon { get; set; }

        /// <summary>
        /// 图文咨询费用
        /// </summary>
        public decimal? GraphicFees { get; set; }
        /// <summary>
        ///  电话咨询费
        /// </summary>
        public decimal? TelephoneFee { get; set; }
        /// <summary>
        ///  视频咨询费
        /// </summary>
        public decimal? VideoFee { get; set; }

        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }

 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}