﻿namespace Sand.Domain.Entities.PaymentOrder
{
    /// <summary>
    /// 用户评价表
    /// </summary>
    public partial class Userevaluation {
    }
}