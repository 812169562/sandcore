﻿using Dapper.Contrib.Extensions;
using Sand.Domain.Entities.PaymentOrder.Enums;
using Sand.Extensions;
using System;
using System.Runtime.Serialization;

namespace Sand.Domain.Entities.PaymentOrder
{/// <summary>
 /// 退款数据传输对象
 /// </summary>
    [Table("Refund")]
    public class Refund
    {
        /// <summary>
        /// 
        /// </summary>
        [ExplicitKey]
        public string Id { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        public string OrdersId { get; set; }
        /// <summary>
        /// HIS收费编号
        /// </summary>
        [DataMember]
        public string ChargeID { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        [Computed]
        public string StatusStr => ((RefundStatus)Status).DisplayName();
        /// <summary>
        /// 创建人
        /// </summary>
        public string CreateId { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        public bool IsEnable { get; set; }
        /// <summary>
        /// 最近更新人
        /// </summary>
        public string LastUpdateName { get; set; }
        /// <summary>
        /// 最近更新者
        /// </summary>
        public string LastUpdateId { get; set; }
        /// <summary>
        /// 最近更新时间
        /// </summary>
        [Computed]
        public string LastUpdateTimeStr => this.LastUpdateTime.ToDateTimeString();
        /// <summary>
        /// 最近更新时间
        /// </summary>
        public DateTime? LastUpdateTime { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public string CreateName { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        [Computed]
        public string CreateTimeStr => this.CreateTime.ToDateTimeString();
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreateTime { get; set; }
        /// <summary>
        /// 版本号
        /// </summary>
        public string Version { get; set; }
        /// <summary>
        /// 退款原因
        /// </summary>
        public string Reasons { get; set; }
        /// <summary>
        /// 退款失败原因
        /// </summary>
        public string FailureReasons { get; set; }
        /// <summary>
        /// 退款金额
        /// </summary>
        public int RefundAmount { get; set; }
    }
}
