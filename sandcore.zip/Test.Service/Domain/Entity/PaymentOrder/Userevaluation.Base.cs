﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    /// 用户评价表
    /// </summary>
    [Description( "用户评价表" )]
    public partial class Userevaluation : Entity,ISoftDelete {
        /// <summary>
        /// 初始化用户评价表
        /// </summary>
        public Userevaluation(){
        }
        /// <summary>
        /// 订单编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "订单编号输入过长，不能超过36位" )]
        public string OrdersId { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "用户编号输入过长，不能超过36位" )]
        public string UserId { get; set; }
        /// <summary>
        ///  星级
        /// </summary>
        [Required(ErrorMessage = "请填写 星级")]
        public int Star { get; set; }
        /// <summary>
        /// 评语
        /// </summary>
        [StringLength( 1000, ErrorMessage = "评语输入过长，不能超过1000位" )]
        public string Comment { get; set; }
        /// <summary>
        /// 是否匿名
        /// </summary>
        public bool? IsAnonymous { get; set; }
         /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 类型(1.就诊评论2.咨询评论)
        /// </summary>
        [Required(ErrorMessage = "类型不能为空")]
        public int Type { get; set; }

        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}