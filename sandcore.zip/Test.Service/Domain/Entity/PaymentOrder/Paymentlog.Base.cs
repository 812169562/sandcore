﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    /// 支付日志
    /// </summary>
    [Description( "支付日志" )]
    public partial class Paymentlog : Entity,ISoftDelete {
        /// <summary>
        /// 初始化支付日志
        /// </summary>
        public Paymentlog(){
        }
        /// <summary>
        /// 支付编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "支付编号输入过长，不能超过36位")]
        [ForeignKey("Id")]
        public string PaymentId { get; set; }
        /// <summary>
        /// 支付总金额(退费时为负数,分为单位）
        /// </summary>
        public int? Amount { get; set; }
        /// <summary>
        /// 传入参数
        /// </summary>
        [StringLength( 16383, ErrorMessage = "传入参数输入过长，不能超过16383位" )]
        public string Input { get; set; }
        /// <summary>
        /// 返回数据
        /// </summary>
        [StringLength( 16383, ErrorMessage = "返回数据输入过长，不能超过16383位" )]
        public string Output { get; set; }
        /// <summary>
        /// 支付变化情况
        /// </summary>
        [StringLength( 16383, ErrorMessage = "支付变化情况输入过长，不能超过16383位" )]
        public string PaymentChargeLog { get; set; }
        /// <summary>
        /// Ip
        /// </summary>
        [StringLength( 100, ErrorMessage = "Ip输入过长，不能超过100位" )]
        public string Ip { get; set; }
         /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        
        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}