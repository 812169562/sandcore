﻿namespace  Sand.Domain.Entities.PaymentOrder{
    /// <summary>
    /// convenientorder
    /// </summary>
    public partial class Convenientorder {
    }
}