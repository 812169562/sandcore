﻿namespace  Sand.Domain.Entities.PaymentOrder{
    /// <summary>
    /// OrdersLog订单日志表
    /// </summary>
    public partial class Orderslog {
    }
}