﻿using Sand.Dependency;
using Sand.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder
{
    /// <summary>
    /// 在线问诊订单表
    /// </summary>
    [Description("订单表")]
    public partial class ChatOrders : Entity, ISoftDelete
    {
        /// <summary>
        /// 初始化订单表
        /// </summary>
        public ChatOrders()
        {
        }

        /// <summary>
        /// 医生编号
        /// </summary>
        [StringLength(36, ErrorMessage = "医生编号输入过长，不能超过36位")]
        public string UserId { get; set; }
        /// <summary>
        /// 医生姓名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 患者编号
        /// </summary>
        [StringLength(36, ErrorMessage = "患者编号输入过长，不能超过36位")]
        public string PatientId { get; set; }
        /// <summary>
        /// 患者姓名
        /// </summary>
        public string PatientName { get; set; }
        /// <summary>
        /// 科室
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 科室Id
        /// </summary>
        [StringLength(36, ErrorMessage = "科室Id输入过长，不能超过36位")]
        public string DepartmentId { get; set; }
        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 职称
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 类型(1图文,2电话,3视频)
        /// </summary>
        public int? Type { get; set; }
        /// <summary>
        /// 订单生成时间
        /// </summary>
        public DateTime? BeginTime { get; set; }
        /// <summary>
        /// 订单结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// 支付平台订单号
        /// </summary>la
        [StringLength(60, ErrorMessage = "支付平台订单号输入过长，不能超过60位")]
        public string TradeNo { get; set; }
        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength(60, ErrorMessage = "系统订单号输入过长，不能超过60位")]
        public string OutTradeNo { get; set; }
        /// <summary>
        /// 订单支付时间
        /// </summary>
        public DateTime? PayTime { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        public int? Money { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }

        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}
