﻿namespace Sand.Domain.Entities.PaymentOrders
{
    /// <summary>
    /// 支付日志
    /// </summary>
    public partial class Paymentlog {
    }
}