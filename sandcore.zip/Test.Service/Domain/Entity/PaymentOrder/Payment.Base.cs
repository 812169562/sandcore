﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    ///  第三方支付信息
    /// </summary>
    [Description(" 第三方支付信息")]
    public partial class Payment : Entity, ISoftDelete {
        /// <summary>
        /// 初始化 第三方支付信息
        /// </summary>
        public Payment() {
        }
        /// <summary>
        /// 支付者
        /// </summary>
        [StringLength(36, ErrorMessage = "支付者输入过长，不能超过36位")]
        public string PayUserId { get; set; }
        /// <summary>
        /// 支付者
        /// </summary>
        [StringLength(150, ErrorMessage = "支付者输入过长，不能超过150位")]
        public string PayUserName { get; set; }
        /// <summary>
        /// 支付时间
        /// </summary>
        public DateTime? PayDate { get; set; }
        /// <summary>
        /// 支付类型(1,Web,2.App,3小程序,4.Wap)
        /// </summary>
        public int? PayType { get; set; }
        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        public int? Amount { get; set; }
        /// <summary>
        /// 已退费金额（分为单位）
        /// </summary>
        public int? RefundAmount { get; set; }
        /// <summary>
        /// 确认已支付金额（分为单位）
        /// </summary>
        public int? ComfirmAmount { get; set; }
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [StringLength(60, ErrorMessage = "支付平台订单号输入过长，不能超过60位")]
        public string TradeNo { get; set; }
        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength(60, ErrorMessage = "系统订单号输入过长，不能超过60位")]
        public string OutTradeNo { get; set; }
        /// <summary>
        /// 支付平台(1,微信,2,支付宝,3银联,4.QQ)
        /// </summary>
        public int? PayPlatform { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 支付日志记录
        /// </summary>
        public List<Paymentlog> Paymentlog { get; set; }

        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}