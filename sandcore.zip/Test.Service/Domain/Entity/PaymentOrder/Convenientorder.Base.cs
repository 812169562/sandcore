﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    /// convenientorder
    /// </summary>
    [Description( "convenientorder" )]
    public partial class Convenientorder : Entity,ISoftDelete {
        /// <summary>
        /// 初始化convenientorder
        /// </summary>
        public Convenientorder(){
        }
        /// <summary>
        /// 就诊卡编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "就诊卡编号输入过长，不能超过36位" )]
        public string CardId { get; set; }
        /// <summary>
        /// HIS挂号费用记录编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "HIS挂号费用记录编号输入过长，不能超过36位" )]
        public string RegisterChargeId { get; set; }
        /// <summary>
        /// HIS费用表信息
        /// </summary>
        [StringLength( 16383, ErrorMessage = "HIS费用表信息输入过长，不能超过16383位" )]
        public string ChargeJson { get; set; }
        /// <summary>
        /// HIS费用明细表信息
        /// </summary>
        [StringLength( 16383, ErrorMessage = "HIS费用明细表信息输入过长，不能超过16383位" )]
        public string ChargeDetalisJson { get; set; }
        /// <summary>
        /// 类型（1.便民 2.拍方抓药）
        /// </summary>
        public int? Type { get; set; }
        /// <summary>
        /// 医生编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "医生编号输入过长，不能超过36位" )]
        public string UserId { get; set; }
        /// <summary>
        /// 审核时间
        /// </summary>
        public DateTime? AuditTime { get; set; }
        /// <summary>
        /// 审核人编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "审核人编号输入过长，不能超过36位" )]
        public string AuditId { get; set; }
        /// <summary>
        /// 审核人名字
        /// </summary>
        [StringLength( 50, ErrorMessage = "审核人名字输入过长，不能超过50位" )]
        public string AuditName { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        [StringLength( 500, ErrorMessage = "备注输入过长，不能超过500位" )]
        public string Remark { get; set; }
        /// <summary>
        /// 图片编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "图片编号输入过长，不能超过36位" )]
        public string ImageNewName { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int? Count { get; set; }
        /// <summary>
        /// 药品类型（1.饮片2.小包装3.免煎）
        /// </summary>
        public int? DrugType { get; set; }
        /// <summary>
        /// 处方类型(1.中药2.西药)
        /// </summary>
        public int? PrescriptionType { get; set; }
         /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 项目名称
        /// </summary>
        [StringLength(36, ErrorMessage = "项目名称输入过长，不能超过200位")]
        public string ItemName { get; set; }
        /// <summary>
        /// 审核备注
        /// </summary>
        [StringLength(36, ErrorMessage = "审核备注输入过长，不能超过500位")]
        public string AuditRemark { get; set; }
        /// <summary>
        /// 是否配送
        /// </summary>
        public bool? IsDelivery { get; set; }
        /// <summary>
        /// 是否代煎
        /// </summary>
        public bool? IsDecocting { get; set; }
        /// <summary>
        /// 收货人
        /// </summary>
        public string Consignee { get; set; }
        /// <summary>
        /// 收货人电话
        /// </summary>
        public string Tel { get; set; }
        /// <summary>
        /// 收货人地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 快递单号
        /// </summary>
        public string CourierNumber { get; set; }
        /// <summary>
        /// 快递
        /// </summary>
        public string ExpressId { get; set; }
        /// <summary>
        /// 快递名称
        /// </summary>
        public string ExpressName { get; set; }
        /// <summary>
        /// 是否当日送达(1.是 0.否)
        /// </summary>
        public int? IsSamedayDelivery { get; set; }
        /// <summary>
        /// 煎服法
        /// </summary>
        public string Use { get; set; }
        /// <summary>
        /// HIS订单号
        /// </summary>
        public string ChargeNo { get; set; }
        /// <summary>
        /// 原开方医生
        /// </summary>
        public string OriginalDoctor { get; set; }
        /// <summary>
        /// 原开方医院
        /// </summary>
        public string OriginalHospital { get; set; }
        /// <summary>
        /// 原开方诊断
        /// </summary>
        public string OriginalDiagnosis { get; set; }
        

        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}