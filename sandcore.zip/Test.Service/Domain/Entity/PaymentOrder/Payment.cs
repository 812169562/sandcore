﻿namespace  Sand.Domain.Entities.PaymentOrder{
    /// <summary>
    ///  第三方支付信息
    /// </summary>
    public partial class Payment {
    }
}