﻿namespace Sand.Domain.Entities.PaymentOrder
{
    /// <summary>
    /// 订单表
    /// </summary>
    public partial class Orders {
    }
}