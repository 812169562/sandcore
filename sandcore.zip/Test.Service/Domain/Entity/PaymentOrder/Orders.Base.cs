﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    /// 订单表
    /// </summary>
    [Description( "订单表" )]
    public partial class Orders : Entity,ISoftDelete {
        /// <summary>
        /// 初始化订单表
        /// </summary>
        public Orders(){
        }

        /// <summary>
        /// 预约编号(此处HIS tbReservation ID)
        /// </summary>
        [StringLength(36, ErrorMessage = "预约编号输入过长，不能超过36位")]
        public string ReservationID { get; set; }
        /// <summary>
        /// 外部编号(此处HISId)
        /// </summary>
        [StringLength( 36, ErrorMessage = "外部编号(此处HISId)输入过长，不能超过36位" )]
        public string OutId { get; set; }
        /// <summary>
        /// 患者编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "患者编号输入过长，不能超过36位" )]
        public string CardId { get; set; }
        /// <summary>
        /// 患者编号(外部系统编号和CardId1-1)
        /// </summary>
        [StringLength( 36, ErrorMessage = "患者编号(外部系统编号和CardId1-1)输入过长，不能超过36位" )]
        public string OutPatientId { get; set; }
        /// <summary>
        /// 类型(1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目)
        /// </summary>
        public int? Type { get; set; }
        /// <summary>
        /// 支付编号
        /// </summary>
        [StringLength( 36, ErrorMessage = "支付编号输入过长，不能超过36位" )]
        public string PaymentId { get; set; }
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        [StringLength( 60, ErrorMessage = "支付平台订单号输入过长，不能超过60位" )]
        public string TradeNo { get; set; }
        /// <summary>
        /// 系统订单号
        /// </summary>
        [StringLength( 60, ErrorMessage = "系统订单号输入过长，不能超过60位" )]
        public string OutTradeNo { get; set; }
        /// <summary>
        /// 支付金额（分为单位）
        /// </summary>
        public int? Amount { get; set; }
        /// <summary>
        /// 备注信息
        /// </summary>
        [StringLength( 200, ErrorMessage = "备注信息输入过长，不能超过200位" )]
        public string Remark { get; set; }
         /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 订单情况
        /// </summary>
        [StringLength(4095, ErrorMessage = "订单情况输入过长，不能超过4095位")]
        public string Details { get; set; }
        ///// <summary>
        ///// 
        ///// </summary>
        public List<Orderslog> Orderslog { get; set; }
        /// <summary>
        /// 就诊时间
        /// </summary>
        public DateTime? SittingDate { get; set; }
        /// <summary>
        /// 医生编号
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 坐诊ID
        /// </summary>
        public string SittingId { get; set; }
        /// <summary>
        /// 便民订单编号
        /// </summary>
        public string ConvenientOrderId { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}