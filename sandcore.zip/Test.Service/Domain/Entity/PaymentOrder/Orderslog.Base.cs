﻿using System;
using Sand.Helpers;
using Sand.Dependency;
using Sand.Domain.Entities;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sand.Domain.Entities.PaymentOrder {
    /// <summary>
    /// OrdersLog订单日志表
    /// </summary>
    [Description( "OrdersLog订单日志表" )]
    public partial class Orderslog : Entity,ISoftDelete {
        /// <summary>
        /// 初始化OrdersLog订单日志表
        /// </summary>
        public Orderslog(){
        }
        /// <summary>
        /// 订单编号情况
        /// </summary>
        [StringLength( 16383, ErrorMessage = "订单编号情况输入过长，不能超过16383位" )]
        public string OrdersChargeLog { get; set; }
         /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        public bool IsDeleted { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [StringLength(36, ErrorMessage = "订单编号输入过长，不能超过36位")]
        [ForeignKey("Id")]
        //[NotMapped]
        public string OrdersId { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        public override void Init()
        {
            this.Id = Uuid.Next();
            base.Init();
        }
 
        /// <summary>
        /// 加载
        /// </summary>
        public override void Load(IEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}