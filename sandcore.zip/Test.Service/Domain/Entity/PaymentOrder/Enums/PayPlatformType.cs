﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 支付平台(1,微信,2,支付宝,3银联,4.QQ)
    /// </summary>
    public enum PayPlatformType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        Unknown = 0,
        /// <summary>
        /// 微信
        /// </summary>
        [Description("微信")]
        [DisplayName("微信")]
        WeChat = 1,
        /// <summary>
        /// 支付宝
        /// </summary>
        [Description("支付宝")]
        [DisplayName("支付宝")]
        Alipay = 2,
        /// <summary>
        /// 3银联
        /// </summary>
        [Description("银联")]
        [DisplayName("银联")]
        UnionPay = 3,
        /// <summary>
        /// QQ
        /// </summary>
        [Description("QQ")]
        [DisplayName("QQ")]
        QQ = 4
    }
}
