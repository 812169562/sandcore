﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 支付类型(1,Web,2.App,3小程序,4.Wap)
    /// </summary>
    public enum PayType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        Unknown = 0,
        /// <summary>
        /// Web
        /// </summary>
        [Description("Web")]
        [DisplayName("Web")]
        Web = 1,
        /// <summary>
        /// App
        /// </summary>
        [Description("App")]
        [DisplayName("App")]
        App = 2,
        /// <summary>
        ///小程序
        /// </summary>
        [Description("小程序")]
        [DisplayName("小程序")]
        SmallProcedures = 3,
        /// <summary>
        /// Wap
        /// </summary>
        [Description("Wap")]
        [DisplayName("Wap")]
        Wap = 4,
        /// <summary>
        /// 公众号
        /// </summary>
        [Description("公众号")]
        [DisplayName("公众号")]
        Public = 5
    }
}
