﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 支付状态(0支付失效,1,等待支付,2支付成功,3部分退费,4完成退费)
    /// </summary>
    public enum PaymentStatus
    {
        /// <summary>
        /// 已取消
        /// </summary>
        [Description("已取消")]
        [DisplayName("已取消")]
        Cancelled = -1,
        /// <summary>
        /// 支付失效
        /// </summary>
        [Description("失效")]
        [DisplayName("失效")]
        Invalid = 0,
        /// <summary>
        /// 等待支付
        /// </summary>
        [Description("等待支付")]
        [DisplayName("等待支付")]
        Waiting = 1,
        /// <summary>
        /// 支付成功
        /// </summary>
        [Description("支付成功")]
        [DisplayName("支付成功")]
        Success = 2,
        /// <summary>
        /// 部分退费
        /// </summary>
        [Description("部分退费")]
        [DisplayName("部分退费")]
        PartialRefund = 3,
        /// <summary>
        /// 完成退费
        /// </summary>
        [Description("完成退费")]
        [DisplayName("完成退费")]
        Refund = 4
    }
}
