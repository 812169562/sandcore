﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    ///  类型(1图文,2电话,3视频)
    /// </summary>
    public enum ChatOrdersType
    {
        /// <summary>
        /// 未知
        /// </summary>
        None = 0,
        /// <summary>
        /// 图文
        /// </summary>
        [Description("挂号")]
        [DisplayName("挂号")]
        text = 1,
        /// <summary>
        /// 电话
        /// </summary>
        [Description("西药")]
        [DisplayName("西药")]
        phone = 2,
        /// <summary>
        /// 视频
        /// </summary>
        [Description("中药")]
        [DisplayName("中药")]
        video = 3,
    }
}
