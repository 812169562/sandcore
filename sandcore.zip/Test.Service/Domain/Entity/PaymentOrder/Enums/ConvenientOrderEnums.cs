﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 状态
    /// </summary>
    public enum ConvenientOrderStatus
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        None = 0,
        /// <summary>
        /// 待审核
        /// </summary>
        [Description("待审核")]
        [DisplayName("待审核")]
        Audit = 1,
        /// <summary>
        /// 审核通过
        /// </summary>
        [Description("审核通过")]
        [DisplayName("审核通过")]
        Pass = 2,
        /// <summary>
        /// 审核未通过
        /// </summary>
        [Description("审核未通过")]
        [DisplayName("审核未通过")]
        Fail = 3,
        /// <summary>
        /// 审核通过已缴费
        /// </summary>
        [Description("审核通过已缴费")]
        [DisplayName("审核通过已缴费")]
        Payment = 4,
        /// <summary>
        /// 已配送
        /// </summary>
        [Description("已配送")]
        [DisplayName("已配送")]
        Delivery = 5
    }

    /// <summary>
    /// 类型
    /// </summary>
    public enum ConvenientOrderType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        None = 0,
        /// <summary>
        /// 便民门诊
        /// </summary>
        [Description("便民门诊")]
        [DisplayName("便民门诊")]
        Convenient = 1,
        /// <summary>
        /// 拍方抓药
        /// </summary>
        [Description("拍方抓药")]
        [DisplayName("拍方抓药")]
        Patron = 2
    }

    /// <summary>
    /// 处方类型
    /// </summary>
    public enum PrescriptionType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        None = 0,
        /// <summary>
        /// 中药处方
        /// </summary>
        [Description("中药处方")]
        [DisplayName("中药处方")]
        China = 1,
        /// <summary>
        /// 西药处方
        /// </summary>
        [Description("西药处方")]
        [DisplayName("西药处方")]
        West = 2
    }

    /// <summary>
    /// 药品类型
    /// </summary>
    public enum DrugType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        None = 0,
        /// <summary>
        /// 小包装
        /// </summary>
        [Description("精制饮片")]
        [DisplayName("精制饮片")]
        SmallPackage = 1,
        /// <summary>
        /// 中药饮片
        /// </summary>
        [Description("普通饮片")]
        [DisplayName("普通饮片")]
        DrinkingSlices = 2,
        /// <summary>
        /// 免煎
        /// </summary>
        [Description("免煎")]
        [DisplayName("免煎")]
        BoilFree = 3
    }
}
