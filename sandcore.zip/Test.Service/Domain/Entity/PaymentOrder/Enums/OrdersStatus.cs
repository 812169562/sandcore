﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 订单状态 0失效,1,待付款,2已支付,3已完成,-1退款中,-2退款完成,-3已取消
    /// </summary>
    public enum OrdersStatus
    {
        /// <summary>
        /// 失效
        /// </summary>
        [Description("失效")]
        [DisplayName("失效")]
        Invalid = 0,
        /// <summary>
        /// 待付款
        /// </summary>
        [Description("待付款")]
        [DisplayName("待付款")]
        Pay = 1,
        /// <summary>
        /// 已支付
        /// </summary>
        [Description("已支付")]
        [DisplayName("已支付")]
        Paymented = 2,
        /// <summary>
        /// 已完成
        /// </summary>
        [Description("已完成")]
        [DisplayName("已完成")]
        Completed = 3,
        /// <summary>
        /// 退款中
        /// </summary>
        [Description("退款中")]
        [DisplayName("退款中")]
        Refunding = -1,
        /// <summary>
        /// 退款完成
        /// </summary>
        [Description("退款完成")]
        [DisplayName("退款完成")]
        Refund = -2,
        /// <summary>
        /// 已取消
        /// </summary>
        [Description("已取消")]
        [DisplayName("已取消")]
        Cancelled = -3
    }
    /// <summary>
    /// 退款状态
    /// </summary>
    public enum RefundStatus
    {
        /// <summary>
        /// 退款中
        /// </summary>
        [Description("退款中")]
        [DisplayName("退款中")]
        Refunding = 1,
        /// <summary>
        /// 退款完成
        /// </summary>
        [Description("退款完成")]
        [DisplayName("退款完成")]
        Success = 2,
        /// <summary>
        /// 审核不通过
        /// </summary>
        [Description("审核不通过")]
        [DisplayName("审核不通过")]
        Failure = 3,
        /// <summary>
        /// 微信平台退款失败
        /// </summary>
        [Description("微信平台退款失败")]
        [DisplayName("微信平台退款失败")]
        PlatformFailure = -1,
        /// <summary>
        /// 微信平台预约费退款失败
        /// </summary>
        [Description("微信平台预约费退款失败")]
        [DisplayName("微信平台预约费退款失败")]
        BookingMoneyPlatformFailure = -2
    }
}
