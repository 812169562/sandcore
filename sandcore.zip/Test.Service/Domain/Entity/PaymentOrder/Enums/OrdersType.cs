﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 订单类型 1,挂号,2西药,3中药,4输液,5治疗,6检验,7检查,8其他缴费项目
    /// </summary>
    public enum OrdersType
    {
        /// <summary>
        /// 未知
        /// </summary>
        None = 0,
        /// <summary>
        /// 挂号
        /// </summary>
        [Description("挂号")]
        [DisplayName("挂号")]
        Register = 1,
        /// <summary>
        /// 西药
        /// </summary>
        [Description("西药")]
        [DisplayName("西药")]
        WesternMedicine = 2,
        /// <summary>
        /// 中药
        /// </summary>
        [Description("中药")]
        [DisplayName("中药")]
        ChineseMedicine = 3,
        /// <summary>
        /// 输液
        /// </summary>
        [Description("输液")]
        [DisplayName("输液")]
        Infusion = 4,
        /// <summary>
        /// 治疗
        /// </summary>
        [Description("治疗")]
        [DisplayName("治疗")]
        Treatment = 5,
        /// <summary>
        /// 检验
        /// </summary>
        [Description("检验")]
        [DisplayName("检验")]
        Checkout = 6,
        /// <summary>
        /// 检查
        /// </summary>
        [Description("检查")]
        [DisplayName("检查")]
        Inspect = 7,
        /// <summary>
        /// 其他缴费项目
        /// </summary>
        [Description("其他缴费项目")]
        [DisplayName("其他缴费项目")]
        Other = 8,
        /// <summary>
        /// 图文咨询
        /// </summary>
        [Description("图文咨询")]
        [DisplayName("图文咨询")]
        Graphic = 9,
        /// <summary>
        /// 网络开单
        /// </summary>
        [Description("网络开单")]
        [DisplayName("网络开单")]
        Telephone = 10,
        /// <summary>
        /// 视频咨询
        /// </summary>
        [Description("视频咨询")]
        [DisplayName("视频咨询")]
        Video = 11
    }
}
