﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Sand.Domain.Entities.PaymentOrder.Enums
{
    /// <summary>
    /// 评论类型(1.就诊评论2.咨询评论)
    /// </summary>
    public enum EvaluationType
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        [DisplayName("未知")]
        None = 0,
        /// <summary>
        /// 就诊
        /// </summary>
        [Description("就诊")]
        [DisplayName("就诊")]
        Visit = 1,
        /// <summary>
        /// 咨询
        /// </summary>
        [Description("咨询")]
        [DisplayName("咨询")]
        Consultation = 2,
    }
}
