﻿using Sand.Utils.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sand.Domain.Entities.Payment
{
    /// <summary>
    /// 
    /// </summary>
    public class PayResult
    {
        /// <summary>
        /// 状态码
        /// </summary>
        public StateCode Code { get; set; }
        /// <summary>
        /// 消息
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// 数据
        /// </summary>
        public PayModel Data { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }
    }
}
