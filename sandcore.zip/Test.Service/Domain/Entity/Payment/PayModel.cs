﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using Dapper.Contrib.Extensions;

namespace Sand.Domain.Entities.Payment
{
    /// <summary>
    /// 支付模型
    /// </summary>
    public class PayModel
    {
        /// <summary>
        /// 支付类型
        /// </summary>
        public PaymentType PaymentType { get; set; }
        /// <summary>
        /// 商户系统内部订单号
        /// </summary>
        public string OutTradeNo { get; set; }
        /// <summary>
        /// 支付平台订单号
        /// </summary>
        public string TradeNo { get; set; }
        /// <summary>
        /// 订单信息(信息)
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        /// 订单标题
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// 授权码
        /// 扫码支付授权码，设备读取用户微信中的条码或者二维码信息
        /// </summary>
        public string AuthCode { get; set; }
        /// <summary>
        /// 标价币种,符合ISO 4217标准的三位字母代码，默认人民币：CNY，详细列表请参见货币类型
        /// </summary>
        public string AmountType { get; set; } = "CNY";
        /// <summary>
        /// 标价金额,订单总金额，该处单位为分(注意支付宝为元，各接口按照文档处理结果)
        /// </summary>
        public int TotalAmount { get; set; }
        /// <summary>
        /// 标价金额,订单总金额，该处单位为元(当该值>0时，并且不得传入大于小数点2位的数值，TotalAmount值无效)
        /// </summary>
        public decimal TotalAmountDec { get; set; }
        /// <summary>
        /// 退款金额，该处单位为分(注意支付宝为元，各接口按照文档处理结果)
        /// </summary>
        public int RefundAmount { get; set; }
        /// <summary>
        /// 退款金额，该处单位为分该处单位为元(当该值>0时，并且不得传入大于小数点2位的数值，RefundAmount值无效)
        /// </summary>
        public decimal RefundAmountDec { get; set; }
        /// <summary>
        /// 退款原因
        /// </summary>
        public string RefundDesc { get; set; }
        /// <summary>
        /// 用户标识，此参数为微信用户在商户对应appid下的唯一标识。
        /// </summary>
        public string OpenId { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 场景信息,该字段用于上报支付的场景信息,针对H5支付有以下三种场景,请根据对应场景上报
        /// </summary>
        public string SceneInfo { get; set; }
        /// <summary>
        /// 商户退款单号
        /// </summary>
        public string OutRefundNo { get; set; }
        /// <summary>
        /// 订单明细(一次支付可能包含多个订单信息)
        /// </summary>
        public List<OrderSubject> OrderSubject { get; set; }
    }
    /// <summary>
    /// 订单详细
    /// </summary>
    public class OrderSubject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }
    }

    /// <summary>
    /// 支付类型
    /// </summary>
    public enum PaymentType
    {

        /// <summary>
        /// 微信公众号支付
        /// </summary>
        [Description("未知的支付类型")]
        [DisplayName("未知的支付")]
        Unknow = 0,
        /// <summary>
        /// 微信公众号支付
        /// </summary>
        [Description("微信公众号支付")]
        [DisplayName("微信支付")]
        WechatPublic = 1,
        /// <summary>
        /// 微信h5支付
        /// </summary>
        [Description("微信h5支付")]
        [DisplayName("微信支付")]
        WechatWap = 2,
        /// <summary>
        /// 微信退款
        /// </summary>
        [Description("微信退款")]
        [DisplayName("微信退款")]
        WechatRefund = 3,
        /// <summary>
        /// 微信查询
        /// </summary>
        [Description("微信查询")]
        [DisplayName("微信查询")]
        WechatQuery = 4,
        /// <summary>
        /// 微信查询
        /// </summary>
        [Description("小程序支付")]
        [DisplayName("微信支付")]
        WechatApplet = 5,
    }
}
