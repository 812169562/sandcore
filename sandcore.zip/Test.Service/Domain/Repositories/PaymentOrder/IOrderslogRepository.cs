﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;
using Sand.Dependency;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    /// OrdersLog订单日志表仓储
    /// </summary>
    public interface IOrderslogRepository : IRepository<Orderslog>
    {
    }
}
