﻿using Sand.Domain.Entities.PaymentOrder;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Domain.Repositories.PaymentOrder
{
    /// <summary>
    /// 在线问诊仓储
    /// </summary>
    public interface IChatOrdersRepository : IRepository<ChatOrders>
    {
    }
}
