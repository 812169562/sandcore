﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    /// 支付日志仓储
    /// </summary>
    public interface IPaymentlogRepository : IRepository<Paymentlog> {
    }
}
