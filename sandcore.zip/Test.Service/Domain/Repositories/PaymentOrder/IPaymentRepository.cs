﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    ///  第三方支付信息仓储
    /// </summary>
    public interface IPaymentRepository : IRepository<Payment> {
    }
}
