﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    /// convenientorder仓储
    /// </summary>
    public interface IConvenientorderRepository : IRepository<Convenientorder> {
    }
}
