﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    /// 订单表仓储
    /// </summary>
    public interface IOrdersRepository : IRepository<Orders> {
    }
}
