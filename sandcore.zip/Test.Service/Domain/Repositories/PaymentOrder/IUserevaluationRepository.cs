﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.PaymentOrder;

namespace Sand.Domain.Repositories.PaymentOrder {
    /// <summary>
    /// 用户评价表仓储
    /// </summary>
    public interface IUserevaluationRepository : IRepository<Userevaluation> {
    }
}
