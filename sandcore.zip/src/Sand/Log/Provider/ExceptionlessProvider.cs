﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using Sand.Log.Abstractions;
using Exceptionless;
using System.Linq;
using Sand.Log.Core;
using Sand.Helpers;

namespace Sand.Log.Provider
{
    /// <summary>
    /// Exceptionless日志提供程序
    /// </summary>
    public class ExceptionlessProvider : ILogProvider
    {
        /// <summary>
        /// NLog日志操作，用于控制日志级别是否启用
        /// </summary>
        private readonly NLog.ILogger _logger;
        /// <summary>
        /// 客户端
        /// </summary>
        private readonly ExceptionlessClient _client;
        /// <summary>
        /// 行号
        /// </summary>
        private int _line;

        /// <summary>
        /// 初始化Exceptionless日志提供程序
        /// </summary>
        /// <param name="logName">日志名称</param>
        public ExceptionlessProvider(string logName)
        {
            _logger = NLogProvider.GetLogger(logName);
            _client = ExceptionlessClient.Default;
        }

        /// <summary>
        /// 日志名称
        /// </summary>
        public string LogName => _logger.Name;

        /// <summary>
        /// 调试级别是否启用
        /// </summary>
        public bool IsDebugEnabled => _logger.IsDebugEnabled;

        /// <summary>
        /// 跟踪级别是否启用
        /// </summary>
        public bool IsTraceEnabled => _logger.IsTraceEnabled;

        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="level">日志等级</param>
        /// <param name="content">日志内容</param>
        public void WriteLog(LogLevel level, ILogContent content)
        {
            InitLine();
            var builder = CreateBuilder(level, content);
            builder.SetUserIdentity(content.UserName);
            builder.SetSource(content.Url);
            builder.SetReferenceId(content.TraceId);
            AddProperties(builder, content as ExceptionlessContent);
            builder.Submit();
        }

        /// <summary>
        /// 初始化行号
        /// </summary>
        private void InitLine()
        {
            _line = 1;
        }

        /// <summary>
        /// 创建事件生成器
        /// </summary>
        private EventBuilder CreateBuilder(LogLevel level, ILogContent content)
        {
            if (content.Exception != null)
                return _client.CreateException(content.Exception);
            return _client.CreateLog(GetMessage(content), ConvertTo(level));
        }

        /// <summary>
        /// 获取日志消息
        /// </summary>
        /// <param name="content">日志内容</param>
        private string GetMessage(ILogContent content)
        {
            var caption = content as ICaption;
            if (caption != null && string.IsNullOrWhiteSpace(caption.Caption) == false)
                return caption.Caption;
            if (content.Content.Length > 0)
                return content.Content.ToString();
            return content.TraceId;
        }

        /// <summary>
        /// 转换日志等级
        /// </summary>
        private Exceptionless.Logging.LogLevel ConvertTo(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Trace:
                    return Exceptionless.Logging.LogLevel.Trace;
                case LogLevel.Debug:
                    return Exceptionless.Logging.LogLevel.Debug;
                case LogLevel.Information:
                    return Exceptionless.Logging.LogLevel.Info;
                case LogLevel.Warning:
                    return Exceptionless.Logging.LogLevel.Warn;
                case LogLevel.Error:
                    return Exceptionless.Logging.LogLevel.Error;
                case LogLevel.Critical:
                    return Exceptionless.Logging.LogLevel.Fatal;
                default:
                    return Exceptionless.Logging.LogLevel.Off;
            }
        }

        /// <summary>
        /// 设置用户信息
        /// </summary>
        private void SetUser(ILogContent content)
        {
            if (string.IsNullOrWhiteSpace(content.UserId))
                return;
            _client.Configuration.SetUserIdentity(content.UserId);
        }

        /// <summary>
        /// 设置来源
        /// </summary>
        private void SetSource(EventBuilder builder, ILogContent content)
        {
            if (string.IsNullOrWhiteSpace(content.Url))
                return;
            builder.SetSource(content.Url);
        }

        /// <summary>
        /// 设置跟踪号
        /// </summary>
        private void SetReferenceId(EventBuilder builder, ILogContent content)
        {
            builder.SetReferenceId(content.TraceId);
        }

        /// <summary>
        /// 添加属性集合
        /// </summary>
        private void AddProperties(EventBuilder builder, ILogConvert content)
        {
            if (content == null)
                return;
            foreach (var parameter in content.To().OrderBy(t => t.SortId))
            {
                if (string.IsNullOrWhiteSpace(parameter.Value))
                    continue;
                builder.SetProperty($"{GetLine()}. {parameter.Text}", parameter.Value);
            }
        }

        /// <summary>
        /// 获取行号
        /// </summary>
        private string GetLine()
        {
            return _line++.ToString().PadLeft(2, '0');
        }
    }
}
