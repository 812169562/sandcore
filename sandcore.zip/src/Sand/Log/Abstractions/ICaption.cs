﻿namespace Sand.Log.Abstractions
{
    interface ICaption
    {
        /// <summary>
        /// 标题
        /// </summary>
        string Caption { get; }
    }
}