﻿namespace Sand.Dependency
{
    /// <summary>
    /// 依赖配置
    /// </summary>
    public interface IConfig:Autofac.Core.IModule
    {
    }
}
