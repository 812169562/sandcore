﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Cloud.Express
{
    /// <summary>
    /// 快递请求参数
    /// </summary>
    public interface IExpressRequest
    {
    }
}
