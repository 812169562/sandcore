﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Cloud.Express.Kdniao
{
    /// <summary>
    /// 订单查询
    /// </summary>
    public class KdniaoOrderQueryResponse : KdniaoResponse
    {
    }
}
