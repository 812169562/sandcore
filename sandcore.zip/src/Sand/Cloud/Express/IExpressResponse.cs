﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sand.Cloud.Express
{
    /// <summary>
    /// 快递响应返回接口
    /// </summary>
    public class IExpressResponse
    {
    }
}
