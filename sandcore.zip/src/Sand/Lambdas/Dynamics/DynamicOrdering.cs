﻿using System.Linq.Expressions;

namespace Sand.Lambdas.Dynamics {
    /// <summary>
    /// 
    /// </summary>
    public class DynamicOrdering {
        /// <summary>
        /// 
        /// </summary>
        public Expression Selector;
        /// <summary>
        /// 
        /// </summary>
        public bool Ascending;
    }
}
