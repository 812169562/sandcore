﻿using Sand.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sand.Cache
{
    /// <summary>
    /// 
    /// </summary>
    public static class MapperCache
    {
        //private static IEnumerable<IMapRegister> _data;
        //public static IEnumerable<IMapRegister> Data
        //{
        //    get
        //    {
        //        if (_data == null|| !_data.Any())
        //        {
        //            var result = new List<IMapRegister>();
        //            foreach (var assembly in GetAssemblies())
        //                result.AddRange(Helpers.Reflection.GetTypesByInterface<IMapRegister>(assembly));
        //            return result;
                     
        //        }
        //        return _data;
        //    }
        //}
    }
}
