﻿using Autofac;

namespace Sand.DI
{
    /// <summary>
    /// Ioc配置模块
    /// </summary>
    public abstract class IocConfig : Module
    {
    }
}
