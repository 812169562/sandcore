﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.


[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("样式", "IDE0041:使用 \"is null\" 检查", Justification = "<挂起>", Scope = "member", Target = "~M:Sand.Domain.Entities.Entity`1.GetHashCode~System.Int32")]

